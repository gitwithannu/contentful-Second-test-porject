interface MenuOptions {
  title?: string;
  url?: any;
  isDropdown?: any;
}
interface MenuItem {
  link?: any;
  icon?: string;
  arialabel: string;
}
export const nav: MenuOptions[] = [
  {
    title: "About Us",
    url: "/about",
    isDropdown: [
      {
        title: "Contact Us",
        url: "/contact-us",
      },
    ],
  },
  {
    title: "Our Service",
    url: "!#",
    isDropdown: [
      {
        title: "Seo Organic Marketing",
        url: "/seo-organic-market",
      },
      {
        title: "Amazon Advertisement Services",
        url: "/amazon-advertisement-services",
      },
      {
        title: "Adobe Experience Cloud (AEC)",
        url: "/adobe-experience-cloud",
      },
      {
        title: "Salesforce",
        url: "/salesforce",
      },
      {
        title: "Social Media Advertising",
        url: "/social-media-advertising",
      },
      {
        title: "Content Marketing Services",
        url: "/content-marketing-services",
      },
      {
        title: "Information Architecture Services",
        url: "/information-architecture-services",
      },
      {
        title: "Pay-Per-Click (PPC) Advertising",
        url: "/pay-per-click-advertising",
      },
      {
        title: "Social Media Marketing",
        url: "/social-media-marketing",
      },
      {
        title: "Accessibility Strategies",
        url: "/accessibility-strategies",
      },
      {
        title: "Website Design",
        url: "/website-design",
      },
    ],
  },
  {
    title: "Portfolio",
    url: "/portfolio",
  },
  {
    title: "Our Products",
    url: "!#",
    isDropdown: [
      {
        title: "File Manager",
        url: "!#",
      },
      {
        title: "Duplicate",
        url: "!#",
      },
      {
        title: "Theme Editor",
        url: "!#",
      },
      {
        title: "Stackabl",
        url: "!#",
      },
    ],
  },
  {
    title: "Blog",
    url: "/blogs",
  },
];

export const topnav: MenuItem[] = [
  {
    link: "https://www.facebook.com/truincorp/",
    icon: "icon-facebook",
    arialabel: "Click here for go to facebook page",
  },
  {
    link: "https://twitter.com/Tru_Inc",
    icon: "icon-twitter-1",
    arialabel: "Click here for go to Twitter page",
  },
  {
    link: "https://www.instagram.com/tru_inc/",
    icon: "icon-instagram",
    arialabel: "Click here for go to Instagram page",
  },
];

export const blogtab = [
  { title: "All (6)" },
  { title: "Design (2)" },
  { title: "Development (4)" },
  { title: "Marketing (1)" },
];

export const post = [
  {
    image: "/images/blog/blog-1.jpg",
    title: "Top 5 Web Development Trends for 2020",
    category: "Development",
    readingTime: "7 mins read",
    authorImg: "/images/trublogicon.svg",
    author: "Tru",
    postdate: "Posted Today",
    date: "May 5, 2021",
  },
  {
    image: "/images/blog/blog-2.jpg",
    title: "Top 5 Web Development Trends for 2020",
    category: "Development",
    readingTime: "7 mins read",
    authorImg: "/images/trublogicon.svg",
    author: "Tru",
    postdate: "Posted Today",
    date: "May 5, 2021",
  },
  {
    image: "/images/blog/blog-3.jpg",
    title: "Top 5 Web Development Trends for 2020",
    category: "Development",
    readingTime: "7 mins read",
    authorImg: "/images/trublogicon.svg",
    author: "Tru",
    postdate: "Posted Today",
    date: "May 5, 2021",
  },
  {
    image: "/images/blog/blog-4.jpg",
    title: "Top 5 Web Development Trends for 2020",
    category: "Development",
    readingTime: "7 mins read",
    authorImg: "/images/trublogicon.svg",
    author: "Tru",
    postdate: "Posted Today",
    date: "May 5, 2021",
  },
  {
    image: "/images/blog/blog-5.jpg",
    title: "Top 5 Web Development Trends for 2020",
    category: "Development",
    readingTime: "7 mins read",
    authorImg: "/images/trublogicon.svg",
    author: "Tru",
    postdate: "Posted Today",
    date: "May 5, 2021",
  },
  {
    image: "/images/blog/blog-6.jpg",
    title: "Top 5 Web Development Trends for 2020",
    category: "Development",
    readingTime: "7 mins read",
    authorImg: "/images/trublogicon.svg",
    author: "Tru",
    postdate: "Posted Today",
    date: "May 5, 2021",
  },
  {
    image: "/images/blog/blog-5.jpg",
    title: "Top 5 Web Development Trends for 2020",
    category: "Development",
    readingTime: "7 mins read",
    authorImg: "/images/trublogicon.svg",
    author: "Tru",
    postdate: "Posted Today",
    date: "May 5, 2021",
  },
  {
    image: "/images/blog/blog-6.jpg",
    title: "Top 5 Web Development Trends for 2020",
    category: "Development",
    readingTime: "7 mins read",
    authorImg: "/images/trublogicon.svg",
    author: "Tru",
    postdate: "Posted Today",
    date: "May 5, 2021",
  },
];

export const servicescard = [
  {
    icon: '/images/services/pie-chart.svg',
    title: 'Digital Strategy',
    linetext: 'DS',
    desc: 'Reach out, say hello, and communicate with your audience. The right audience. Using digital strategies from website to social media, you can effectively capture your audiences, encourage shares, and foster organic brand growth.',
    usefulLink: [
      { link: '#', linktext: 'SEO & Organic Marketing' },
      { link: '#', linktext: 'Social Media Marketing' },
      { link: '#', linktext: 'Accessibility Strategies' },
      { link: '#', linktext: 'Brand Persona Development' }
    ]
  },
  {
    icon: '/images/services/ui-icon.svg',
    title: 'User Experience',
    linetext: 'DS',
    desc: 'Reach out, say hello, and communicate with your audience. The right audience. Using digital strategies from website to social media, you can effectively capture your audiences, encourage shares, and foster organic brand growth.',
    usefulLink: [
      { link: '#', linktext: 'Information Architecture' },
      { link: '#', linktext: 'Website Design' },
      { link: '#', linktext: 'Usability Audits' },
      { link: '#', linktext: 'Customer Experience' },
      { link: '#', linktext: 'Creative Studio' }
    ]
  },
  {
    icon: '/images/services/rocket-icon.svg',
    title: 'Development',
    linetext: 'DS',
    desc: 'Reach out, say hello, and communicate with your audience. The right audience. Using digital strategies from website to social media, you can effectively capture your audiences, encourage shares, and foster organic brand growth.',
    usefulLink: [
      { link: '#', linktext: 'Website Development' },
      { link: '#', linktext: 'App Development' },
      { link: '#', linktext: 'Web App Development (PWA)' },
      { link: '#', linktext: 'Development Operations (DevOps)' },
      { link: '#', linktext: 'Platform Migration' }
    ]
  },
  {
    icon: '/images/services/shopping-icon.svg',
    title: 'E-Commerce',
    linetext: 'DS',
    desc: 'Reach out, say hello, and communicate with your audience. The right audience. Using digital strategies from website to social media, you can effectively capture your audiences, encourage shares, and foster organic brand growth.',
    usefulLink: [
      { link: '#', linktext: 'Headless Architecture' },
      { link: '#', linktext: 'Adobe Experience Cloud' },
      { link: '#', linktext: 'Salesforce' },
      { link: '#', linktext: 'BigCommerce' }
    ]
  },
  {
    icon: '/images/services/market-down.svg',
    title: 'Digital Marketing',
    linetext: 'DS',
    desc: 'Reach out, say hello, and communicate with your audience. The right audience. Using digital strategies from website to social media, you can effectively capture your audiences, encourage shares, and foster organic brand growth.',
    usefulLink: [
      { link: '#', linktext: 'PPC Ads' },
      { link: '#', linktext: 'Amazon Ads' },
      { link: '#', linktext: 'Social Media Ads' },
      { link: '#', linktext: 'Custom Email Templating' },
      { link: '#', linktext: 'Content marketing' }
    ]
  },
  {
    icon: '/images/services/analytics-icon.svg',
    title: 'Analytics',
    linetext: 'DS',
    desc: 'Reach out, say hello, and communicate with your audience. The right audience. Using digital strategies from website to social media, you can effectively capture your audiences, encourage shares, and foster organic brand growth.',
    usefulLink: [
      { link: '#', linktext: 'Marketing Technology Implementation' },
      { link: '#', linktext: 'Adobe Suite Product Audits' },
      { link: '#', linktext: 'Reporting Dashboards' },
      { link: '#', linktext: 'KPI Strategy Workshops' },
      { link: '#', linktext: 'A/B Testing' },
      { link: '#', linktext: 'Mobile App Reporting' }
    ]
  },
  {
    icon: '/images/services/shopping-icon.svg',
    title: 'Security',
    linetext: 'DS',
    desc: 'Reach out, say hello, and communicate with your audience. The right audience. Using digital strategies from website to social media, you can effectively capture your audiences, encourage shares, and foster organic brand growth.',
    usefulLink: [
      { link: '#', linktext: 'Vulnerability & Penetration Testing' },
      { link: '#', linktext: 'Web Application Testing' },
      { link: '#', linktext: 'Mobile App Security Testing' },
      { link: '#', linktext: 'Code Review' }
    ]
  }
];