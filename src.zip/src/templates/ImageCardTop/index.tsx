import React from "react";

interface CardTopProps extends React.HTMLAttributes<HTMLDivElement> {}

export const ImageCardTop: React.FC<CardTopProps> = ({ children, ...rest }) => {
  return (
    <div>
      <div {...rest}>{children}</div>
    </div>
  );
};

export const ImageCardGrid: React.FC<CardTopProps> = ({
  children,
  ...rest
}) => {
  return (
    <div>
      <div className="InnerCardRow" {...rest}>
        {children}
      </div>
    </div>
  );
};
