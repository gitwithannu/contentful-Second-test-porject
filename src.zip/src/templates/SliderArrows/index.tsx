import React from "react";

interface SliderArrows {
  NextSlideArrow?: any;
  PrevSlideArrow?: any;
}

function SliderArrows({ NextSlideArrow, PrevSlideArrow }: SliderArrows) {
  return (
    <div className="container learnMoreButtonOuter">
      <div className="row">
        <div className="col-5">
          <div className="sliderArrows">
            {NextSlideArrow}
            {PrevSlideArrow}
          </div>
        </div>
      </div>
    </div>
  );
}

export default SliderArrows;
