import React from "react";

interface BlowSingleprops extends React.HTMLAttributes<HTMLDivElement> {
  customClass?: string
}

const BlowSingleBanner: React.FC<BlowSingleprops> = ({ children, customClass, ...rest }) => {
  return (
    <div>
      <section className={`blowSingleBannerPin ${customClass}`}>
        <div className="blowInnerBanner paddingY128 dark">
          <div className="grpahicStrokesLeft">
            <svg
              width="308"
              height="733"
              viewBox="0 0 308 733"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <mask id="path-1-inside-1_38_19" fill="white">
                <path d="M-13.5 205C56.6498 205 123.926 232.814 173.53 282.324C223.133 331.833 251 398.983 251 469C251 539.017 223.133 606.167 173.53 655.676C123.926 705.186 56.6498 733 -13.5 733L-13.5 469L-13.5 205Z" />
              </mask>
              <path
                d="M-13.5 205C56.6498 205 123.926 232.814 173.53 282.324C223.133 331.833 251 398.983 251 469C251 539.017 223.133 606.167 173.53 655.676C123.926 705.186 56.6498 733 -13.5 733L-13.5 469L-13.5 205Z"
                stroke="#00A5D0"
                strokeWidth="2"
                mask="url(#path-1-inside-1_38_19)"
              />
              <path
                d="M307.5 306.489C139.643 302.618 4.30539 167.295 0.511026 -0.5H154.749C158.428 82.1866 224.794 148.569 307.5 152.321V306.489Z"
                stroke="#00A5D0"
              />
            </svg>
          </div>
          {children}
          <div className="grpahicStrokesRight">
            <svg
              width="251"
              height="251"
              viewBox="0 0 251 251"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <mask id="path-1-inside-1_38_13" fill="white">
                <path d="M-1.09716e-05 251C-1.20201e-05 218.038 6.47936 185.399 19.0682 154.946C31.657 124.494 50.1087 96.8237 73.3697 73.5162C96.6308 50.2087 124.246 31.7201 154.638 19.1062C185.03 6.49229 217.604 -1.5275e-05 250.5 -1.09497e-05L250.5 251L-1.09716e-05 251Z" />
              </mask>
              <path
                d="M-1.09716e-05 251C-1.20201e-05 218.038 6.47936 185.399 19.0682 154.946C31.657 124.494 50.1087 96.8237 73.3697 73.5162C96.6308 50.2087 124.246 31.7201 154.638 19.1062C185.03 6.49229 217.604 -1.5275e-05 250.5 -1.09497e-05L250.5 251L-1.09716e-05 251Z"
                stroke="#00A5D0"
                strokeWidth="2"
                mask="url(#path-1-inside-1_38_13)"
              />
            </svg>
          </div>
        </div>
      </section>
    </div>
  );
};

export default BlowSingleBanner;
