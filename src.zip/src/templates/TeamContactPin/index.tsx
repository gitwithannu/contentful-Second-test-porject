import React from "react";

interface TeamContactPinProps extends React.HTMLAttributes<HTMLDivElement> {}

const TeamContactPin: React.FC<TeamContactPinProps> = ({
  children,
  ...rest
}) => {
  return (
    <div>
      <section className="teamContectPin" {...rest}>
        {children}
      </section>
    </div>
  );
};

export default TeamContactPin;
