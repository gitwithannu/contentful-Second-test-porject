export const ContactForm = () => {
    const env = `${process.env.NEXT_PUBLIC_ENV_TYPE}`;
    let htmlContent = "";
    if (env == "PROD") {
         htmlContent = `<script type="text/javascript" src="https://promobullitstores.formstack.com/forms/js.php/tru_contact_us"></script><noscript><a href="https://promobullitstores.formstack.com/forms/tru_contact_us" title="Online Form">Online Form - Tru - Contact Us </a></noscript><div style="text-align:right; font-size:x-small;"><a href="http://www.formstack.com?utm_source=jsembed&utm_medium=product&utm_campaign=product+branding&fa=h,5339474" title="Powered by Formstack">Powered by Formstack</a></div>`
    } else  {
         htmlContent = `<script type="text/javascript" src="https://promobullitstores.formstack.com/forms/js.php/tru_contact_us_devstg"></script><noscript><a href="https://promobullitstores.formstack.com/forms/tru_contact_us_devstg" title="Online Form">Online Form - Tru - Contact Us  - dev/stg</a></noscript>`
   }
    return <>
        <div className="contact-form-reset" dangerouslySetInnerHTML={{ __html: htmlContent }} /> 
    </>
}