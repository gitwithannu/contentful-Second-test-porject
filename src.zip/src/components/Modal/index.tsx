import Link from "next/link";
import React, { useEffect, useState } from "react";
import Image from "next/image";
import parse from "html-react-parser";
import { createPortal } from "react-dom"
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))

interface ModalProps {
  HeaderLogo?: any;
}
export const Modal = ({ showModal, toggle, modalData = '' }: any) => {
  let modalDescription = modalData?.description
  if (modalDescription) {
    modalDescription= modalData?.description
  } else {
    modalDescription = ''
  }
  let image = "";
  let buttonText = "";
  let buttonUrl = "";
  let description = "";
  let enableButton = false;
  if (modalData) {
    let finalData = JSON.parse(modalData)
    image = finalData[0].image;
    buttonText = finalData[0].buttonText;
    buttonUrl = finalData[0].buttonUrl;
    description = finalData[0].description;
    enableButton = finalData[0].enableButton;
  }

  const closeModal = (e: { preventDefault: () => void; }) => {
    e.preventDefault()
    toggle(false)
  }

  return (
    <div>
  {showModal && createPortal(
        <div className="ModalPanel">
          <div className="modalCover">
            <div className="container modalInnerPanel">
              <div className="modalHeader">
              {image?  <Image
                  src={image? image :""}
                  alt="Sobeys"
                  width={120}
                  height={50}
                  loading ="lazy"
                ></Image> :""}
                
              </div>
              <div className="modayBody">
                    <div className="DataBlock">
                      {description ? parse(description) : ""}
                    </div>
              </div>
              <div className="modalFooter">
           <div className="learnMoreButton">
           {enableButton &&  <Link
                href={buttonUrl ? buttonUrl : "#"}
                aria-label=" See the full client project"
                className="globalButton withCircle"
              >
                {buttonText ? buttonText : "See the full client project"}
                    
              </Link>
            }
            </div>
            
                <div className="learnMoreButton">
                  <button className="globalButton" aria-label="close" onClick={(e) => closeModal(e)}>
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      , document.body)}
    </div>
  );
};
