import { FC } from "react";
interface YoutubeProps {
     title?:string
     src?: string;
   }
   
export const YouTubeVideo: FC<YoutubeProps> = ({ src, title }) => {
     const videoId = src;
     return (
         <div className="youtube-video">
             <iframe
                 src={`https://www.youtube.com/embed/${videoId}?autoplay=1&mute=1`}
                 title={title ? title : "Youtube Video"}
                 allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                 allowFullScreen
             ></iframe>
         </div>
     );
 };
 
 export default YouTubeVideo;
 