import Link from "next/link";
import React, { useRef, useEffect, useState, useContext, createContext } from "react";
import { useOnClickOutside } from '@/utils/hooks/useOnClickOutside';
import useWindowSize from '@/utils/hooks/useWindowSize';

// ContextApi Types
interface MyContextInterface {
  toggleShow: boolean;
  setToggleShow: (el: boolean) => void;
}

// Global Children Types
interface DropdownProps {
  children?: any;
}

interface DropdownToggle extends DropdownProps {
  link?: any;
  icon?: string;
  ariaLabel?: string;
}

// ContextApi defualt values
const ToggleContext = createContext<MyContextInterface>({
  toggleShow: false,
  setToggleShow: () => {},
});

// Dropdown Toggle Component
export const DropdownToggle: React.FC<DropdownToggle> = ({
  children,
  link,
  icon,
}) => {
  const { toggleShow, setToggleShow } = useContext(ToggleContext);

  return (
    <>
      <Link
        href={link}
        aria-expanded={toggleShow ? true : false}
        aria-label={children}
      >
        {children}
      </Link>
      <button onClick={() => setToggleShow(!toggleShow)}>
        <span className={`demo-icon ${icon}`}></span>
      </button>
    </>
  );
};

// Dropdown Menu Component
export const DropdownMenu: React.FC<DropdownProps> = ({ children }) => {
  const { toggleShow, setToggleShow } = useContext(ToggleContext);
  const menuRef = useRef<HTMLDivElement | any>(null);

  let active = 0;
  const handlerDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    event.preventDefault();
    if (toggleShow) {
      if (menuRef.current !== null) {
        if (
          event.keyCode == 9 &&
          active < (menuRef.current as HTMLDivElement).children.length - 1
        ) {
          active++;
          menuRef.current.children[active].focus();
        } else if (
          event.keyCode == 9 &&
          active == (menuRef.current as HTMLDivElement).children.length - 1
        ) {
          setToggleShow(!toggleShow);
        }

        // else if(event.keyCode == 38 && active > 0){
        //   active--;
        //   menuRef.current.children[active].focus();
        // }
      }
    }
  };

  useEffect(() => {
    if (toggleShow) {
      if (menuRef.current !== null) {
        menuRef.current.children[0].focus();
      }
    }
  }, [toggleShow]);

  return (
    <div>
      <div
        ref={menuRef}
        className="dropdown-menu"
        onKeyDown={(e) => handlerDown(e)}
      >
        {children}
      </div>
    </div>
  );
};

// Dropdowm Parent Component
export const Dropdown: React.FC<DropdownProps> = ({ children }) => {
  const dropdownRef = useRef(null);
  const [toggleShow, setToggleShow] = useState(false);
  // useOnClickOutside(dropdownRef, () => setToggleShow(false));
  const { width } = useWindowSize();

  return (
    <ToggleContext.Provider value={{ toggleShow, setToggleShow }}>
      <div
        ref={dropdownRef}
        className={`nav-item dropdown ${toggleShow ? "show" : "hide"}`}
      >
        {children}
      </div>
    </ToggleContext.Provider>
  );
};
