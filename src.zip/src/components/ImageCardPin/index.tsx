import Image from "next/image"
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
import { documentToHtmlString } from "@contentful/rich-text-html-renderer";
import parse from 'html-react-parser';
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))

export const ImageCardPin = (cardData: any) => {
const title = cardData?.cardData?.title;
  const desc = cardData?.cardData?.desc
  const cardDataAll = cardData?.cardData?.data;
  const halfMemebers = cardDataAll.length / 2
  const first = cardDataAll.slice(0,5)
  const last = cardDataAll.slice((cardDataAll.length - halfMemebers), cardDataAll.length);
  return <section className="ImageCardPin ImageSubCards socialMediaButterflies">
  <div className="ImageCard lightBackground paddingB128">
    <div className="ImageCardWraper ">
      <div className="container">
        <div className="ImageCardItem">
          <div className="row ImageCardItemRow ">
            <div className="col-6">
              <div className="ImageCardContact">
                <h5>{parse(title)}</h5>
                  {parse(desc)}
              </div>
            </div>
            <div className="col-6">
              <div className="ImageCardImage">
                  <ImageConversion
                    url={cardData?.cardData?.imageUrl}
                    altext={cardData?.cardData?.imageAlt}
                  />
                  
              </div>
            </div>
          </div>
          <div className="InnerCardRow cardStepRow informationList">
            <div className="row ImageCardItemRow mobCard">
               
               {first.map((data: any, key: any,index:number) => {
                    return <div className="col innerCardCol" key={key}>
                         <div className="InnerCardItem">
                              <span className="cardStepCounts"> Step {data?.icon} </span>
                              <p> {parse(data.desc)} </p>
                         </div>
                    </div>
               })
               }
               </div>
               <div className="row ImageCardItemRow mobCard">
               {last.reverse().map((data: any, key: any,index:number) => {
                    return <div className="col innerCardCol" key={key}>
                         <div className="InnerCardItem">
                              <span className="cardStepCounts"> Step {data?.icon} </span>
                              <p>{parse(data.desc)} </p>
                         </div>
                    </div>
               })
               }
          </div>
          
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
}
