import Image from "next/image";
import { useCallback, useEffect, useState } from "react";

export const DragCursor = () => {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const addEventListeners = useCallback(() => {
    document.addEventListener("mousemove", onMouseMove);
  }, []);

  const removeEventListeners = useCallback(() => {
    document.removeEventListener("mousemove", onMouseMove);
  }, []);

  const onMouseMove = (e: any) => {
    setPosition({ x: e.pageX, y: e.pageY });
  };
  useEffect(() => {
    addEventListeners();
    return () => removeEventListeners();
  }, [addEventListeners, removeEventListeners]);

  return (
    <div>
      <div
        style={{
          transform: `translate(${position.x}px, ${position.y}px)`,
        }}
        className="cursor"
      >
        <Image src="/images/home/Scroll.svg" fill loading ="lazy" alt="Drag Cursor" />
      </div>
    </div>
  );
};
