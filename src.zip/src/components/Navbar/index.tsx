import { FC, useState, createContext, useMemo, useContext, useEffect, useRef } from "react";
import Link from "next/link";
import Image from "next/image";
import { SearchBar } from "../Search";

import useWindowSize from '@/utils/hooks/useWindowSize';

interface GlobalProp {
  children?: React.ReactNode;
}
interface NavbarProp extends GlobalProp {
  expand?: string;
}
interface NavbarBrandProp extends GlobalProp {}
interface NavItemProp {
  children?: React.ReactNode;
  href?: string | any;
}
interface MyContextInterface {
  toggleShow: boolean;
  setToggleShow: (el: boolean) => void;
}

const ToggleContext = createContext<MyContextInterface>({
  toggleShow: false,
  setToggleShow: () => {},
});

export const Navbar: FC<NavbarProp> = ({ children, expand = "" }) => {
  const [toggleShow, setToggleShow] = useState(false);
  const contextValue = useMemo(() => ({toggleShow, setToggleShow}), [toggleShow]);
  return (
    <ToggleContext.Provider value={contextValue}>
      <nav className={`navbar ${expand}`} >{children}</nav>
    </ToggleContext.Provider>
  );
};

export const NavbarBrand: FC<NavbarBrandProp> = ({ children }) => {
  return (
    <Link href="/" className="navbar-brand">
      {children}
    </Link>
  );
};

export const NavbarToggle = () => {
  const { toggleShow, setToggleShow } = useContext(ToggleContext);
  useEffect(() => {
    let selectBody = document.querySelector("body");
    if (toggleShow) {
      //@ts-ignore
      selectBody.classList.add("hideScroll");
    } else {
      //@ts-ignore
      selectBody.classList.remove("hideScroll");
    }
  }, [toggleShow]);

  return (
    
    <div className="navbar-toggle">
      <SearchBar />
      <button
        onClick={() => setToggleShow(!toggleShow)}
        className="navbar-toggle-icon"
        type="button"
      > 
        <Image src="/images/mobile-menu.svg" alt="Mobile Menu" width={48} height={48} loading ="lazy" />
       
      </button>
    </div>
  );
};

export const NavbarClose = () => {
  const { toggleShow, setToggleShow } = useContext(ToggleContext);
  return (
    <div className="navbar-close">
      <button onClick={() => setToggleShow(!toggleShow)} type="button">
        <span className="demo-icon icon-cancel"></span>
      </button>
    </div>
  );
};

export const NavbarCollapse: FC<GlobalProp> = ({ children }) => {
  const myRef = useRef<HTMLDivElement>(null);
  const { toggleShow, setToggleShow } = useContext(ToggleContext);
  const { width } = useWindowSize();

  useEffect(() => {
    const handleClick = () => {
      setToggleShow(!toggleShow);
    };

    //@ts-ignore
    const aTags = myRef.current.querySelectorAll('a');
    if(width < 1199){
      aTags.forEach((aTag:any) => {
        aTag.addEventListener('click', handleClick);
      });
    }

    return () => {
      aTags.forEach((aTag:any) => {
        aTag.removeEventListener('click', handleClick);
      });
    };
  }, [setToggleShow, toggleShow, width]);

  return (
    <div className={`navbar-collapse ${toggleShow ? "show" : "hide"}`} ref={myRef}>
      {children}
    </div>
  );
};

export const NavItem: FC<NavItemProp> = ({ children, href }) => {
  const { toggleShow, setToggleShow } = useContext(ToggleContext);
  return (
    <Link
      href={href}
      onClick={() => setToggleShow(!toggleShow)}
      className={`sdfsd`}
      aria-label="click here for show menu"
    >
      {children}
    </Link>
  );
};
