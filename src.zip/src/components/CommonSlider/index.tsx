import React from "react";
import Slider, { Settings } from "react-slick";
import "slick-carousel/slick/slick.css";
// import "slick-carousel/slick/slick-theme.css";

interface SocialSliderProps extends React.HTMLAttributes<HTMLDivElement> {
  settings?: Settings;
  children?: any;
}
function SlickNextArrow(props: any) {
  const { onClick } = props;
  return (
    <div className="sliderArrows">
      <button className="sliderRightArrow" onClick={onClick}>
        <span className="demo-icon icon-right-arrow-1"></span>
      </button>
    </div>
  );
}

function SlickPrevArrow(props: any) {
  const { onClick } = props;
  return (
    <div className="sliderArrows leftArrow">
      <button className="sliderLeftArrowProduct" onClick={onClick}>
        <span className="demo-icon icon-left-arrow"></span>
      </button>
    </div>
  );
}
const SocialSlider: React.FC<SocialSliderProps> = ({
  children,
  settings,
  ...rest
}) => {
  const defaultSettings: Settings = {
    infinite: false,
    slidesToShow: 3.5,
    slidesToScroll: 1,
    dots: false,
    nextArrow: <SlickNextArrow />,
    prevArrow: <SlickPrevArrow />,
    responsive: [
      {
        breakpoint: 1199,
        settings: {
          slidesToShow: 2.5,
        },
      },
      {
        breakpoint: 767,
        settings: {
          slidesToShow: 1.7,
        },
      },
      {
        breakpoint: 575,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  };

  const sliderSettings = { ...defaultSettings, ...settings };

  return (
    //@ts-ignore
    <Slider {...sliderSettings} {...rest}>
      {children}
    </Slider>
  );
};

export default SocialSlider;
