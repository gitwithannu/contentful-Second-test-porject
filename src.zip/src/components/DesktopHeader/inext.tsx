import Link from "next/link";
import Image from "next/image";
import { nav, topnav } from "@/src/static";
import parse from 'html-react-parser';
import {
  Navbar,
  NavbarBrand,
  NavbarToggle,
  NavbarCollapse,
  NavbarClose,
  DropdownToggle,
  DropdownMenu,
  Dropdown,
} from "@/src/components";
import { SearchBar } from "../Search";
import { useEffect, useState } from "react";
import useWindowSize from '@/utils/hooks/useWindowSize';
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))

import Scrollbar from "smooth-scrollbar";
const DesktopHeader = ({ data, announcementData }: any) => {
  const nav = data?.topNavigationCollection?.items[0]?.navLinks
  const topnav = data?.topNavigationCollection?.items[0]?.topNav
  const desktopNav = data?.topNavigationCollection?.items[0]?.megaMenuDesktop
  const announcement = announcementData?.topAnnouncementHeaderCollection?.items[0];
  const desktopLogoRight =announcement?.desktopLogoRight
  const enableAnnouncement =announcement?.enableSection
  const mobileLogoRight =announcement?.mobileLogoRight
  const mobilePattern =announcement?.mobilePattern
  const desktopPatternLeft =announcement?.desktopPatternLeft
  const desktopPatternRight =announcement?.desktopPatternRight
  const listItems = announcement?.listItemsCollection?.items
  let defaultUrl = "https://images.ctfassets.net/";
  const desktopPatternLeftImage = desktopPatternLeft?.url.replace(defaultUrl, '/api/images/');
  const desktopPatternRightImage = desktopPatternRight?.url.replace(defaultUrl, '/api/images/');
  const mobilePatternImage = mobilePattern?.url.replace(defaultUrl, '/api/images/');
  const backgroundImageStyle = {
    backgroundImage: `url(${desktopPatternLeftImage}), url(${desktopPatternRightImage}), url(${mobilePatternImage})`,
    backgroundSize: 'contain',
    backgroundPosition: 'left center, right center',
    width: '100%',
    height: '60px', 
    backgroundRepeat:' no-repeat'
  };




  useEffect(() => {

    const topBar = document.querySelector('.topBar');
    const bodyElement = document.body;
    if (topBar && bodyElement) {
      bodyElement.classList.add('topBarPadding');
    }

    if(document.querySelectorAll(".slick-slide"))
        {   
            let slideAccess = document.querySelectorAll(".slick-slide");
            for (let i = 0; i < slideAccess.length; i++) {
                let element = slideAccess[i];
                element.setAttribute("aria-hidden", "false");

                element.removeAttribute("tabindex");
            }
        }
        if(document.querySelectorAll(".slick-cloned")){   
            let cloned = document.querySelectorAll(".slick-cloned");
            for (let i = 0; i < cloned.length; i++) {
                let element = cloned[i];
                element.setAttribute("aria-hidden", "false");
                element.removeAttribute("tabindex");
                element.removeAttribute("data-index");
            }
          let nextroute = document.querySelectorAll("#__next-route-announcer__");
            for (let i = 0; i < nextroute.length; i++) {
                let element = nextroute[i];
                element.setAttribute("aria-atomic", "true");
                element.removeAttribute("role");
          }
          let xinside = document.querySelectorAll(".slick-cloned a");
          for (let i = 0; i < xinside.length; i++) {
              let element = xinside[i];
              element.setAttribute("aria-hidden", "false");
              element.setAttribute("tabindex","-1");
              element.removeAttribute("data-index");
        }

            let xinsidere = document.querySelectorAll(".scroller,.slick-slide, .ourServiceCard, .slick-slide div");
            for (let i = 0; i < xinsidere.length; i++) {
                let element = xinsidere[i];
                element.removeAttribute("tabindex");
            }

        }
    const listener = (event: { code: string; keyCode: number }) => {
      if (event.code === "Tab") {
        document.querySelectorAll("a,button,nav,div").forEach((item) => {
          item.classList.add("tab");
          document.addEventListener("click", function () {
            item.classList.remove("tab");
          });
        });
      }

      if (event.keyCode === 27) {
        document.querySelectorAll("a,button,nav").forEach((item) => {
          item.classList.add("tab");
          document.addEventListener("click", function () {
            item.classList.remove("tab");
          });
        });
      }
    };
    document.addEventListener("keydown", listener);
    return () => {
      document.removeEventListener("keydown", listener);
    };
  }, []);

  const [shouldAddClass, setShouldAddClass] = useState(false);
const { width } = useWindowSize();
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 80) {
        setShouldAddClass(true);
      } else {
        setShouldAddClass(false);
      }
    };

    window.addEventListener('scroll', handleScroll);

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <>
      {enableAnnouncement &&
        <div className="topBar top-bar-desk" style={backgroundImageStyle}>
          <div>
            <ul>
              {listItems?.map((item: any, key: any) => (
                <li key={key}>
                  {item?.enableImage &&
                    <div className="top-bar-icon-m">
                      {item?.cardImage?.url && <ImageConversion
                          url={item?.cardImage?.url}
                          altext={item?.cardImage?.title}
                        />
                      }
                    </div>}
                  {item?.showTitle && <>{parse(item?.title)} </>}
                </li>
              ))}
            </ul>
          </div>
          <div className="top-bar-image">
            <div className="top-bar-left-icon">

              {desktopLogoRight?.url && <ImageConversion
                url={desktopLogoRight?.url}
                altext={desktopLogoRight?.title}
                className="desktop-view"
              />}
              {mobileLogoRight?.url && <ImageConversion
                url={mobileLogoRight?.url}
                altext={mobileLogoRight?.title}
                className="mobile-view"
              />
              }
            </div>
          </div>
        </div>
      }
      <header className={`site-header ${shouldAddClass ? 'my-div-class' : ''}`} role="banner">
      <div className="nav top-nav">
        <Link href="mailto:support@tru.agency">support@tru.agency</Link>
        <ul className="dFlex">
          {topnav?.map((item: any, key: any) => (
            <li key={item?.icon}>
              <Link href={item?.link} aria-label={item?.arialabel} target={item?.target ? item?.target : "_self"}>
                <span className={`demo-icon ${item?.icon}`}></span>
              </Link>
            </li>
          ))}
        </ul>
        </div>
        {enableAnnouncement &&
          <div className="topBar top-bar-mob" style={backgroundImageStyle}>
            <div>
              <ul>
                {listItems?.map((item: any, key: any) => (
                  <li key={key}>
                    {item?.enableImage &&
                      <div className="top-bar-icon-m">
                        {item?.cardImage?.url && <ImageConversion
                          url={item?.cardImage?.url}
                          altext={item?.cardImage?.title}
                        />
                      }
                      </div>}
                    {item?.showTitle && <>{parse(item?.title)} </>}
                  </li>
                ))}
              </ul>
            </div>
            <div className="top-bar-image">
              <div className="top-bar-left-icon">

                {desktopLogoRight?.url && <ImageConversion
                  url={desktopLogoRight?.url}
                  altext={desktopLogoRight?.title}
                  className="desktop-view"
                />}
                {mobileLogoRight?.url && <ImageConversion
                  url={mobileLogoRight?.url}
                  altext={mobileLogoRight?.title}
                  className="mobile-view"
                />
                }
              </div>
            </div>
          </div>
        }
      <Navbar expand="xl">
        <NavbarBrand>
          <span className="navbar-logo">
            <Image src="/images/logo.svg" fill priority alt="Tru logo" />
          </span>
          <span className="navbar-text">
            Tru <span></span> Innovation Starts Here
          </span>
        </NavbarBrand>
        <NavbarToggle />
        <NavbarCollapse>
          <div className="mobile-header">
            <NavbarClose />
          </div>
          <div className="mobile-graphic">
            <svg
              width="930"
              height="348"
              viewBox="0 0 930 348"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <circle
                opacity="0.5"
                cx="173.5"
                cy="174.5"
                r="173"
                stroke="#00A5D0" />
              <g opacity="0.5">
                <mask id="path-2-inside-1_39_16" fill="white">
                  <path d="M347 0H930V347H347V0Z" />
                </mask>
                <path
                  d="M347 0V-1H346V0H347ZM347 347H346V348H347V347ZM347 1H930V-1H347V1ZM930 346H347V348H930V346ZM348 347V0H346V347H348Z"
                  fill="#00A5D0"
                  mask="url(#path-2-inside-1_39_16)" />
              </g>
              <path
                opacity="0.5"
                d="M693.5 346.489C504.303 342.16 351.754 189.627 347.511 0.5H521.405C525.519 93.6721 600.306 168.477 693.5 172.674V346.489Z"
                stroke="#00A5D0" />
            </svg>
          </div>
          <ul className="nav">
            {width > 1199 && (desktopNav?.length > 0 &&
              desktopNav?.map((items: any, key: number) => (
                items?.isDropdown?.length > 0 ?
                  (
                    //@ts-ignore
                    <li key={items?.title} className={`${!items?.megaMenu && 'single-dropdown'} ${items?.isDropdown?.length > 0 && 'MegaDropDown-outer'}`}>
                      <Link href={items?.url} aria-label={items?.title} className="with--arrow">
                        {items?.title}
                        <span className="demo-icon icon-down-arrow"></span>
                      </Link>

                      {items?.megaMenu ? <div className="megaMenuOuter" key={key}>
                        {items?.megaMenu && <div className="megaMenuheading">
                          <h5 className="megaMenutitle">{items?.title}</h5>
                        </div>}
                        <div className={`megaMenuinner ${items?.column == '4' && 'ourProducts'}`}>
                          {items.isDropdown.map((el: any, key: any) => {
                            return (
                              items?.megaMenuButtons == undefined ?
                                <div className="megaMenuCol" key={key}>
                                  {items?.megaMenu && <div className="megaMenuiconBox">
                                    <div className="megaMenuicon">
                                      {el?.image && <Image src={el?.image} alt={el?.title} fill priority />}
                                    </div>
                                  </div>}
                                  <div className="megaMenuItemHeading">
                                    <h5 className="megaMenuItemTitle">{el?.title}</h5>
                                  </div>
                                  <ul className="megaMenulist">
                                    {el?.dropdown?.map((listItem: any, key: any) => {
                                      return <li key={key}><Link href={listItem?.url} aria-label={listItem?.title} target={listItem?.target ? listItem?.target : "_self"}>{listItem?.title}</Link></li>;
                                    })}
                                  </ul>
                                </div> :
                                <div className="megaMenuCol" key={key}>
                                  <div className="megaMenuContent">
                                    {items?.megaMenu && <div className="megaMenuiconBox">
                                      <div className="megaMenuicon">
                                        {el?.image && <Image src={el?.image} alt={el?.title} fill priority />}
                                      </div>
                                    </div>}
                                    <div className="megaMenuItemHeading">
                                      <h5 className="megaMenuItemTitle">{el?.title}</h5>
                                    </div>
                                    <div className="megaMenuDes">
                                      <p>{el?.description}</p>
                                    </div>
                                  </div>
                                  <div className="megaMenuLink">
                                    <Link href={el?.url} aria-label={el?.title} target={el?.target ? el?.target : "_self"}>Learn More  <Image src="/images/menu/menu-arrow-right.svg" alt="menu-arrow" width={14} height={16} /> </Link>
                                  </div>
                                </div>
                            );
                          })}
                        </div>
                      </div> :
                        <div className="megaMenuOuter megaMenu-single">
                          {items.isDropdown.map((el: any, key: any) => (
                            <Link key={key} href={el?.url} target={el?.target ? el?.target : "_self"}>{el?.title}</Link>
                          ))}
                        </div>}
                    </li>
                  )
                  :
                  <li key={items?.title}><Link href={items?.url} aria-label={items?.title}>{items?.title}</Link></li>
              )))}

            {width < 1200 && (nav?.length > 0 &&
              nav?.map((items: any, key: number) => (
                <li key={items?.title}>
                  {items?.isDropdown?.length > 0 ? (
                    <Dropdown>
                      <DropdownToggle icon="icon-down-arrow" link={items?.url}>
                        {items?.title}
                      </DropdownToggle>
                      <DropdownMenu>
                        {items.isDropdown.map((el: any, key: any) => (
                          <Link href={el?.url} key={el?.title} aria-label={el?.title} target={el?.target ? el?.target : "_self"}>
                            {el?.title}
                          </Link>
                        ))}
                      </DropdownMenu>
                    </Dropdown>
                  ) : (
                    <Link href={items?.url} aria-label={items?.title}>
                      {items?.title}
                    </Link>
                  )}
                </li>
              )))}
          </ul>
        </NavbarCollapse>
        <div className="navbar-right">
          <SearchBar />
          <Link
            href="/contact-us"
            className="startProject globalButton"
            aria-label="Start a Project"
          >
            Start a Project
          </Link>
        </div>
      </Navbar>
    </header></>
  );
};

export default DesktopHeader;