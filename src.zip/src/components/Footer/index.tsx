import React from "react";
import Image from "next/image";
import Link from "next/link";
import parse from 'html-react-parser';
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))

const Footer = (navData: any) => {
  const footerNav = navData?.navData?.footerCollection?.items
  const filtered = footerNav?.filter((singleData: any) => {
    return singleData.tag === "footer";
  });

  const year = new Date().getFullYear();
  return filtered?.map((section: any, index: any) => {
  const quickLinks = section?.quickLinks;
  const quickLinksHeading = section?.quickLinkHeading;
  const bottomFooterLinks = section?.bottomFooterLinks;
  const footerIcon = section?.footerIcon?.url;
  const footerIconAlt = section?.footerIcon?.title;
  const supportEmailFooter = section?.supportEmailFooter;
  return (
    <footer className="footerMain" key={index}>
      <div className="container">
        <div className="row">
          <div className="col-4 footerLeftCol">
            <div className="footerLeft">
              <div className="footerLogo">
                <Link href="/" aria-label="click here to go back on Home Page">
                {footerIcon && <ImageConversion
                        url={ footerIcon}
                        altext={footerIconAlt}
                  />
                }
                </Link>
              </div>
              <div className="connect">
                <p>Connect:</p>
                <ul>
                  <li>
                    <Link href="https://www.facebook.com/truincorp/" target="_blank" aria-label="An image of facebook">
                      <span className="demo-icon icon-facebook"></span>
                    </Link>
                  </li>
                  <li>
                    <Link href="https://twitter.com/Tru_Inc" target="_blank" aria-label="An image of twitter">
                      <span className="demo-icon icon-twitter-1"></span>
                    </Link>
                  </li>
                  <li>
                    <Link href="https://www.instagram.com/tru_inc/" target="_blank" aria-label="An image of instagram">
                      <span className="demo-icon icon-instagram"></span>
                    </Link>
                  </li>
                  <li>
                    <Link href="https://www.linkedin.com/company/truinc" target="_blank" aria-label="An image of linkedin">
                      <span className="demo-icon icon-linkedin-logo-svgrepo-com-1"></span>
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="col-8 footerRightCol">
            <div className="footerRight">
              <div className="row">
                <div className="col-12">
                  <div className="quicklinks">
                    <span className="footerSmallHead">{quickLinksHeading}</span>
                    <ul className="footerNavItems">
                      {quickLinks?.map((item:any, key:number) => (
                        <li key={key}>
                        <Link href={item?.link} aria-label={item?.arialabel} target={item?.target ? item?.target: "_self"}>
                        {item.title}
                        </Link>
                      </li>
                       ))}
                    </ul>
                    {supportEmailFooter ?
                      <Link
                        href={`mailto: ${supportEmailFooter}`}
                        target="_blank"
                        aria-label="support@tru.agency"
                        className="truEmail"
                      >
                        
                        {supportEmailFooter}
                      </Link>
                      : ""}
                  </div>
                </div>
              </div>
              <div className="copyrightWrap">
                <div className="row">
                  <div className="col-4 fullWidthLgMd">
                    <div className="copyright">© {year} Tru Inc.</div>
                  </div>
                  <div className="col-8 fullWidthLgMd">
                    <div className="policyPages">
                      <ul>
                      {bottomFooterLinks?.map((item:any, key:number) => (
                        <li key={key}>
                        <Link href={item?.link} aria-label={item?.arialabel} target={item?.target ? item?.target: "_self"}>
                          {item.title}
                        </Link>
                      </li>
                       ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
});
};

export default Footer;

