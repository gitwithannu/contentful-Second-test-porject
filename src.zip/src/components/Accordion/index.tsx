import React, { FC, useEffect, useState, useContext, createContext, useRef } from 'react';

const AccordionContext = createContext<{
    collapse: boolean,
    setCollapse: (args: any) => void;
} | null>(null);

interface AccordionWrapperProps {
    children?: React.ReactNode,
    className?: string;
    customIndex?: number |undefined;
}

export const AccordionHeader: FC<AccordionWrapperProps> = ({ children }) => {
    const { collapse, setCollapse } = useContext<any>(AccordionContext);
    return (
        <div className="accordion--wrapper--header">
            <button 
                onClick={() => setCollapse(!collapse)}
                aria-expanded={collapse ? true : false}
            >
                {children} {
                    collapse ? 
                    <span className="accordion--button">
                        <svg xmlns="http://www.w3.org/2000/svg" width="21" height="24" viewBox="0 0 21 24" fill="none">
                            <path d="M20.25 12C20.25 12.6234 19.7484 13.125 19.125 13.125H1.875C1.25156 13.125 0.75 12.6234 0.75 12C0.75 11.3766 1.25156 10.875 1.875 10.875H19.125C19.7484 10.875 20.25 11.3766 20.25 12Z" fill="#051D3A"/>
                    </svg>
                    </span> 
                    : 
                    <span className="accordion--button">
                        <svg xmlns="http://www.w3.org/2000/svg" width="21" height="24" viewBox="0 0 21 24" fill="none">
                            <path d="M11.625 3.375C11.625 2.75156 11.1234 2.25 10.5 2.25C9.87656 2.25 9.375 2.75156 9.375 3.375V10.875H1.875C1.25156 10.875 0.75 11.3766 0.75 12C0.75 12.6234 1.25156 13.125 1.875 13.125H9.375V20.625C9.375 21.2484 9.87656 21.75 10.5 21.75C11.1234 21.75 11.625 21.2484 11.625 20.625V13.125H19.125C19.7484 13.125 20.25 12.6234 20.25 12C20.25 11.3766 19.7484 10.875 19.125 10.875H11.625V3.375Z" fill="#051D3A"/>
                        </svg>
                    </span>
                }
            </button>
        </div>
    );
}

export const AccordionPanel: FC<AccordionWrapperProps> = ({ children }) => {
    const panelRef = useRef<HTMLDivElement>(null);
    const ctx = useContext(AccordionContext);

    useEffect(() => {
        if (!ctx?.collapse && panelRef.current) {
            panelRef.current.style.height = `0px`;
        } else if (panelRef.current) {
            panelRef.current.style.height = `${panelRef.current.scrollHeight}px`;
        }
    }, [ctx?.collapse]);

    return (
        <div ref={panelRef} className="accordion--wrapper--content">
            <div className="accordion--wrapper--content--body">
                {children}
            </div>
        </div>
    );
}

export const Accordion: FC<AccordionWrapperProps & { customIndex: number }> = ({ children, customIndex }) => {
    const [collapse, setCollapse] = useState(customIndex === 0);

    return (
        <AccordionContext.Provider value={{ collapse, setCollapse }}>
            <div className={`accordion--wrapper ${collapse ? 'show' : ''}`}>{children}</div>
        </AccordionContext.Provider>
    );
}

export const AccordionWrapper: FC<AccordionWrapperProps> = ({ children, className }) => {
    return <div className={`accordian ${className}`}>{children}</div>
}