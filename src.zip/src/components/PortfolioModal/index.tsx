import Link from "next/link";
import React, { useEffect, useState } from "react";
import Image from "next/image";
import parse from "html-react-parser";
import {createPortal} from "react-dom"
interface ModalProps {
  HeaderLogo?: any;
}
export const PortfolioModal = ({ showModal, toggle, modalData = '' }: any) => {
  let modalDescription = modalData
  if (modalDescription) {
    modalDescription= modalData
  } else {
    modalDescription = ''
  }
  

  const closeModal = (e: { preventDefault: () => void; }) => {
    e.preventDefault()
    toggle(false)
  }

  return (
    <div>

  {showModal && createPortal(
        <div className="ModalPanel">
          <div className="modalCover">
            <div className="container modalInnerPanel">
             
              <div className="modayBody">
                    <div className="DataBlock">
                      {modalDescription ? parse(modalDescription) : ""}
                    </div>
              </div>
              <div className="modalFooter">
            
                <div className="learnMoreButton">
                  <button className="globalButton" aria-label="close" onClick={(e) => closeModal(e)}>
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      , document.body)}
    </div>
  );
};
