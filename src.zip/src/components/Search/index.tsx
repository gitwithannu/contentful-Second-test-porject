import { FC, useState, useRef } from "react";
import Link from "next/link";
import { useRouter } from "next/router";

interface SearchProps {
  className?: string;
  animate?: boolean;
  src?: string;
  onClick?: string;
  messageid?: any;
}

export const SearchBar: FC<SearchProps> = ({ messageid }) => {
  const searchRef = useRef<HTMLInputElement>(null);
  const router = useRouter();
  const [showMe, setShowMe] = useState(false);
  const [message, setMessage] = useState("");

  const toggle = () => {
    searchRef?.current?.focus();
    setShowMe(!showMe);
  };

  const handleSubmit = (event: { preventDefault: () => void }) => {
    event.preventDefault();
    setShowMe(false);
    router.push({
      pathname: '/search',
      query: { s: message }
    });
  };

  const handleChange = (event: { target: { value: any } }) => {
    setMessage(event.target.value);
  };

  const handleClick = () => {
    // 👇️ clear input value
    setMessage("");
    searchRef?.current?.focus();
  };

  return (
    <div className="SearchPopPanel">
      <button
        className="search"
        onClick={toggle}
        aria-label="Search here"
      >
        <span className="demo-icon icon-search-1"></span>
      </button>
      <div className={`innerSearchBox ${showMe ? "active" : ""}`}>
        <div className="container">
          <div className="SearchLeftPanel">
            <form onSubmit={handleSubmit}>
              <input
                type="text"
                autoFocus
                id={messageid}
                name="message"
                placeholder="Type your keyword here..."
                onChange={handleChange}
                value={message}
                ref={searchRef}
              ></input>
              <button className="searchButton">
                <span className="demo-icon icon-search-1"></span>
              </button>
            </form>
          </div>

          <div className="SearchRightPanel">
            {message && <button
              onClick={handleClick}
              aria-label="click here for clear data"
            >
              Clear
            </button>}
            <button onClick={toggle}  aria-label="click here for search">
              <span className="demo-icon icon-cross"></span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
