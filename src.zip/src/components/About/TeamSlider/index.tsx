import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import gsap from "gsap";
import { useRef } from "react";
import Image from "next/image";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
const AboutTeamSlider = ({ teamMembers }: any) => {
  const members = JSON.parse(teamMembers);
  const halfMemebers = members.length / 2
  const first = members.slice(0, halfMemebers);
  const last = members.slice((members.length - halfMemebers), members.length);
  const teamSliderRef = useRef<HTMLDivElement>(null);
  // useIsomorphicLayoutEffect(() => {
  //   let ctx = gsap.context(() => {
  //     setTimeout(() => {
  //     //TeamSlider
  //     gsap.set(".whoWeAreSliderRowOne", { xPercent: -73 });
  //     gsap.set(".whoWeAreSliderRowTwo", { xPercent: 73 });

  //     const teamSlideTl = gsap.timeline({});

  //     ScrollTrigger.create({
  //       animation: teamSlideTl,
  //       trigger: teamSliderRef.current,
  //       start: "top top",
  //       end: "+=1500px",
  //       pin: teamSliderRef.current,
  //       scrub: true,
  //     });

  //     teamSlideTl
  //       .to(".whoWeAreSliderRowOne", { xPercent: 73, duration: 100 })
  //       .to(".whoWeAreSliderRowTwo", { xPercent: -70, duration: 100 }, "<");

  //     let mm = gsap.matchMedia();
      
  //     mm.add("(max-width: 767.98px) and (min-width: 300.98px)", () => {
  //       gsap.set(".whoWeAreSliderRowOne", { xPercent: -240, });
  //       gsap.set(".whoWeAreSliderRowTwo", { xPercent: 243 });

  //       teamSlideTl
  //         .to(".whoWeAreSliderRowOne", {
  //           xPercent: 73,
  //           duration: 100,
  //           yPercent:0
  //         })
  //         .to(".whoWeAreSliderRowTwo", { xPercent: -70, duration: 100 }, "<");
  //     });
  //     }, 3000);
  //   }, teamSliderRef);

  //   return () => ctx.revert();
  // }, []);

  return (
    <div>
      <section className="teamSlider--pin" ref={teamSliderRef}>
        <div className="whoWeAreSliderMain">
          <div className="whoWeAreSlider ">
            <div className="whoWeAreSliderCard whoWeAreSliderRowOne dFlex ">
              {
                
                first.map((data: any, index: any) => {
              
                let customClassName ='';
                if (index % 2 === 0) {
                  customClassName = "roundTop";
                } else if (index % 3 === 0) {
                  customClassName = "circle";
                } else if (index % 4 === 0) {
                  customClassName = "roundLeft"
                } 
                return <div className="teamCard" key={index}>
                        <div className={"profileImage "+customClassName }>
                          <Image src={data?.cardImage?.url} alt={data?.cardImage?.title} fill loading="lazy" />
                        </div>
                        <div className="profileContent">
                        <h4>{data?.title}</h4>
                        <p>{documentToPlainTextString(data?.description?.json)}</p>
                        </div>
                      </div>
               })
              }
            </div>
            <div className="whoWeAreSliderCard whoWeAreSliderRowTwo dFlex">
            {
                last.map((data: any, index: any) => {
                let customClassName ='';
                if (index % 2 === 0) {
                  customClassName = "roundTop";
                } else if (index % 3 === 0) {
                  customClassName = "circle";
                } else if (index % 4 === 0) {
                  customClassName = "roundLeft"
                } 
                return <div className="teamCard" key={index}>
                        <div className={"profileImage "+customClassName }>
                          <Image src={data?.cardImage?.url} alt={data?.cardImage?.title} fill loading ="lazy" />
                        </div>
                        <div className="profileContent">
                        <h4>{data?.title}</h4>
                        <p>{documentToPlainTextString(data?.description?.json)}</p>
                        </div>
                      </div>
               })
              }
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
export default AboutTeamSlider;
