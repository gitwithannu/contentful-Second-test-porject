import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import gsap from "gsap";
import { useRef } from "react";
import Image from "next/image";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import Link from "next/link";
import parse from "html-react-parser";
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))

const CreatorTeam = ({ title, description, gridImages, buttonText, buttonUrl }: any) => {
  const creatorTeamRef = useRef<HTMLDivElement>(null);
  const gridLoop = JSON.parse(gridImages);
  const cardImage = "images/our-services.svg";
  const cardImage2 = "images/our-product.svg";
  const cardImage3 = "images/our-partners.svg";
  const chitChat = "images/chit-chat.svg";
  const idea = "images/idea.svg";
  const quality = "images/star-icon.svg";
  const timeTable = "images/time-table.svg";
  return (
    <div>
      <section className="creatorTeam paddingB128" ref={creatorTeamRef} role="region">
        <div className="blueCircle">
          <Image
            src="/images/bottomGradient.png"
            alt="bottomOrangeBlueradient"
            fill
            loading ="lazy"
          />
        </div>

        <div className="container">
          <div className="row">            
            <div className="col-12 col-12-sm">
              <div className="career" ref={creatorTeamRef}>
              <h2>{title}</h2>
              {parse(description)}
                <div className="learnMoreButton">
                  <Link
                    href={buttonUrl ? buttonUrl : "#"}
                    className="globalButton withCircle"
                    aria-label="Click here to See available opportunities"
                  >
                    {buttonText ? buttonText : "See available opportunities"}
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="services-page-cards paddingT128">
          <div className="container">
            <div className="row">
              {
                gridLoop.map((data: any, index: any) => {
                  return (<div className="col-4" key={data+index}>
                    <div className="service-pages-card">
                      <div className="service-card-icon-outer">
                        <div className="service-card-icon">
                        <ImageConversion
                          url={data?.cardImage?.url}
                          altext={data?.cardImage?.title}
                          height={64}
                          width={64}
                          />
                        </div>
                      </div>
                      {data?.title && <Link
                    href={data.buttonUrl ? data?.buttonUrl :"#"}
                    aria-label={data?.title}
                    target="_self"
                  ><h4>{data.title}</h4></Link>}
                    </div>
                  </div>)
                })
              }
              
            </div>
          </div>
        </div>
      </section>
     
    </div>
  );
};
export default CreatorTeam;
