import Image from 'next/image';
import { useRef } from 'react';
import Link from 'next/link';
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))

const cardImage = "images/our-services.svg";
const cardImage2 = "images/our-product.svg";
const cardImage3 = "images/our-partners.svg";
const chitChat = "images/chit-chat.svg";
const idea = "images/idea.svg";
const quality = "images/star-icon.svg";
const timeTable = "images/time-table.svg";

export const WhatWeValue = ({title, columnData}:any) => {
  const whatWeValueRef = useRef<HTMLDivElement>(null);
  const colData = JSON.parse(columnData);
  let timer: string | number | NodeJS.Timeout | undefined;
  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      timer = setTimeout(() => {
        const whatWeValueTl = gsap.timeline({});
        ScrollTrigger.create({
            animation: whatWeValueTl,
            trigger: whatWeValueRef.current,
            start: "top 90%",
            end: "+=1000",
            scrub: true,
            onToggle: scrollTrigger => {
              scrollTrigger.refresh()
            },
          });

        gsap.set('.whatWeValueHeading', { yPercent: 120, opacity: 0 }); 
        gsap.set('.whatWeValueCardRow', { yPercent: 50, opacity: 0 }); 

        whatWeValueTl
            .to(".whatWeValueHeading", { yPercent: 0, opacity: 1, duration: 3 })
            .to(".whatWeValueCardRow", { yPercent: 0, opacity: 1, duration: 3}, '<');
      }, 1000)
    }, whatWeValueRef);

    return () => {
      clearTimeout(timer);
      ctx.revert();
    }
  }, []);

    return <div className="whatWeValueSection paddingT128 paddingB128" ref={whatWeValueRef}>
    <div className="container">
      <div className="row">
        <div className="col-12 col-12-sm ">
            <h2 className="whatWeValueHeading">{title}</h2>
        </div>
      </div>
        <div className="row whatWeValueCardRow ">
          {
            colData.map((data: any, index: any) => {
              return (
                <div className="col-3 col-12-sm" key={data+index}>
                <div className="whatWeValueCard">
                  <div className="whatWeValueIconOuter">
                      <div className="whatWeValueIcon">
                      <ImageConversion
                              url={data?.cardImage?.url}
                              altext={data?.cardImage?.title}
                              />
                    </div>
                  </div>
                  <h4 className="whatWeValueCardHeading">{data?.title}</h4>
                  <div className="whatWeValueDes">
                    <p>{documentToPlainTextString(data?.description?.json)}</p>
                  </div>
                </div>
              </div>
              )
            }) 
            }
      </div>
    </div>
  </div>
}