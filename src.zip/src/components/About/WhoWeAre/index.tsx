import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import gsap from "gsap";
import { useRef } from "react";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
import parse from 'html-react-parser';
const WhoWeAre = ({ sectionData }: any) => {
  const whoWeAre = JSON.parse(sectionData);
  let desc = documentToPlainTextString(whoWeAre?.description?.json)
  const WhoWeAreRef = useRef<HTMLDivElement>(null);
  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      // Add the Contact Team Section animation steps to the timeline
      setTimeout(() => {
      gsap.set(".whoWeAreHeading", {
        xPercent: 50,
        opacity: 0,
      });
      gsap.set(".whoWeAreContent", {
        xPercent: 30,
        opacity: 0,
      });

      const ourTeamTl = gsap.timeline({});

      ScrollTrigger.create({
        animation: ourTeamTl,
        trigger: WhoWeAreRef.current,
        start: "top 60%",
        end: "bottom",
        // pin: WhoWeAreRef.current,
        scrub: true,
      });

      ourTeamTl
        .to(
          ".whoWeAreHeading",
          {
            xPercent: 0,
            opacity: 1,
            duration: 7,
            ease: "Power4.easeOut",
          },
          "<30%"
        )
        .to(
          ".whoWeAreContent",
          {
            xPercent: 0,
            opacity: 1,
            duration: 4,
            ease: "Power4.easeOut",
          },
          "<10%"
        );
      }, 3000);
    }, WhoWeAreRef);

    return () => ctx.revert();
  }, []);

  return (
    <section className="whoWeAre ourTeam--pin paddingY128" ref={WhoWeAreRef}>
      <div className="container">
        <div className="row">
          <div className="col-4 col-12-sm">
            <h2 className="whoWeAreHeading">{whoWeAre?.title}</h2>
          </div>
          <div className="col-8 col-12-sm">
            <div className="whoWeAreContent">
              {parse(desc)}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
export default WhoWeAre;
