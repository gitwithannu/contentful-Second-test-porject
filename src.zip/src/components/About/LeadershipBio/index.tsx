import React, {useState,useEffect, useRef} from 'react'
import { LeadershipAccordion, LeadershipAccordionHeader, LeadershipAccordionPanel, LeadershipAccordionWrapper } from '../../LeadershipAccordion';
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
import Image from 'next/image';
import parse from 'html-react-parser';
import gsap from "gsap";
import Link from 'next/link';
import Scrollbar from 'smooth-scrollbar';
import { useRouter } from 'next/router';
const AboutLeadershipBio = ({ title, dataMembers }: any) => {
     const members = JSON.parse(dataMembers);
     const [isDesktop, setIsDesktop] = useState(true);
     const [isMobile, setIsMobile] = useState(false);
     const router = useRouter();
     const scrollToElement = (team: string | string[] | undefined) => {
          if (typeof team === 'string') {
            setTimeout(() => {
              const targetElement = document.querySelector(`#${team}`) as HTMLElement | null;
              if (targetElement) {
                let targetElementOffsetTop = 30;
                if (window.innerWidth <= 1199) {
                  targetElementOffsetTop += 80;
                }
                const scrollbar = Scrollbar.init(document.querySelector('.scroller') as HTMLElement);
                if (scrollbar) {
                  scrollbar.scrollIntoView(targetElement, {
                    alignToTop: true,
                    offsetTop: targetElementOffsetTop,
                  });
                }
              }
            }, 2000);
          }
        };
      
        useEffect(() => {
          const handleRouteChangeComplete = () => {
            const team = router.query.scrollTo;
            scrollToElement(team);
          };
          if (router.isReady) {
              handleRouteChangeComplete();
          }
          router.events.on('routeChangeComplete', handleRouteChangeComplete);
          return () => {
            router.events.off('routeChangeComplete', handleRouteChangeComplete);
          };
        }, [router]);
     

     useEffect(() => {
          const handleResize = () => {
              setIsDesktop(window.innerWidth >= 1200);
               setIsMobile(window.innerWidth <= 1199);
          };
          
          handleResize();
          window.addEventListener('resize', handleResize);
          return () => {
              window.removeEventListener('resize', handleResize);
          };
     }, []); 
     return (
          <section className='leadership-bio paddingY128' id="our-team">
               <div className='container'>
                    <div className='row'>
                         <div className='col-12'>
                              <h2 className='text-center leadership-title'>{title}</h2>
                         </div>
                         <div className='col-12'>

                         <LeadershipAccordionWrapper className="leaderbio-accordion">

                                   {members.map((leader: any, i: number) => {
                                        const description = documentToPlainTextString(leader?.description?.json);
                                        return (
                                             <LeadershipAccordion key={i} customIndex={i}>
                                                  <LeadershipAccordionHeader customIndex={i}>
                                                       <div className='leaderbio-info'>
                                                            <div className='leaderbio-image'>
                                                            {leader?.enableImage && leader?.cardImage?.url&& <Image src={leader?.cardImage?.url} fill className='leaderbio-img' alt={leader?.cardImage?.title} />}
                                                            </div>
                                                            <div className='leaderbio-data'>
                                                                 <div className='leaderbio-text'>
                                                                 {leader?.showTitle && (
                                                                      <h6 className='leaderbio-name'>
                                                                      {leader?.buttonUrl ? (
                                                                           <Link className='leaderbio-link' target="_blank" href={leader?.buttonUrl}>{leader?.title}</Link>
                                                                      ) : (
                                                                           leader?.title
                                                                      )}
                                                                      </h6>
                                                                      )}
                                                                 {leader?.cardTextAbber && <p className='leaderbio-post'>{leader?.cardTextAbber}</p>}
                                                                 </div>
                                                                 {isDesktop && (
                                                                      <div className='desktopOnly'>
                                                                           <LeadershipAccordionPanel customIndex={i}>
                                                                                {description && <div>{parse(description)}</div>}
                                                                           </LeadershipAccordionPanel>
                                                                      </div>
                                                                 )}
                                                            </div>
                                                       </div>
                                                  </LeadershipAccordionHeader>
                                                  {isMobile && (
                                                       <div className='mobileOnly'>
                                                            <LeadershipAccordionPanel customIndex={i}>
                                                                 {description && <div>{parse(description)}</div>}
                                                            </LeadershipAccordionPanel>
                                                       </div>
                                                  )}
                                             </LeadershipAccordion>
                                        )
                                   })}
                         
                         </LeadershipAccordionWrapper>

                         
                         </div>
                    </div>
               </div>
                    </section>
                    
  )
}

export default AboutLeadershipBio;