import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import gsap from "gsap";
import Image from "next/image";
import { useRef } from "react";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
import parse from 'html-react-parser';
import Link from "next/link";

const WhatWeDone = ({ sectionData }: any) => {
  const WhatWeDone = JSON.parse(sectionData);
  const title = WhatWeDone?.title;
  const subTitle = WhatWeDone?.subHeading
  const description = documentToPlainTextString(WhatWeDone?.description?.json)
  const appsPlugin = WhatWeDone?.appsPlugins
  const membersOfStaff = WhatWeDone?.membersOfStaff
  const countriesSaved = WhatWeDone?.countriesSaved
  const gitCommits = WhatWeDone?.gitCommits
  const projectsCompleted = WhatWeDone?.projectsCompleted
  const users = WhatWeDone?.users
  const WhatWeDoneRef = useRef<HTMLDivElement>(null);
  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      // Add the Contact Team Section animation steps to the timeline
      setTimeout(() => {
      gsap.set(".sofarCircle", { yPercent: 0 });
      gsap.set(".aboutWhiteCircle h3", { opacity: 1, xPercent: 0 });
      gsap.set(".whatWeContent", { opacity: 0 });
      gsap.set(".whatWeContentLeft h3", { scale: 1.5, xPercent: 50, yPercent: 80.6, opacity: 0 });
      gsap.set(".whatWeContentLeft p", { opacity: 0, yPercent: 150.6 });
      gsap.set(".whatWeContentLeft span", { opacity: 0, yPercent: 200 });
      gsap.set(".pluginCommites", { opacity: 0, scale: 0.3, xPercent: -100 });
      gsap.set(".appsPlugin, .memberStaff, .countriesServed, .gitCommits, .userCounter", { opacity: 0, scale: 0.3 }
      );

      gsap.set(".whatWeContentRight", { scale: 0.8, opacity: 0, yPercent: 10 });
      const whatWeDoneTl = gsap.timeline({});
      let mm = gsap.matchMedia();

      mm.add("(min-width: 768px)", () => {
        ScrollTrigger.create({
          animation: whatWeDoneTl,
          trigger: WhatWeDoneRef.current,
          start: "top 60%",
          end: "bottom center",
          scrub: true
        });
      })

      whatWeDoneTl
        .to(".aboutWhiteCircle", { clipPath: "circle(100% at 50% 50%)", duration: 40, delay: 1 }, "<")
        .to(".whatWeContent", { opacity: 1, ease: "Power0.easeOut", }, "<20%")
        .to(".whatWeContentLeft h3", { scale: 1, xPercent: 0, duration: 15, yPercent: 0, delay: 1, opacity: 1 }, "<30%")
        .to(".whatWeContentLeft p",{ scale: 1, duration: 10, yPercent: 0, opacity: 1, delay: 0, ease: "Power4.easeOut"},"<10%")
        .to(".whatWeContentLeft span",{ scale: 1, duration: 20, yPercent: 0,opacity: 1,delay: 3 },"<")
        .to(".whatWeContentRight",{ scale: 1, duration: 20, opacity: 1, yPercent: 0 },"<")
        .to(".aboutWhiteCircle .whatWeContent p", { scale: 1, xPercent: 0, yPercent: 0, opacity: 1, delay: 3 },"<80%")
        .to(".sofarCircle", { yPercent: 0, duration: 10, opacity: 1, ease: "Power4.easeOut" }, "<30%")
        .to(".pluginCommites", { opacity: 1, scale: 1, xPercent: 0, delay: 3, duration: 10 }, "<")
        .to(".appsPlugin", { scale: 1, duration: 10, xPercent: 0, opacity: 1, delay: 3, ease: "Power4.easeOut" },"<80%")
        .to(".memberStaff", { scale: 1, xPercent: 0, duration: 10, opacity: 1, delay: 3, ease: "Power4.easeOut" }, "<")
        .to(".countriesServed", { scale: 1, xPercent: 0, duration: 10, opacity: 1, delay: 3, ease: "Power4.easeOut" }, "<")
        .to(".gitCommits", { scale: 1, xPercent: 0, duration: 30, opacity: 1, delay: 1, ease: "Power4.easeOut" },"<")
        .to(".userCounter", { scale: 1, duration: 30, xPercent: 0, opacity: 1, delay: 3, ease: "Power4.easeOut" }, "<" );

      mm.add("(max-width: 767px)", () => {
        gsap.set(".projectNumberCircle", { opacity: 0, scale: 0.3 });
        gsap.set(".userCounter", { opacity: 0, scale: 0.3  });
        ScrollTrigger.create({
          animation: whatWeDoneTl,
          trigger: WhatWeDoneRef.current,
          start: "top 70%",
          end: "bottom center",
          scrub: true
        });
        whatWeDoneTl
          .to(".userCounter", { scale: 1, duration: 30, xPercent: 0, opacity: 1, delay: 3, ease: "Power4.easeOut" }, "<")
          .to(".projectNumberCircle", { scale: 1, duration: 30, xPercent: 0, opacity: 1, delay: 3, ease: "Power4.easeOut" },"<")
          .to(".gitCommits", { scale: 1, xPercent: 0, duration: 30, opacity: 1, delay: 1, ease: "Power4.easeOut" }, "<")
          .to(".pluginCommites", { opacity: 1, scale: 1, xPercent: 0, delay: 3, duration: 10, }, "<")
          .to(".appsPlugin", { scale: 1, duration: 10, xPercent: 0, opacity: 1, delay: 3, ease: "Power4.easeOut" },"<80%")
          .to(".memberStaff", { scale: 1, xPercent: 0, duration: 10, opacity: 1, delay: 3, ease: "Power4.easeOut" },"<")
          .to(".countriesServed",{ scale: 1, xPercent: 0, duration: 10, opacity: 1, delay: 3, ease: "Power4.easeOut" },"<");
      });
      mm.add("(max-width: 320px) and(min-width: 300px)", () => {
        ScrollTrigger.create({
          animation: whatWeDoneTl,
          trigger: WhatWeDoneRef.current,
          start: "top 40%",
          end: "bottom center",
          scrub: true,
        });
      });
      }, 3000);
    }, WhatWeDoneRef);

    return () => ctx.revert();
  }, []);

  return (
    <section className="minHeight100 whatWeDoneMainPanel" ref={WhatWeDoneRef}>
      <div className="aboutMainPanel">
        <div className="sofarCircle">
          <div className=" aboutWhiteCircle h1">
            <div className="container">
              <div className="row dFlex">
                <div className="whiteCirclee  dFlex flexFlowColumn">
                  <div className="whatWeDone">
                    <div className="whatWeProject">
                      <div className="row dFlex">
                        <div className="col-7 col-12-sm">
                          <div className="whatWeContent whatWeContentLeft ">
                          <h3>{title}</h3>
                            <p>
                              {subTitle}
                            </p>
                            <span>
                             {description}
                            </span>
                          </div>
                        </div>
                        <div className="col-5 col-12-sm whatWeContentRight col-12-sm ">
                          <div className="projectNumberCircle showDesk">
                            <h3 className="circleNumber">
                              {parse(projectsCompleted)}
                            </h3>
                          </div>
                         
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="bottomWhatWeDonePanel">
          <div className="projectNames allData">
            <div className="container">
              <div className="row reverseMob">
                <div className="col-12-sm col-7 m0 counterLeftPanel">
                  <div className="pluginCommites">
                    <div className="membersPlugin">
                      <div className="appsPlugin">
                      <h3>{parse(appsPlugin)}</h3>
                      </div>
                      <div className="memberCount">
                        <div className="memberStaff">
                          <h4>
                          {parse(membersOfStaff)}
                          </h4>
                        </div>
                        <div className="countriesServed">
                          <h4>
                          {parse(countriesSaved)}
                          </h4>
                        </div>
                      </div>
                    </div>
                    <div className="gitCommits">
                      <h3>
                      {parse(gitCommits)}
                      </h3>
                    </div>
                  </div>
                </div>
                <div className="col-12-sm col-5 dFlex m0 counterRightPanel">
                  <div className="userCounter dFlex">
                    <h3>
                    {parse(users)}
                    </h3>
                  </div>
                  <div className="projectNumberCircle showMob">
                    <h3 className="circleNumber">
                    {parse(projectsCompleted)}
                    </h3>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      </section>
  );
};
export default WhatWeDone;