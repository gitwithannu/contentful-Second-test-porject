import BlowSingleBanner from "@/src/templates/BlowSingleBanner";
import { useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";

const AboutSingleBaneer = () => {
  const aboutSingleBaneerRef = useRef<HTMLDivElement>(null);

  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      // Add the Single banner Blow Section animation steps to the timeline
      //setTimeout(() => {
        let mm = gsap.matchMedia();
        mm.add("(min-width: 1299.99px)", () => {
          gsap.set(".blowInnerBannerHeading", { scale: 2, opacity: 0 });
          gsap.set(".blowInnerBannerSubHeading", { yPercent: 40, opacity: 0 });
        })
      gsap.set(".blowInnerBannerSubText", {
        yPercent: 60,
        opacity: 0,
      });
      const aboutSingleBannerTl = gsap.timeline({});
      mm.add("(min-width: 1299.99px)", () => {
        ScrollTrigger.create({
          animation: aboutSingleBannerTl,
          trigger: aboutSingleBaneerRef.current,
          start: "top bottom",
          end: "bottom center",
          pin: aboutSingleBaneerRef.current,
          scrub: true,
        });
      });

      aboutSingleBannerTl
        .to(".blowInnerBannerHeading", {
          scale: 1,
          duration: 1,
          opacity: 1,
          ease: "Power4.easeOut",
        })
        .to(
          ".blowInnerBannerSubHeading",
          {
            yPercent: 0,
            opacity: 1,
            duration: 1,
            ease: "Power4.easeOut",
          },
          "<40%"
        )
        .to(
          ".blowInnerBannerSubText",
          {
            yPercent: 0,
            opacity: 1,
            duration: 1,
            ease: "Power4.easeOut",
          },
          "<60%"
      );
      mm.add("(max-width: 1299.98px) and (min-width: 200.98px)", () => {
        ScrollTrigger.create({
          animation: aboutSingleBannerTl,
          trigger: aboutSingleBaneerRef.current,
          start: "top 100%",
          end: "bottom center",
          scrub: true,
          onToggle: scrollTrigger => {
            // refresh because height start changes
            scrollTrigger.refresh()
          },
        });
        gsap.set(".blowInnerBannerHeading", {
          scale: 0,
          opacity: 1,
        });
      });
      //}, 3000);
    }, aboutSingleBaneerRef);

    return () => ctx.revert();
  }, []);
  return (
    <BlowSingleBanner>
      <div
        className="blowInnerBanner aboutInnerBanner dark"
        ref={aboutSingleBaneerRef}
      >
        <div className="blowInnerBannerWrap ">
          <h2 className="blowInnerBannerHeading">Why We’re Here</h2>
          <h4 className="blowInnerBannerSubHeading">
            Founded in X, Aly Hemraj was inspired by the… About what makes TRU,
            TRU, why was the business founded and what benefit do we have to the
            client? What gap were we fulfilling in the market?
          </h4>
          <p className="blowInnerBannerSubText">
            We’re a results-driven, customer-focused digital agency.
            <span className="dBlock">
              We find opportunities that help you navigate the digital world
              with smart data-packed decisions.
            </span>
          </p>
        </div>
      </div>
    </BlowSingleBanner>
  );
};
export default AboutSingleBaneer;
