import { useRef } from 'react';
import Link from 'next/link';
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";

export const AboutContact = ({buttonUrl,buttonText,enableButton,title}:any) =>{
    const aboutContactRef = useRef<HTMLDivElement>(null);
    let timer: string | number | NodeJS.Timeout | undefined;
    useIsomorphicLayoutEffect(() => {
        let ctx = gsap.context(() => {
          timer = setTimeout(() => {
            const aboutContactTl = gsap.timeline({});
            ScrollTrigger.create({
                animation: aboutContactTl,
                trigger: aboutContactRef.current,
                start: "top 80%",
                end: "bottom center",
                scrub: true,
                onToggle: scrollTrigger => {
                  // refresh because height start changes
                  scrollTrigger.refresh()
                },
              });

            gsap.set('.aboutContact--title, .aboutContact--cta', { yPercent: 20, opacity: 1 }); 

            aboutContactTl
                .to(".aboutContact--title", { yPercent: 0, opacity: 1 })
                .to(".aboutContact--cta", { yPercent: 0, opacity: 1 }, '<');
          }, 1000);

         
        }, aboutContactRef);
    
        return () => {
          clearTimeout(timer);
          ctx.revert();
        }
      }, []);

    return <section className="truAdsSolutions aboutUsContactSec paddingY128" ref={aboutContactRef}>
        <div className="teamContact teamContact-1 dark">
            <div className="teamContactWrap">
          <h5 className="teamContactContent aboutContact--title">{title}</h5>
          {enableButton && <Link href={buttonUrl} className="globalButton withCircle  contact-cta aboutContact--cta" aria-label="Contact Us Today">{buttonText}</Link>}
            </div>
        </div>
  </section>
}