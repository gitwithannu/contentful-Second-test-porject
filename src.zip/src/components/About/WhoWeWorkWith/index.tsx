import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import gsap from "gsap";
import Image from "next/image";
import { useRef } from "react";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import Slider from "react-slick";
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
import parse from 'html-react-parser';
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))


//Partner Logo
let partnerLogo = {
  centerMode: true,
  dots: false,
  infinite: true,
  slidesToShow: 8,
  slidesToScroll: 1,
  autoplay: true,
  speed: 1000, 
  arrows: false,
  autoplaySpeed: 1000,
  centerPadding: "7vw",
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 6,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1
      }
    }
  ]
};
let partnerLogoRtl = {
  centerMode: true,
  dots: false,
  infinite: true,
  slidesToShow: 8,
  slidesToScroll: 1,
  autoplay: true,
  speed: 1000, 
  arrows: false,
  autoplaySpeed: 1000,
  centerPadding: "7vw",
  rtl: true,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 6,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1
      }
    }
  ]
};
const WhoWeWorkWith = ({ customImageUrl, customImageTitle, imagesData, slideTwo, slideThree }: any) => {
  
  const sectionData = JSON.parse(imagesData);
  const partnerSlideTwo = JSON.parse(slideTwo);
  const partnerSlideThree = JSON.parse(slideThree);
  const sectionDataItems = sectionData?.cardsCollection?.items;
  let desc = documentToPlainTextString(sectionData?.description?.json)
  const WhoWeWorkWithRef = useRef<HTMLDivElement>(null);
  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      // Add the Contact Team Section animation steps to the timeline
      let mm = gsap.matchMedia();
      setTimeout(() => {
      gsap.set(".ourProject", { opacity: 0, yPercent: 10 });
      gsap.set(".partnerLogo, .cardCarouselProduct", { yPercent: 50, opacity: 0 });
      gsap.set(".whoWeAreImage", { yPercent: 50, opacity: 0})
      const whatWeWorkWithTl = gsap.timeline({});

      mm.add("(min-width: 992px) ", () => {
        gsap.set(".whoWeTitle", { xPercent: 0, opacity: 0, yPercent:30 });
        gsap.set(".whoWeDescription", { xPercent: 0, opacity: 0, yPercent: 30 });
        ScrollTrigger.create({
          animation: whatWeWorkWithTl,
          trigger: WhoWeWorkWithRef.current,
          start: "top 65%",
          end: "+=1000px",
          scrub: true,
        });
    })

      // whatWeWorkWithTl
      //   .to(".whoWeTitle", { xPercent: 0, opacity: 1, duration: 1, yPercent: 0, ease: "Power4.easeOut" })
      //   .to(".whoWeDescription", { xPercent: 0, opacity: 1, duration: 4, ease: "Power4.easeOut", yPercent: 0 }, "<")
      //   .to(".ourProject", { yPercent: 0, opacity: 1, duration: 3, ease: "Power4.easeOut" }, "<20%")
      //   .to(".partnerLogo",{ yPercent: 0, opacity: 1, duration: 1, ease: "Power4.easeOut" },"<")
      //   .to(".whoWeAreImage", { yPercent: 0, opacity: 1}, "<" );
      
        whatWeWorkWithTl
        .to(".whoWeTitle", { xPercent: 0, opacity: 1, duration: 1, yPercent: 0, ease: "Power4.easeOut" })
        .to(".whoWeDescription", { xPercent: 0, opacity: 1, duration: 4, ease: "Power4.easeOut", yPercent: 0 }, "<")
        .to(".partnerLogo",{ yPercent: 0, opacity: 1, duration: 1, ease: "Power4.easeOut" },"<")
        .to(".whoWeAreImage", { yPercent: 0, opacity: 1}, "<" );

      mm.add("(max-width: 991px) and (min-width:300px)", () => {
        gsap.set(".whoWeTitle", { xPercent: 0, opacity: 0, yPercent:10 });
        gsap.set(".whoWeDescription", { xPercent: 0, opacity: 0, yPercent:15 });

        ScrollTrigger.create({
          animation: whatWeWorkWithTl,
          trigger: WhoWeWorkWithRef.current,
          start: "top 80%",
          end: "100%",
          pin: false,
          scrub: true,
        });

        gsap.set(".whoWeAreImage", { yPercent: 50, opacity: 1 });

        whatWeWorkWithTl
          .to(".whoWeAreImage", { yPercent: 0,  opacity: 1 },"<")
          .to(".mainWorkPanel", { yPercent: 0, duration: 5, opacity: 1 },"<");
      });
      }, 3000);
    }, WhoWeWorkWithRef);

    return () => ctx.revert();
  }, []);

  return (
    <section className="whatWeDone--pin" ref={WhoWeWorkWithRef}>
      <div className="whatWeDoneInnerPanel">
        <div className="mainWorkPanel whatWeDone">
          <div className="whoWeWork paddingY128">
            <div className="blueCircle">
              <Image
                src="/images/aboutEcllipseShadow.png"
                alt="bottomOrangeBlueradient"
                fill
                loading ="lazy"
              />
            </div>
            <div className="container">
              <div className="row">
                <div className="col-5">
                  <div className="whoWeTitle">
                    <h3>
                      {parse(sectionData?.title)}
                    </h3>
                  </div>
                </div>
                <div className="col-7">
                  <div className="whoWeDescription">
                      {parse(desc)}
                  </div>
                </div>
              </div>
             </div>
             <div className="containerFluid">
              <div className="partnerLogo aboutPartnerSlider paddingT128">
                <Slider {...partnerLogoRtl}>
                {
                    sectionDataItems?.map((partner: any,key:any) => {
                      return (
                        <div key="key">
                          <div className="partnerSlickSlide">
                          <ImageConversion
                              url={partner?.cardImage?.url}
                              altext={partner?.cardImage?.title}
                              />
                            </div>
                        </div>
                   )
                  })
                }
                 

                </Slider>
              </div>

              <div className="partnerLogo aboutPartnerSlider">
                <Slider {...partnerLogo}>
                {
                    partnerSlideTwo?.map((partner: any,key:any) => {
                      return (
                        <div key="key">
                          <div className="partnerSlickSlide">
                          <ImageConversion
                              url={partner?.cardImage?.url}
                              altext={partner?.cardImage?.title}
                              />
                            </div>
                        </div>
                   )
                  })
                }
                 

                </Slider>
              </div>

              <div className="partnerLogo aboutPartnerSlider">
                <Slider {...partnerLogoRtl}>
                {
                    partnerSlideThree?.map((partner: any,key:any) => {
                      return (
                        <div key="key">
                          <div className="partnerSlickSlide">
                          <ImageConversion
                              url={partner?.cardImage?.url}
                              altext={partner?.cardImage?.title}
                            />
                            </div>
                        </div>
                   )
                  })
                }
                 

                </Slider>
              </div>


            </div>
          </div>
        </div>
        {customImageUrl &&
          <div className="whoWeAreImage">
            <ImageConversion
              url={customImageUrl}
              altext={customImageTitle}
            />
          </div>
        }
      </div>
    </section>
  );
};
export default WhoWeWorkWith;
