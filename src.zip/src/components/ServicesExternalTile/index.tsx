import Image from 'next/image'
import Link from 'next/link';
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))

export const ServicesExternalTile = ({CardsData, className}: any) => {
    return  <div className={`services-page-cards paddingB128 ${className}`}>
    <div className="container">
        <div className="row">
          {CardsData.map((section: any, key: any) => { 
            const showTitle = section?.showTitle;
            const cardImage = section?.cardImage?.url;
            const cardAlt = section?.cardImage?.title;
            const buttonUrl = section?.buttonUrl;
            let title = "";
            if (showTitle) {
              title = section?.title;
            }
            return (
              <div className="col-4" key={key}>
                <div className="service-pages-card">
                  <div className="service-card-icon-outer">
                    <div className="service-card-icon">
                    <ImageConversion
                        url={cardImage ? cardImage : ""}
                        altext={cardAlt ? cardAlt : ""}
                    />
                      
                    </div>
                  </div>
                  {title && <Link
                    href={buttonUrl ? buttonUrl :"#"}
                    aria-label={title}
                    target="_self"
                  ><h4>{title}</h4></Link>}
                </div>
              </div>
            )
          })}
      </div>
    </div>
</div>
}