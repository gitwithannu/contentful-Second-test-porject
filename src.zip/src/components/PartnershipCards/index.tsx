import Image from "next/image";
import Link from "next/link";
const salesforcelogosec = "/images/Services/salesforcelogosec.svg";
const blueCheck = "/images/blue-check.svg";
const ourPartner = "/images/our-partners.png";
import parse from "html-react-parser";
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))

interface PartnerCardsProp extends React.HTMLAttributes<HTMLDivElement> {
     icon?: string | any,
     listIcon?: string | any,
     title?: any,
     ctaText?: string,
     description?: string | any,    
     ctaUrl?: string | any,
     reverse?: any,
  cardData?: any,
  bottomTagLine?: any,
  tagline?:any
    
   }

export const PartnerShipPage: React.FC<PartnerCardsProp>= ({ reverse, cardData,bottomTagLine,tagline, icon, title, listIcon, description, ctaText="link", ctaUrl= '#' }) => { 

     return <div className="partnerShipMain">
     <div className={`row partnerShipCardRow ${reverse ? 'reverse-image-right' : ' ' }`}>
       <div className="col-6 col-12-sm">
           <div className="partnerShipImage">
            <ImageConversion url={cardData?.imageUrl} altext={cardData?.imageAlt}/>
         </div>
       </div>
       <div className="col-6 col-12-sm">
         <h3 className="partnerShipCardTitle">{parse(cardData?.title)}</h3>
          <div className="partnerShipDes"> 
            {cardData?.desc && parse(cardData?.desc)}
          </div>
       </div>
     </div>
     <div className="row partnerShipListRow">
        {cardData?.data !== undefined &&
                        cardData?.data.length > 0 &&
                        cardData?.data.map(
                          (
                            item: {
                              icon: boolean | undefined;
                              title: string | undefined;
                              desc: string | undefined;
                              titleShow: boolean | undefined;
                            },
                            key: any
                          ) => (
                            <div className="col-3 col-12-sm" key={key}>
                              <div className="partnerShipBrandList">
                                <div className="partnerShipBrandIcon">
                                <Image
                                src={blueCheck}
                                fill
                                loading ="lazy"
                                alt="blue tick"
                              />
                                </div>
                                {item?.title && item.titleShow && <span>{item?.title}</span>}
                              </div>
                            </div>
                         )
                         )}    
         </div>
     
       {bottomTagLine ? <div className="row partnerShipContent">
         <div className="col-12-sm">
           {parse(tagline)}
         </div>
       </div> : ""}
       {cardData?.enableButton && cardData?.buttonText &&
         <div className="row partnerShipButton">
           <div className="col-12 text-right"><Link href={cardData?.buttonUrl ? cardData?.buttonUrl :"#" } className="globalButton withCircle  contact-cta aboutContact--cta" aria-label="Contact Us Today">{cardData?.buttonText}</Link>
           </div>

         </div>
       }
   </div>        
}