import { useRef } from "react";
import Image from "next/image";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import { AnimateCircle } from "../AnimateCircle";
import Link from "next/link";
import toast, { Toaster } from 'react-hot-toast';
import parse from 'html-react-parser';
import { useRouter } from 'next/router';
import SmoothScrollbar from 'smooth-scrollbar';
interface TopBannerProps extends React.HTMLAttributes<HTMLDivElement> {
  icon?: React.ReactNode;
  title?: any;
  subtitle?: string;
  bg?: string | any;
  showHide?: boolean;
  shadowHide?: boolean;
  cta?: boolean;
  goBackUrl?: string;
  goBackText?: string;
  customClass?: string;
  jobApplicationUrl?: string;
  jobApplicationText?: string,
  jobReferUrl?: string,
  jobReferText?: string,
  onChildClick? : any

}

export const PageImageBannerNew: React.FC<TopBannerProps> = ({
  title,
  subtitle,
  bg,
  showHide,
  shadowHide,
  goBackUrl = "#!",
  goBackText,
  cta = true,
  customClass,
  jobApplicationUrl = "#!",
  jobApplicationText,
  jobReferUrl = "#!",
  jobReferText,
  onChildClick
}) => {
  const pageImageBannerNew = useRef<HTMLDivElement>(null);
 
  const handleClick = (e:any) => {
    e.preventDefault();
    const dataToSend = true;
    // Call the callback function in the parent component with the data
    onChildClick(dataToSend);
    scrollToBottom();
  };

  const scrollToBottom = () => {
    const containerElement = document.getElementsByClassName('scroller')[0] as HTMLElement;
    const scrollbar = SmoothScrollbar.init(containerElement);
    scrollbar.scrollTo(100, 700, 500); 
  }
  
  const router = useRouter();
  const currentUrl = typeof window !== 'undefined' ? window.location.href : null;
  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      //setTimeout(() => {
      gsap.set(".mainBannerHeading", { scale: 2, opacity: 0 });
      gsap.set(".mainBannerSubheading", { xPercent: 20, opacity: 0 });
      gsap.set(".goBackButton", { xPercent: 50, opacity: 0 });
      gsap.set(".supHeading", { xPercent: 10, opacity: 0 });
      gsap.set(".mainBannerButton", { yPercent: 30, opacity: 0 });
      gsap.set(".share-job", { yPercent: 50, opacity: 0 });
      gsap.to(".mainBannerHeading", {
        opacity: 1,
        scale: 1,
        duration: 1,
        ease: "Power4.easeOut",
        delay: 1,
      });
      gsap.to(".mainBannerSubheading", {
        xPercent: 0,
        opacity: 1,
        delay: 1,
        duration: 1,
      });
      gsap.to(".goBackButton", {
        xPercent: 0,
        opacity: 1,
        duration: 2,
        delay: 1.5,
        ease: "Power4.easeOut",
      });
      gsap.to(".supHeading", {
        xPercent: 0,
        opacity: 1,
        duration: 2,
        delay: 1.5,
        ease: "Power4.easeOut",
      });
      gsap.to(".mainBannerButton", {
        yPercent: 0,
        opacity: 1,
        duration: 2,
        delay: 1.5,
        ease: "Power4.easeOut",
      });
      gsap.to(".share-job", {
        yPercent: 0,
        opacity: 1,
        duration: 2,
        delay: 1.8,
        ease: "Power4.easeOut",
      });

      const pageImageBannerTl = gsap.timeline({});
      let mm = gsap.matchMedia();
    }, pageImageBannerNew);
    return () => ctx.revert();
  }, []);

  function handleCopyToClipboard() {
    navigator.clipboard.writeText(window.location.href)
      .then(() => {
        toast.success('Link Copied', {
          style: {
            border: '1px solid #051d3a',
            borderRadius: '50px',
            color: '#000',
            fontWeight:'bold',
            background: '#edfafd',
            
          },
          iconTheme: {
            primary: '#051d3a',
            secondary: '#fff',
          },
          duration: 800,       
        });
        // You can add additional logic or UI updates here
      })
      .catch((error) => {
        console.error('Error copying to clipboard:', error);
        // Handle errors or provide user feedback here
      });
  }

 
  return (
    <>
    <div className={customClass}>
      <section className="mainBannerPin" ref={pageImageBannerNew}>
        <div className="mainBannerSection mainBannerSectionNew">
          <div className="mainBanner bannerPadding innerPageBanner mainBannerNew">
            <AnimateCircle className="left-top" />
            <AnimateCircle animate={false} className="right-bottom" />
            <div className="mainBannerOuter">
              <div className="mainBannerGraphics">
                <svg
                  width="930"
                  height="348"
                  viewBox="0 0 930 348"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <circle
                    opacity="0.5"
                    cx="173.5"
                    cy="174.5"
                    r="173"
                    stroke="#00A5D0"
                  />
                  <g opacity="0.5">
                    <mask id="path-2-inside-1_39_16" fill="white">
                      <path d="M347 0H930V347H347V0Z" />
                    </mask>
                    <path
                      d="M347 0V-1H346V0H347ZM347 347H346V348H347V347ZM347 1H930V-1H347V1ZM930 346H347V348H930V346ZM348 347V0H346V347H348Z"
                      fill="#00A5D0"
                      mask="url(#path-2-inside-1_39_16)"
                    />
                  </g>
                  <path
                    opacity="0.5"
                    d="M693.5 346.489C504.303 342.16 351.754 189.627 347.511 0.5H521.405C525.519 93.6721 600.306 168.477 693.5 172.674V346.489Z"
                    stroke="#00A5D0"
                  />
                </svg>
              </div>
              <div className="container">
                <div className="row m0">
                  {!cta ? null : (
                    <div className={`goBackButton ${showHide ? "hide" : ""}`}>
                     <Link
                        href={goBackUrl}
                        aria-label="click here for go back to service archive"
                      ><Image
                      src="/images/bannerArrow.svg"
                      width={32}
                      height={32}
                      alt="Arrow icon"
                      loading ="lazy"
                    /></Link> 
                      <Link
                        href={goBackUrl}
                        aria-label="click here for go back to service archive"
                      >
                        {goBackText}
                      </Link>
                    </div>
                  )}
                  <div className="goBackOuter">
                    <div className="col-10 col-12-sm">
                      <div className="supHeading"> Tru | <span> Full time</span></div>
                      <h1 className="mainBannerHeading">{parse(title)}</h1>
                      <p className="mainBannerSubheading">{subtitle}</p>
                      
                      <div className="mainBannerButton">
                        {jobApplicationUrl && jobApplicationText ? (
                          <Link href={jobApplicationUrl} className="globalButton" onClick={handleClick}>{jobApplicationText}</Link>
                        ) : (null)
                        }
                        {jobReferUrl && jobReferText ? (
                        <Link href={jobReferUrl} className="globalButton outlineBtn">{jobReferText}</Link>
                        ) : (null)
                      }
                    </div>  
                      <div className="share-job">
                        <div><span className="demo-icon  icon-share"></span> </div>
                        <ul>
                          <li><Link href={`https://www.facebook.com/sharer/sharer.php?u=${currentUrl || router.asPath}`}><span className="demo-icon icon-facebook"></span></Link></li>
                          <li><Link target="_blank" href={`http://twitter.com/share?text=${parse(title)}&url=${currentUrl || router.asPath}`}><span className="demo-icon icon-x-twitter"></span></Link></li>
                          <li><Link target="_blank" href={`https://www.linkedin.com/shareArticle?mini=true&url=${currentUrl || router.asPath}&title=${parse(title)}`}><span className="demo-icon icon-linkedin-logo-svgrepo-com-1"></span></Link></li>
                          <li><Link target="_blank" href={`https://wa.me/?text=${currentUrl || router.asPath}`}><span className="demo-icon icon-whatsapp"></span></Link></li>
                          <li><Link target="_blank" href={`https://t.me/share/url?url=${currentUrl || router.asPath}`}><span className="demo-icon icon-telegram"></span></Link></li>
                          <li><span onClick={handleCopyToClipboard} className="demo-icon icon-link"></span>
                          
                          </li>
                        </ul>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {shadowHide ? <div className="blueShadowBottom"></div> : ""}
            </div>
          </div>
       
        </div>
        <Toaster containerClassName="copiedNotification"  position="top-center" />
        </section>
        
   
    </div>
  
    </>
  );
};
