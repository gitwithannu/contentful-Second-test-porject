import { useRef } from "react";
import parse from 'html-react-parser';
import Link from "next/link";

interface contactSection extends React.HTMLAttributes<HTMLDivElement> {
  teamContactDesc?: string | any;
  ctaText?: string | undefined;
     ctaUrl?: any | undefined
     enableCta?: boolean | false
}
const ContactSection: React.FC<contactSection> = ({
     teamContactDesc,
     ctaText,
     ctaUrl,
     enableCta
}) => {
  const ServicesBottomPanelRef = useRef<HTMLDivElement>(null);
  return (
    <section className="truAdsSolutions blogContactSection" ref={ServicesBottomPanelRef}>
      <section className="teamContact teamContact-1 dark">
        <div className="teamContactWrap">
          <h5 className="teamContactContent">{parse(teamContactDesc)}</h5>
                      {enableCta  && <Link
                           href={ctaUrl ? ctaUrl: "#" }
                           className="globalButton contact-cta"
                           aria-label={ctaText}
                      >
                           {ctaText}
                      </Link>}
        </div>
      </section>
    </section>
  );
};
export default ContactSection;
