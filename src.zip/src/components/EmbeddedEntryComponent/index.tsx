import React from 'react';
import Image from "next/image";
import ContactSection from '../Blog/ContactSection';
import dynamic from "next/dynamic";
import parse from 'html-react-parser';
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
import { Accordion, AccordionHeader, AccordionPanel, AccordionWrapper } from '../Accordion';
import { documentToReactComponents } from '@contentful/rich-text-react-renderer';
import { BLOCKS, INLINES, MARKS } from '@contentful/rich-text-types';
import YouTubeVideo from "@/src/components/YoutubeVideo";

const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))
interface EmbeddedEntryProps {
     data: any;
     entry: any;
}
const options = {
  renderMark: {
    [MARKS.BOLD]: (text:any) => <strong>{text}</strong>,
    [MARKS.ITALIC]: (text:any) => <em>{text}</em>,
  },
  renderNode: {
    [BLOCKS.PARAGRAPH]: (node:any, children:any) => <p>{children}</p>,
    [BLOCKS.HEADING_1]: (node:any, children:any) => <h1>{children}</h1>,
    [BLOCKS.HEADING_2]: (node:any, children:any) => <h2>{children}</h2>,
    [BLOCKS.HEADING_3]: (node:any, children:any) => <h3>{children}</h3>,
    [BLOCKS.HEADING_4]: (node:any, children:any) => <h4>{children}</h4>,
    [BLOCKS.HEADING_5]: (node:any, children:any) => <h5>{children}</h5>,
    [BLOCKS.HEADING_6]: (node:any, children:any) => <h6>{children}</h6>,
    [BLOCKS.UL_LIST]: (node:any, children:any) => <ul>{children}</ul>,
    [BLOCKS.OL_LIST]: (node: any, children: any) => <ol>{children}</ol>,
    [BLOCKS.LIST_ITEM]: (node: any, children: any) => <li>{children}</li>,
    [INLINES.HYPERLINK]: (node:any, children:any) => (
      <a href={node.data.uri}>{children}</a>
    ),
  },
};


const EmbeddedEntryComponent: React.FC<EmbeddedEntryProps> = ({ data,entry }) => {
  if (entry && entry.__typename == 'Headingsubheadingdescription' && entry.tag === "contactSection") {
    return (
        <ContactSection
            teamContactDesc={entry?.subTitle}
            enableCta={entry?.enableButton}
            ctaText={entry?.buttonText}
            ctaUrl={entry?.buttonUrl}
        />
    );
  }
  if (entry && entry.__typename == 'Headingsubheadingdescription' && entry.tag === "blogListingContent") {
    return (
      <div className="cardImageLeft">
      {entry?.title && parse(entry?.title) }
      {entry?.subTitle &&  <div className="imageInfoTopText">{parse(entry?.subTitle)}</div> }
          <div className="cardImageRow">
              <div className="cardImageImg">
                <ImageConversion url={entry?.featureImage?.url}
                  altext={entry?.featureImage?.title}
                        />
                         <div className="cardContent">
                         {entry?.buttonText && <div className="cardTitle">{entry?.buttonText}</div>}
                         {entry?.buttonUrl && <div className="cardDesc">{parse(entry?.buttonUrl)}</div>}
                         </div>
                        {entry?.featureImage?.description && <div className="img-src-text">{parse(entry?.featureImage?.description)}
                        </div>}
              </div>
            {entry?.description?.json &&
              <div className="cardImageText">{documentToReactComponents(entry?.description?.json, options)}
              </div>
            }
        </div>
      </div>
    );
  }
  if (entry && entry.__typename == 'Headingsubheadingdescription' && entry.tag == null) {
    
    return (<>
      {entry?.subTitle &&  <div className="imageInfoTopText">{parse(entry?.subTitle)}</div> }
      </>
    );
  }

  if (entry.__typename == 'Headingsubheadingdescription' && entry.tag == "imageWithDescription") {
    return (
      <div className="singleImage imageWithDescriptionSingle">
        {entry?.title &&
        <h3 className="imageInfoBlockTitle">{entry?.title}</h3>}
        {entry?.subTitle && <div className="imageInfoTopText">{parse(entry?.subTitle)}</div>}
          {entry?.featureImage?.url && <ImageConversion
            url={entry?.featureImage?.url}
            altext={entry?.featureImage?.title}
          />
          } 
      {entry?.featureImage?.description && <div className="img-src-text">{parse(entry?.featureImage?.description)}</div>}
      {entry?.description?.json && <div className="imageInfoBottomText">{documentToReactComponents(entry?.description?.json, options)} </div>}
     </div>
    )
  }

  if(entry && entry.__typename == 'Accordion' && entry?.tag == "blogFaqSection") {
    return (
      <div className="container blogFaQ">
      <div className="faq">
        {entry?.heading && <div className="faq_title">
          <h3>{entry?.heading}</h3>
        </div>
        }
        <AccordionWrapper>
        {
          entry?.accordions?.map((accordion: any, key: any) => {
            return (
                <Accordion key={key} customIndex={key}>
                <AccordionHeader>{accordion?.key}</AccordionHeader>
                  <AccordionPanel>
                  <p>{parse(accordion?.value)}</p>
                  </AccordionPanel>
                </Accordion>
            )
          })
          }
        </AccordionWrapper>
      </div>
      </div>
      )
      }
  if (entry && entry.__typename == 'Headingsubheadingdescription' && entry?.tag == "blogQuoteBorder") {
    return (<blockquote className="blogQuote blogQuoteborder">
            <div className="blogQuoteIcon">
              <Image
                alt="quote icon"
                src="/images/quote-icon.svg"
                width="60"
                height="32"
                decoding="async"
                data-nimg="1"
                loading="lazy"
              />
            </div>
            {parse(entry?.subTitle)}
          </blockquote>
        )
  }
  
  if (entry && entry.__typename == 'Headingsubheadingdescription' && entry?.tag == "blogQuote") {
    return (<blockquote className="blogQuote">
            <div className="blogQuoteIcon">
              <Image
                alt="quote icon"
                src="/images/quote-icon.svg"
                width="60"
                height="32"
                decoding="async"
                data-nimg="1"
                loading="lazy"
              />
            </div>
          {parse(entry?.subTitle)}
          </blockquote>
        )
  }

  if (entry && entry.__typename == 'Headingsubheadingdescription' && entry?.tag == "blogContact") {
    return (<ContactSection
              teamContactDesc={entry?.subTitle}
              enableCta={entry?.enableButton}
              ctaText={entry?.buttonText}
              ctaUrl={entry?.buttonUrl}
            />
        )
  }

  if (entry && entry.__typename == 'Headingsubheadingdescription' && entry?.tag == "blogVideo") {
    return (
            <div className="cardImageLeft">
                <YouTubeVideo src={entry?.subTitle} title={entry?.title} />
                <div className="img-src-text">{parse(documentToPlainTextString(entry?.description?.json))}</div>
            </div>
        )
  }
  if (entry && entry.__typename == "SectionWithCards" && entry?.tag == "CustomCards") { 
    return (
         <div className="cardImageGrid">
         {entry?.cardsCollection?.items?.map((card: any, key: any) => {
              return (
                   <div className="cardImageImg" key={key}>
                   {card?.cardImage?.url && <ImageConversion
                        url={card?.cardImage?.url}
                        altext={card?.cardImage?.title}
                        />
                        }
                        <div className="cardContent">
                        {card?.title && <div className="cardTitle">{card?.title}</div>}
                        {card?.description?.json && <div className="cardDesc">{parse(documentToPlainTextString(card?.description?.json))}</div>}
                   
                        </div>
                        {card?.cardImage?.description && <div className="img-src-text">{parse(card?.cardImage?.description)}</div>}
                   </div>
                   )
         })
         }
         </div>
    )
}

  

  return null
};

export default EmbeddedEntryComponent;
