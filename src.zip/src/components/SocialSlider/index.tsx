import React from "react";
import Slider, { Settings } from "react-slick";
import "slick-carousel/slick/slick.css";

interface SocialSliderProps {
  images: string[];
  settings?: Settings;
  children?: any;
  sectionClass?: string;
  customClass?: any;
}

const SocialSlider: React.FC<SocialSliderProps> = ({
  sectionClass,
  customClass,
  children,
  settings,
}) => {
  const defaultSettings: Settings = {
    infinite: true,
    slidesToShow: 5,
    autoplaySpeed: 2000,
    centerMode: true,
    centerPadding: "200px",
    arrows: false,
    responsive: [
      {
        breakpoint: 1660,
        settings: {
          slidesToShow: 4,
        },
      },
      {
        breakpoint: 1199,
        settings: {
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 991,
        settings: {
          slidesToShow: 3,
          centerPadding: "100px",
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          centerPadding: "80px",
        },
      },
      {
        breakpoint: 575,
        settings: {
          slidesToShow: 1,
          centerPadding: "80px",
        },
      },
    ],
  };

  const sliderSettings = { ...defaultSettings, ...settings };

  return (
    <Slider {...sliderSettings} className={customClass +' '+ sectionClass+'-partner'}>
      {children}
    </Slider>
  );
};

export default SocialSlider;
