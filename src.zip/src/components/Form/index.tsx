// components/MyForm.tsx
import Link from "next/link";
import Image from "next/image";
import React, { useEffect, useState, ChangeEvent, FormEvent } from "react";
import pdfjs from "pdfjs-dist";
import SmoothScrollbar from "smooth-scrollbar";
import mammoth from "mammoth";
interface FormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  linkedIn: string;
  resume: any;
  coverLetter: any;
  resumeAutoFill: any;
  jobTitle: string;
  [key: string]: any;
}

interface FormDataCustom {
  [key: string]: string;
}
interface FormProps {
  formClass?: string;
  labelClass?: string;
  inputClass?: string;
  fileInputClass?: string;
  onChildClick?: any;
  jobTitle?: any;
  questionsData?: any;
}

export const Form: React.FC<FormProps> = ({
  formClass,
  labelClass,
  inputClass,
  fileInputClass,
  onChildClick,
  jobTitle,
  questionsData,
}) => {
  const [showAssessmentTab, setShowAssessmentTab] = useState(false);
  const [showFirstTab, setshowFirstTab] = useState(true);
  const [completeStep, setcompleteStep] = useState("");
  const [loading, setLoading] = useState<any>(false);
  const [formSubmitted, setFormSubmitted] = useState<any>(false);
  const [parsingError, setParsingError] = useState<any>(false);
  const [errors, setErrors] = useState<Partial<FormData>>({});
  const [errorsAsses, setErrorsAsses] = useState<Partial<FormDataCustom>>({});
  const [isResumeDisabled, setIsResumeDisabled] = useState<any>(false);
  const [fileContent, setFileContent] = useState<string>("");
  const [fileName, setFileName] = useState<string>("");
  const [formData, setFormData] = useState<FormData>({
    firstName: "",
    lastName: "",
    jobTitle: "",
    email: "",
    phone: "",
    linkedIn: "",
    resume: null,
    coverLetter: null,
    resumeAutoFill: null,
  });
  const [customFields, setCustomFields] = useState<FormDataCustom>({});
  const [secondForm, setSecondForm] = useState<boolean>(false);
  const clearBasicForm = () => {
    setFormData((prevData) => ({
      ...prevData,
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
    }));
    setErrors({});
  };

  const clearSocialForm = () => {
    setFormData((prevData) => ({
      ...prevData,
      linkedIn: "",
    }));
    setErrors({});
  };


  const validateAssessment = (e: any) => {
    const errors: Partial<FormDataCustom> = {};
    const inputFields = e.target.querySelectorAll("input");
    inputFields.forEach((input: any) => {
      if (input.type === "radio" && input.checked) {
        setCustomFields((prevData) => ({
          ...prevData,
          [input.name]: input.value,
        }));
      } else if (input.type === "text" && input.value !== "") {
        setCustomFields((prevData) => ({
          ...prevData,
          [input.name]: input.value,
        }));
      } else if (input.type === "text" && input.value === "") {
        errors[input.name] = "error";
      }
    });
    setErrorsAsses(errors);
    scrollToBottom();
    return Object.keys(errors).length === 0;
  };
  
  const validateForm = () => {
    const newErrors: Partial<FormData> = {};
    if (!formData.firstName.trim()) {
      newErrors.firstName = "First name is required";
    } else if (!/^[a-zA-Z]+$/.test(formData.firstName)) {
      newErrors.firstName = "First name should contain only letters";
    }

    if (!formData.lastName.trim()) {
      newErrors.lastName = "Last name is required";
    } else if (!/^[a-zA-Z]+$/.test(formData.lastName)) {
      newErrors.lastName = "Last name should contain only letters";
    }

    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Invalid email format";
    }
    if (!formData.phone.trim()) {
      newErrors.phone = "Phone is required";
    } else if (!/^\d+$/.test(formData.phone.trim())) {
      newErrors.phone = "Phone must contain only numeric digits";
    } else if (formData.phone.length > 14) {
      newErrors.phone = "Phone number must not exceed 14 digits";
    }
    if (!formData.linkedIn.trim()) {
      newErrors.linkedIn = "LinkedIn is required"; 
    }

    if (!formData.resume) {
      newErrors.resume = "Resume is required";
    } else if (!/\.(pdf|doc|docx)$/i.test(formData.resume.name)) {
      newErrors.resume =
        "Invalid file format for resume. Supported formats: pdf, doc, docx";
    }
    setErrors(newErrors);
    if (Object.keys(newErrors).length === 0) {
      setLoading(true);
    } else {
      setLoading(false);
    }
    return Object.keys(newErrors).length === 0; // Returns true if there are no errors
  };

  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setErrors((prevData) => ({
      ...prevData,
      [name]: '',
    }));
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };
  const handleResumeChange = (e: ChangeEvent<HTMLInputElement>) => {
    const fileData = e.target.files && e.target.files[0];
    const currentValue = e.target.value;
    const input = e.target;
    e.target.value = "";
    if (currentValue === e.target.value) {
      const event = new Event("change", { bubbles: true });
      input.dispatchEvent(event);
    }
    setErrors((prevData) => ({
      ...prevData,
      resume: '',
    }));
    setFormData((prevData) => ({
      ...prevData,
      resume: fileData || null,
    }));
  };
  const handleCoverLetterChange = (e: ChangeEvent<HTMLInputElement>) => {
    const fileData = e.target.files && e.target.files[0];
    const currentValue = e.target.value;
    const input = e.target;
    e.target.value = "";
    if (currentValue === e.target.value) {
      const event = new Event("change", { bubbles: true });
      input.dispatchEvent(event);
    }
    setErrors((prevData) => ({
      ...prevData,
      coverLetter: '',
    }));
    setFormData((prevData) => ({
      ...prevData,
      coverLetter: fileData || null,
    }));
  };

  const handleFile = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    const filePath = event.target.value;
    setLoading(true);
    if (file) {
      setFileName(file.name);
      if (
        file.type ===
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
      ) {
        const docxContent = await readDocx(file);
        setFileContent(docxContent);
        setParsingError(false);
        const extractedFirstName = extractFirstName(docxContent);
        const extractedLastName = extractLastName(docxContent);
        const extractedPhoneNumber = extractPhoneNumber(docxContent);
        const extractedEmail = extractEmail(docxContent);
        const extractedLinkedInUrl = extractLinkedInUrl(docxContent);
        setTimeout(() => {
          setFormData({
            ...formData,
            firstName: extractedFirstName,
            lastName: extractedLastName,
            phone: extractedPhoneNumber,
            email: extractedEmail,
            linkedIn: extractedLinkedInUrl,
            resume: file,
            resumeAutoFill : false
          });
          setLoading(false);
        }, 2000);

        setIsResumeDisabled(true);
      } else if (file.type === "application/vnd.oasis.opendocument.text") {
        await sendOdttoApi(file);
      } else if (file.type === "text/rtf") {
        await sendRtfApi(file);
      } else if (file.type === "application/pdf") {
        await sendFileToApi(file);
      } else {
        setParsingError(true);
        setLoading(false)
        setFileContent("Unsupported file format");
      }
    }
  };

  const sendFileToApi = async (file: any) => {
    setParsingError(false);
    try {
      const customFormData = new FormData();
      customFormData.append("pdfFile", file);
      const response = await fetch("/api/pdfUtils", {
        method: "POST",
        body: customFormData,
      });

      if (response.ok) {
        const result = await response.json();
        if (result?.pdfData) {
          const pdfText = result?.pdfData;
          const extractedFirstName = extractFirstName(pdfText);
          const extractedLastName = extractLastName(pdfText);
          const extractedPhoneNumber = extractPhoneNumber(pdfText);
          const extractedEmail = extractEmail(pdfText);
          const extractedLinkedInUrl = extractLinkedInUrl(pdfText);
          setTimeout(() => {
            setFormData({
              ...formData,
              firstName: extractedFirstName,
              lastName: extractedLastName,
              phone: extractedPhoneNumber,
              email: extractedEmail,
              linkedIn: extractedLinkedInUrl,
              resume: file,
              resumeAutoFill : false
            });
            setLoading(false);
          }, 2000);
        }
      } else {
        console.error("Failed to send file:", response.statusText);
        setParsingError(true);
        setFormData({
          ...formData,
          resume: null,
        });
        setLoading(false)
      }
    } catch (error) {
      setParsingError(true);
      setFormData({
        ...formData,
        resume: null,
      });
      setLoading(false)
      console.error("Error sending file:", error);
    }
  };

  const readDocx = async (file: File): Promise<string> => {
    const reader = new FileReader();
    return new Promise<string>((resolve) => {
      reader.onload = (event) => {
        const content = (event.target as FileReader).result as ArrayBuffer;
        mammoth
          .extractRawText({ arrayBuffer: content })
          .then((result) => {
            setParsingError(false);
            resolve(result.value);
          })
          .catch(() => {
            setParsingError(true);
            
            resolve("Error reading DOCX file");
          });
      };
      reader.readAsArrayBuffer(file);
    });
  };

  const sendOdttoApi = async (file: any) => {
    try {
      const customFormData = new FormData();
      customFormData.append("odtFile", file);
      const response = await fetch("/api/odtToHtml", {
        method: "POST",
        body: customFormData,
      });
      if (response.ok) {
        const result = await response.json();
        setFileContent(result);
      }
    } catch (error) {
      console.error("Error sending file:", error);
    }
  };

  const sendRtfApi = async (file: any) => {
    try {
      const customFormData = new FormData();
      customFormData.append("rtfFile", file);
      const response = await fetch("/api/rtfRead", {
        method: "POST",
        body: customFormData,
      });
      if (response.ok) {
        const result = await response.json();
        const pdfText = result?.htmlData;
        setFileContent(pdfText);
      }
    } catch (error) {
      console.error("Error sending file:", error);
    }
  };

  const extractFirstName = (docxContent: string): string => {
    const words = docxContent.split(/\s+/);
    return words.length > 0 ? words[1] : "";
  };

  const extractLastName = (docxContent: string): string => {
    const words = docxContent.split(/\s+/);
    return words.length > 0 ? words[2] : "";
  };

  const extractPhoneNumber = (docxContent: string): string => {
    const phoneRegex = /\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b/g;
    const matches = docxContent.match(phoneRegex);
    return matches ? matches[0] : "";
  };

  const extractEmail = (docxContent: string): string => {
    const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g;
    const matches = docxContent.match(emailRegex);
    return matches ? matches[0] : "";
  };

  const extractLinkedInUrl = (docxContent: string): string => {
    const linkedin = /https:\/\/www\.linkedin\.com\/in\/[a-zA-Z0-9_-]+/g;
    const matches = docxContent.match(linkedin);
    return matches ? matches[0] : "";
  };

  const scrollToBottom = () => {
    const containerElement = document.getElementsByClassName(
      "scroller"
    )[0] as HTMLElement;
    const scrollbar = SmoothScrollbar.init(containerElement);
    scrollbar.scrollTo(100, 700, 500);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (showAssessmentTab && validateAssessment(e)) {
      setSecondForm(true);
      sendEmail(customFields, "assessment", "", formData);
      scrollToBottom();
      setTimeout(() => {
        setShowAssessmentTab(false);
        setFormSubmitted(true);
        setLoading(false);
      }, 2000);
    }

    if (showFirstTab && (await validateForm())) {
      setTimeout(() => {
        setShowAssessmentTab(true);
        setshowFirstTab(false);
        sendEmail(
          formData,
          "FormData",
          [formData.resume, formData.coverLetter],
          ""
        );
        setcompleteStep("job-step-complete");
        setLoading(false);
      }, 2000);
    }
  };

  const sendEmail = async (
    emailData: any,
    formType: any,
    filesData: any,
    customFormData: any
  ) => {
    try {
      const formData = new FormData();
      formData.append("emailData", JSON.stringify(emailData));
      formData.append("formType", formType);
      formData.append("extraFormData", JSON.stringify(customFormData));
      if (filesData) {
        filesData?.forEach((file: any, index: number) => {
          formData.append(`file_${index}`, file);
        });
      }
      const response = await fetch("/api/sendEmail", {
        method: "POST",
        body: formData,
      });
      const data = await response.json();
    } catch (error) {
      console.error("Error sending email:", error);
    }
  };

  const handleVlauesChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    const question = e.target.closest("label")?.getAttribute("data-question");
    setFormData((prevData) => ({
      ...prevData,
      [name]: {
        value: value,
        question: question,
      },
    }));
  };
  const handleRadioChange = (data: {
    name: string;
    value: "yes" | "no";
    customType: string;
    question: string;
  }) => {
    setFormData((prevData) => ({
      ...prevData,
      [data.name]: {
        value: data.value,
        question: data.question,
      },
    }));
  };
  const handleCloseClick = (e: any) => {
    e.preventDefault();
    const dataToSend = true;
    onChildClick(dataToSend);
  };

  const handleClearFile = (e: any) => {
    setFormData({
      ...formData,
      resume: null,
    });
  };

  const handleClearCoverFile = (e: any) => {
    setFormData({
      ...formData,
      coverLetter: null,
    });
  };

  const handleClearFileAll = () => {
    setFormData({
      ...formData,
      resume: null,
      coverLetter: null,
    });
  };

  useEffect(() => {
    setFormData({
      ...formData,
      jobTitle: jobTitle,
    });
  }, []);

  useEffect(() => {
    if (customFields && showAssessmentTab && secondForm) {
      sendEmail(customFields, "assessment", formData, "");
    }
  }, [customFields, secondForm, showAssessmentTab]);
  return (
    <div className="job-application--inner paddingT128 paddingB128">
      <div className="container">
        <div className="row">
          <div className="col-10 margin-auto col-12-sm">
            {loading && (
              <div className="loading-screen">
                <div className="loading-img-outer">
                  <Image
                    src="/images/icons/loading.svg"
                    fill
                    loading ="lazy"
                    alt="loading-image"
                  />
                </div>
              </div>
            )}
               {!formSubmitted && (
            <div className="progressBar">
              <div className="job-application job-app-step job-step-complete">
                <div className="job-application-node"></div>
                <div className="job-progress-title">
                  <h5>Application</h5>
                </div>
              </div>
              <div
                className={`job-application job-app-step job-step-inactive ${completeStep}`}
              >
                <div className="job-application-node"></div>
                <div className="job-progress-title">
                  <h5>Assessment</h5>
                </div>
              </div>
            </div>
               )}
            <div className={`autofill-job-application ${formSubmitted ? 'thank-you-page' : '' }`}>
              {showFirstTab && (
                <>
                  <h4> Autofill Application</h4>
                  <p>
                    Upload your resume/cv in seconds with the autofill option.
                  </p>
                </>
              )}
              <div className="job-app-basic-info">
                <form
                  className={formClass}
                  onSubmit={handleSubmit}
                  encType="multipart/form-data"
                >
                  {showFirstTab && (
                    <div>
                      <div
                        className={`autofill-job-resume ${
                          formData.resumeAutoFill !== null
                            ? "disbled-filed"
                            : ""
                        }`}
                      >
                        <div className="file-upload-wrapper">
                          <input
                            type="file"
                            name="resumeAutoFill"
                            accept=".pdf, .doc, .docx"
                            onChange={handleFile}
                            className="fileuploadInput"
                            disabled={
                              formData?.resumeAutoFill !== null ? true : false
                            }
                          />
                          <div className="file-upload-inner">
                            <span className="lyteFileUpdMsg">
                              <p>
                                {" "}
                                <Link href="#!">Upload your resume</Link> or
                                drag and drop it here{" "}
                              </p>
                              <p className="jb-apply-note">
                                Only .doc, .docx, .pdf{""}
                              </p>
                              <p className="cw-apply-note">(Optional)</p>
                            </span>
                          </div>
                        </div>
                        {formData?.resumeAutoFill && (
                          <div className="browse-file-name">
                            Selected file: {formData?.resumeAutoFill?.name}
                          </div>
                        )}
                        {errors?.resumeAutoFill && (
                          <span className="error-message">
                            {errors?.resumeAutoFill}
                          </span>
                        )}
                      </div>
                      {formData?.resume && (
                        <div className="file-uploaded-message">
                          <p>
                            {" "}
                            Resume parsed successfully. Carefully review your
                            information before submitting the application.
                          </p>
                        </div>
                      )}

                      {parsingError && (
                        <div className="file-uploaded-error-message">
                          <p>
                            {" "}
                            Error in parsing the resume. Please review your resume carefully.
                          </p>
                        </div>
                      )}


                      <div className="form-title">
                        <h5> Basic Info </h5>{" "}
                        <span className="clear-link" onClick={clearBasicForm}>
                          -Clear
                        </span>
                      </div>
                      <label
                        className={`${labelClass || ""}${
                          errors?.firstName ? "showErrors" : ""
                        }`}
                      >
                        First Name:<span className="asterisk">*</span>
                        <input
                          type="text"
                          name="firstName"
                          value={formData?.firstName}
                          onChange={handleInputChange}
                          onFocus={handleInputChange}
                          className={inputClass}
                          maxLength={30}
                        />
                        <input type="hidden" name="jobTitle" value={jobTitle} />
                        {errors?.firstName && (
                          <span className="error-message">
                            {errors?.firstName}
                          </span>
                        )}
                      </label>
                      <label
                        className={`${labelClass || ""}${
                          errors?.lastName ? "showErrors" : ""
                        }`}
                      >
                        Last Name:<span className="asterisk">*</span>
                        <input
                          type="text"
                          name="lastName"
                          maxLength={30}
                          value={formData?.lastName}
                          onChange={handleInputChange}
                          // onBlur={onBlurFieldHanlder}
                          className={inputClass}
                        />
                        {errors?.lastName && (
                          <span className="error-message">
                            {errors?.lastName}
                          </span>
                        )}
                      </label>
                      <label
                        className={`${labelClass || ""}${
                          errors?.email ? "showErrors" : ""
                        }`}
                      >
                        Email:<span className="asterisk">*</span>
                        <input
                          type="email"
                          name="email"
                          value={formData?.email}
                          onChange={handleInputChange}
                          // onBlur={onBlurFieldHanlder}
                          className={inputClass}
                        />
                        {errors?.email && (
                          <span className="error-message">{errors?.email}</span>
                        )}
                      </label>
                      <label
                        className={`${labelClass || ""}${
                          errors?.phone ? "showErrors" : ""
                        }`}
                      >
                        Phone:<span className="asterisk">*</span>
                        <input
                          type="tel"
                          name="phone"
                          value={formData?.phone}
                          maxLength={14}
                          onChange={handleInputChange}
                          className={inputClass}
                          //  onBlur={onBlurFieldHanlder}
                        />
                        {errors?.phone && (
                          <span className="error-message">{errors?.phone}</span>
                        )}
                      </label>
                      <div className="form-title">
                        <h5> Social Network </h5>{" "}
                        <span className="clear-link" onClick={clearSocialForm}>
                          -Clear
                        </span>
                      </div>
                      <label
                        className={`${labelClass || ""}${
                          errors?.linkedIn ? "showErrors" : ""
                        }`}
                      >
                        LinkedIn: <span className="asterisk">*</span>
                        <input
                          type="text"
                          name="linkedIn"
                          value={formData?.linkedIn}
                          onChange={handleInputChange}
                          className={inputClass}
                          // onFocus={onBlurFieldHanlder}
                        />
                        {errors?.linkedIn && (
                          <span className="error-message">
                            {errors?.linkedIn}
                          </span>
                        )}
                      </label>
                      <div className="form-title">
                        <h5> Attachment Information </h5>{" "}
                        <span
                          className="clear-link"
                          onClick={handleClearFileAll}
                        >
                          -Clear
                        </span>
                      </div>
                      <label
                        className={`${fileInputClass} ${
                          errors?.resume ? "showErrors" : ""
                        }`}
                      >
                        Resume: <span className="asterisk">*</span>
                        <div
                          className={`file-Browse ${
                            formData?.resume !== null ? "disabled-field" : ""
                          }`}
                        >
                          <input
                            type="file"
                            name="resume"
                            accept=".pdf, .doc, .docx"
                            onChange={handleResumeChange}
                            className={inputClass}
                            disabled={formData?.resume !== null ? true : false}
                          />
                          <span>Browse</span>
                        </div>
                        {errors?.resume && (
                          <span className="error-message">{errors?.resume}</span>
                        )}
                      </label>
                      {formData?.resume && (
                        <div className="browse-file-name file-upload-class">
                          Selected file: {formData?.resume?.name}
                          <div
                            className="close-input"
                            onClick={handleClearFile}
                          >
                            <span className="demo-icon icon-cancel"></span>
                          </div>
                        </div>
                      )}
                      <label className={fileInputClass}>
                        Cover Letter:
                        <div
                          className={`file-Browse ${
                            formData?.coverLetter !== null
                              ? "disabled-field"
                              : ""
                          }`}
                        >
                          <input
                            type="file"
                            name="coverLetter"
                            accept=".pdf, .doc, .docx"
                            onChange={handleCoverLetterChange}
                            className={inputClass}
                            disabled={
                              formData?.coverLetter !== null ? true : false
                            }
                          />
                          <span>Browse</span>
                        </div>
                        {errors?.coverLetter && (
                          <span className="error-message">
                            {errors?.coverLetter}
                          </span>
                        )}
                      </label>
                      {formData?.coverLetter && (
                        <div className="browse-file-name file-upload-class">
                          Selected file: {formData?.coverLetter?.name}
                          <div
                            className="close-input"
                            onClick={handleClearCoverFile}
                          >
                            <span className="demo-icon icon-cancel"></span>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                  {showAssessmentTab && (
                    <div className="assessment-queries-tab">
                      <h6 className="form-sub-heading"> Questions</h6>
                      <p>
                        {" "}
                        <strong> Application Questionnaire</strong>{" "}
                      </p>
                      {questionsData?.items?.map((question: any, key: any) => {
                        return (
                          <div key={key}>
                            {question?.fieldType == "Text" && (
                              <label
                                data-question={question?.fieldLabel}
                                className={`${labelClass}${
                                  errorsAsses[
                                    `custom_${question?.fieldName}` as keyof Partial<FormData>
                                  ] && "showErrors"
                                }`}
                              >
                                {question?.fieldLabel}{" "}
                                {question?.required && (
                                  <span className="asterisk">*</span>
                                )}
                                <input
                                  type="text"
                                  name={`custom_${question?.fieldName}`}
                                  value={
                                    formData[
                                      `custom_${question?.fieldName}` as keyof Partial<FormData>
                                    ]?.value || ""
                                  }
                                  onChange={handleVlauesChange}
                                  className={inputClass}
                                />
                                {errorsAsses[
                                  `custom_${question?.fieldName}` as keyof Partial<FormData>
                                ] && (
                                  <span className="error-message">
                                    {question?.errorMessage}
                                  </span>
                                )}
                              </label>
                            )}
                            {question.fieldType == "Radio" && (
                              <label data-question={question?.fieldLabel}>
                                {question?.fieldLabel}{" "}
                                {question?.required && (
                                  <span className="asterisk">*</span>
                                )}
                                <div className="quetion-option-type">
                                  <label>
                                    <input
                                      type="radio"
                                      name={`custom_${question?.fieldName}`}
                                      value="yes"
                                      onChange={(e: any) =>
                                        handleRadioChange({
                                          value: e.target.value,
                                          name: e.target.name,
                                          customType: e.target.type,
                                          question: question?.fieldLabel,
                                        })
                                      }
                                    />{" "}
                                    Yes
                                  </label>
                                  <label>
                                    <input
                                      type="radio"
                                      name={`custom_${question?.fieldName}`}
                                      value="no"
                                      onChange={(e: any) =>
                                        handleRadioChange({
                                          value: e.target.value,
                                          name: e.target.name,
                                          customType: e.target.type,
                                          question: question?.fieldLabel,
                                        })
                                      }
                                    />{" "}
                                    No
                                  </label>
                                </div>
                              </label>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                  <div className="step-buttons">
                    {showFirstTab && (
                      <>
                        <button
                          type="button"
                          onClick={handleCloseClick}
                          className="globalButton outlineBtn"
                        >
                          Cancel
                        </button>
                        <button className="globalButton" type="submit">
                          Next
                        </button>
                      </>
                    )}
                    {showAssessmentTab && (
                      <button className="globalButton" type="submit">
                        Submit Assessment
                      </button>
                    )}
                  </div>
                </form>
                {formSubmitted && (
                  <div className="job-application-thankyou">
                    <div className="thankyou-image-outer">
                      <Image
                        fill
                        loading ="lazy"
                        src="/images/thank-you.svg"
                        alt="thank you"
                      />
                    </div>
                    <h4> Thank you for your job application </h4>
                    <div className="goHome">
                      <Link
                        className="globalButton withCircle contact-cta"
                        aria-label="Go to home"
                        href="/"
                      >
                        Go to home
                      </Link>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
