// components/SmoothScroller.tsx
import React, { useEffect, useRef, ReactNode } from 'react';
import Scrollbar from 'smooth-scrollbar';
import useWindowSize from '@/utils/hooks/useWindowSize';

interface SmoothScrollerProps {
  children: ReactNode;
}

const SmoothScroller: React.FC<SmoothScrollerProps> = ({ children }) => {
  const scrollbarRef = useRef<HTMLDivElement>(null);
  const { width } = useWindowSize();

  useEffect(() => {
    if (scrollbarRef.current && width > 767) {
      const options = {
        damping: 0.9, // Customize this value
        thumbMinSize: 20,
        renderByPixels: true,
        alwaysShowTracks: false,
        continuousScrolling: true,
      };

      const scrollbar = Scrollbar.init(scrollbarRef.current, options);

      return () => {
        if (scrollbar) {
          scrollbar.destroy();
        }
      };
    }
  }, [width]);

  return (
    <div
      ref={scrollbarRef}
      className='inner-smooth-scrollbar'
    >
      <div style={{ padding: '20px', overflowX: 'auto' }}>
        {children}
      </div>
    </div>
  );
};

export default SmoothScroller;
