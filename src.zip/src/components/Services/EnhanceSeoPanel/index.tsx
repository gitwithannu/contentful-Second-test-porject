import { HTMLAttributes, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import Image from "next/image";
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
import { useRouter } from 'next/router';
import parse from 'html-react-parser';

interface EnhanceSeoProps{
  singleBannerImageAlt?: any,
  singleBannerImageURL?: any,
  singleBannerMobImageURL?: any,
  singleBannerMobImageAlt?: any,
  title?: any,
  subtitle?: any,
  description?: any
}
const EnhanceSeoPanel: React.FC<EnhanceSeoProps> = ({ title, subtitle, description, singleBannerImageURL, singleBannerMobImageURL, singleBannerImageAlt, singleBannerMobImageAlt }) => {
  const router = useRouter();
  const enhanceSeoPanelRef = useRef<HTMLDivElement>(null);
  // const data = JSON.parse(panelData?.panelData);
  // let description = documentToPlainTextString(data?.description?.json);
  // if (description) {
  //   description = description
  // } else {
  //   description = ''
  // }
  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      // Add the Contact Team Section animation steps to the timeline
      //setTimeout(() => {
       
      gsap.set(".enhanceSeobanner", { yPercent: 0 });
      gsap.set(".enhanceSeoContent", { yPercent: 100, opacity: 0 });
      gsap.set(".enhanceLeft", { xPercent: -10, scale: 0.2, opacity: 0 });
      const enhanceSeoPanelTl = gsap.timeline({});
      ScrollTrigger.create({
        animation: enhanceSeoPanelTl,
        trigger: enhanceSeoPanelRef.current,
        start: "top top",
        end: "bottom center",
        pin: enhanceSeoPanelRef.current,
        scrub: true,
        onToggle: scrollTrigger => {
          // refresh because height start changes
          scrollTrigger.refresh()
        },
      });

      enhanceSeoPanelTl
        .to(".enhanceSeobanner", { yPercent: -100, duration: 5, opacity: 1 })
        .to(".enhanceSeoContent",{ yPercent: 0, opacity: 1, duration: 10, ease: "Power4.easeOut" },"<");
      
      //}, 3000);
    }, enhanceSeoPanelRef);

    return () => ctx.revert();
  }, []);

  return (
    <section className={`enhanceSeoPin aecloudSection`} ref={enhanceSeoPanelRef}>
      <div className="enhanceSeo">
      <div className="enhanceSeobanner">
          <Image
            className="desktopView"
            src={singleBannerImageURL}
            fill
            loading ="lazy"
            alt={singleBannerImageAlt}
          />
          <Image
            className="mobileView"
            src={singleBannerMobImageURL}
            fill
            loading ="lazy"
            alt={singleBannerMobImageAlt}
          />
        </div>
        <div className="enhanceSeoBottom paddingY128">
          <div className="container">
            <div className="row">
              <div className="col-5 enhanceLeft"></div>
              <div className="col-7">
                <div className="enhanceSeoContent">
                  <h3 className="enhanceSeoContentHeading">{title}</h3>
                  <h5 className="enhanceSeoContentSubHeading">{parse(subtitle)}</h5>
                  <div className="enhanceSeoContentText">{parse(description)}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
export default EnhanceSeoPanel;
