import { useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import Image from "next/image";
import parse from "html-react-parser";
import ServicesCard from "../SingleCard";
import { useRouter } from 'next/router';
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))

interface CardGidProps {
  cardData?: any;
  item?: string;
  reverse?: boolean;
  flexibleCol?: boolean;
  customClass?: boolean;
  sectionClass?:string
  bottomTagLine?: boolean;
  tagline?: any;
}
const CardGrid: React.FC<CardGidProps> = ({
  cardData,
  item,
  reverse,
  flexibleCol,
  sectionClass,
  customClass,
  bottomTagLine,
  tagline,
}) => {
  
  const CardGridRef = useRef<HTMLDivElement>(null);
  const router = useRouter();
  useIsomorphicLayoutEffect(() => {
    const pinnedRefEl = CardGridRef.current;
    let timer: string | number | NodeJS.Timeout | undefined;
    if (!pinnedRefEl) return;
    let ctx = gsap.context(() => {
      // Add the Contact Team Section animation steps to the timeline
      // timer = setTimeout(() => {
        // if(router){
      gsap.set(
        ".ImageCardPin .ImageCard .ImageCardWraper-2, .ImageCardPin .ImageCard .ImageCardWraper-3",
        { yPercent: 100 }
      );
      gsap.set(".ImageCardPin .ImageCard .ImageCardWraper-1", {
        yPercent: 15,
      });
      

      const ImageCardT1 = gsap.timeline({});
      let mm = gsap.matchMedia();
      mm.add("(min-width: 1280px)", () => {
        ScrollTrigger.create({
          animation: ImageCardT1,
          trigger: CardGridRef.current,
          start: "top 40%",
          end: "bottom center",
          scrub: true,
          invalidateOnRefresh : true,
          onToggle: scrollTrigger => {
            // refresh because height start changes
            scrollTrigger.refresh()
          },
        });
      });
      mm.add("(max-width: 1280.98px)", () => {
        ScrollTrigger.create({
          animation: ImageCardT1,
          trigger: CardGridRef.current,
          start: "top 70%",
          end: "bottom",
          scrub: true,
          invalidateOnRefresh : true,
          onToggle: scrollTrigger => {
            // refresh because height start changes
            scrollTrigger.refresh()
          },
        });
      });
      ImageCardT1.to(".ImageCardPin .ImageCardWraper-2", {
        yPercent: 0,
        duration: 2,
        ease: "Power4.easeOut",
      }).to(
        ".ImageCardPin .ImageCardWraper-3",
        { yPercent: 0, duration: 10, ease: "Power4.easeOut" },
        "<50%"
      );
    // }
      // }, 1000);
    }, CardGridRef);

    return () => {
      // clearTimeout(timer);
      ctx.revert();
    }
  });

  return (
    <section
      className={`ImageCardPin ${flexibleCol ? "colSize" : ""} ${sectionClass}`}
      ref={CardGridRef}
    >
      <section
        className="ImageCard lightBackground autoHeight"
        ref={CardGridRef}
      >
        <section
          className="ImageCardPin-2 autoHeight paddingY128"
          ref={CardGridRef}
        >
          <div className="ImageCardWraper autoHeight ImageCardWraper-2">
            <div className="container">
              <div className={`ImageCardItem autoHeight`}>
                <div
                  className={`row ImageCardItemRow fullBlock ${
                    reverse ? "flex-reverse" : ""
                  }`}
                >
                  <div className="col-6">
                    <div className="ImageCardImage">
                    <ImageConversion
                      url={cardData?.imageUrl}
                      altext={cardData?.imageAlt}
                      />
                    </div>
                  </div>
                  <div className="col-6">
                    <div className="ImageCardContact">
                      <h5>{parse(cardData?.title)}</h5>
                      {cardData?.desc && parse(cardData?.desc)}
                    </div>
                  </div>
                </div>

                {cardData?.data !== undefined && cardData?.data.length > 0 && (
                  <div
                    className={`${"InnerCardRow"} ${
                      customClass ? "customClass" : ""
                    }`}
                  >
                    <div className="row ImageCardItemRow">
                      {cardData?.data !== undefined &&
                        cardData?.data.length > 0 &&
                        cardData?.data.map(
                          (
                            item: {
                              icon: boolean | undefined;
                              title: string | undefined;
                              desc: string | undefined;
                              titleShow: boolean | undefined;
                            },
                            key: any
                          ) => (
                            <ServicesCard
                              key={item?.title}
                              serviceCardHeading={item?.title}
                              serviceCardDescription={item?.desc}
                              icon={item?.icon}
                              counter={item?.icon}
                              titleShow = {item?.titleShow }
                            />
                          )
                        )}
                    </div>
                  </div>
                )}
                {bottomTagLine ? <div className="bottomCardPanel"> {parse(tagline)} </div> : ""}
              </div>
            </div>
          </div>
        </section>
      </section>
    </section>
  );
};
export default CardGrid;
