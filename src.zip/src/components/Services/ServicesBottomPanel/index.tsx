import { useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import Image from "next/image";
import { useRouter } from 'next/router' 
import parse from 'html-react-parser';
import Link from "next/link";

interface ServicesBottomProps extends React.HTMLAttributes<HTMLDivElement> {
  teamContactDesc?: string | any;
  ctaText?: string;
  ctaUrl?:any
}
const ServicesBottomPanel: React.FC<ServicesBottomProps> = ({
  teamContactDesc,
  ctaText,
  ctaUrl
}) => {
  const ServicesBottomPanelRef = useRef<HTMLDivElement>(null);
  const router = useRouter();
  useIsomorphicLayoutEffect(() => {
    const pinnedRefEl = ServicesBottomPanelRef.current;
    let timer: string | number | NodeJS.Timeout | undefined;
    if (!pinnedRefEl) return;
    let ctx = gsap.context(() => {
      // Add the Contact Team Section animation steps to the timeline
      timer = setTimeout(() => {
      // if(router){
      gsap.set(".teamContactWrap .teamContactContent", {
        yPercent: -100,
        opacity: 0,
      });
      gsap.set(".teamContactWrap .contact-cta", {
        yPercent: 30,
        opacity: 0,
      });
      const scheduleTl = gsap.timeline({});

      ScrollTrigger.create({
        animation: scheduleTl,
        trigger: ServicesBottomPanelRef.current,
        start: "top 60%",
        end: "bottom center",
        scrub: true,
        onToggle: scrollTrigger => {
          // refresh because height start changes
          scrollTrigger.refresh()
        },
      });

      scheduleTl
        .to(
          ".teamContactWrap .teamContactContent",
          {
            yPercent: 0,
            opacity: 1,
            duration: 1,
          },
          "<"
        )
        .to(".teamContactWrap .contact-cta", {
          yPercent: 0,
          duration: 1,
          opacity: 1,
        });
      // }
      }, 1000);
    }, ServicesBottomPanelRef);

    return () =>{
       clearTimeout(timer);
       ctx.revert();
    }
  });
  return (
    <section className="truAdsSolutions" ref={ServicesBottomPanelRef}>
      <section className="teamContact teamContact-1 paddingY128 dark">
        <div className="teamContactWrap">
          <h5 className="teamContactContent">{parse(teamContactDesc)}</h5>
          <Link
            href={ctaUrl}
            className="globalButton withCircle  contact-cta"
            aria-label={ctaText}
          >
            {ctaText}
          </Link>
        </div>
      </section>
    </section>
  );
};
export default ServicesBottomPanel;
