import { useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import parse from "html-react-parser";
import { useRouter } from 'next/router';
interface ServicesInfoprops extends React.HTMLAttributes<HTMLDivElement> {
  bannerHeading?: any;
  bannerSubHeading?: any;
  bannerDescription?: any;
}
const ServicesBlowPanel: React.FC<ServicesInfoprops> = ({
  bannerHeading,
  bannerSubHeading,
  bannerDescription,
}) => {
  const ServicesBlowPanelRef = useRef<HTMLDivElement>(null);
  const router = useRouter();
  useIsomorphicLayoutEffect(() => {
    const pinnedRefEl = ServicesBlowPanelRef.current;
    let timer: string | number | NodeJS.Timeout | undefined;
    if (!pinnedRefEl) return;
    let ctx = gsap.context(() => {
      // Add the Single banner Blow Section animation steps to the timeline
      timer = setTimeout(() => {
        let mm = gsap.matchMedia();
        mm.add("(min-width: 1299.99px)", () => {
          gsap.set(".blowInnerBannerHeading", { scale: 2, opacity: 0 });
          gsap.set(".blowInnerBannerSubHeading", { yPercent: 40, opacity: 0 });
        })
        
        gsap.set(".blowInnerBannerSubText", { yPercent: 40, opacity: 0 });

        const ServicesBlowPanelTl = gsap.timeline({});
           
        mm.add("(min-width: 1299.99px)", () => {
          ScrollTrigger.create({
            animation: ServicesBlowPanelTl,
            trigger: ServicesBlowPanelRef.current,
            start: "top 70%",
            end: "bottom center",
            scrub: true,
            onToggle: scrollTrigger => {
              // refresh because height start changes
              scrollTrigger.refresh()
            },
          });
        });
            
        ServicesBlowPanelTl
            .to(".blowInnerBannerHeading", { scale: 1, duration: 20, opacity: 1, ease: "Power4.easeOut" })
            .to(".blowInnerBannerSubHeading", { yPercent: 0, opacity: 1, duration: 10, ease: "Power4.easeOut" },"<40%")
            .to(".blowInnerBannerSubText", { yPercent: 0, opacity: 1, duration: 10, ease: "Power4.easeOut" }, "<60%");

      mm.add("(max-width: 1299.98px) and (min-width: 200.98px)", () => {
        ScrollTrigger.create({
          animation: ServicesBlowPanelTl,
          trigger: ServicesBlowPanelRef.current,
          start: "top 100%",
          end: "bottom center",
          scrub: true,
          onToggle: scrollTrigger => {
            // refresh because height start changes
            scrollTrigger.refresh()
          },
        });
        gsap.set(".blowInnerBannerHeading", {
          scale: 1,
          xPercent:0,
          opacity: 1,
        });
        gsap.set(".blowInnerBannerSubHeading", { yPercent: 0, opacity: 1 });
      });

      }, 1000);
    }, ServicesBlowPanelRef);

    return () => {
      clearTimeout(timer);
      ctx.revert();
    }
  });
  return (
    <div className="blowInnerBannerWrap" ref={ServicesBlowPanelRef}>
      <h3 className="blowInnerBannerHeading">{parse(bannerHeading)}</h3>
      <h4 className="blowInnerBannerSubHeading">{parse(bannerSubHeading)}</h4>
      <p className="blowInnerBannerSubText">{parse(bannerDescription)} </p>
    </div>
  );
};
export default ServicesBlowPanel;
