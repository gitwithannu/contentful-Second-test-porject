import { useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import parse from "html-react-parser";
interface ServicesCardProps extends React.HTMLAttributes<HTMLDivElement> {
  serviceCardHeading?: string;
  serviceCardDescription?: any;
  gridFlexible?: boolean;
  icon?: any;
  counter?: any;
  titleShow?:any
}

const ServicesCard: React.FC<ServicesCardProps> = ({
  serviceCardHeading,
  serviceCardDescription,
  icon,
  counter,
  titleShow
}) => {
  const ServicesCardRef = useRef<HTMLDivElement>(null);
  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      // Add the Contact Team Section animation steps to the timeline
      gsap.set(".InnerCardRow", { yPercent: 100, opacity: 0 });

      const ImageCardT1 = gsap.timeline({});

      ScrollTrigger.create({
        animation: ImageCardT1,
        trigger: ServicesCardRef.current,
        start: "top top",
        end: "+=600px",
        scrub: true,
        onToggle: scrollTrigger => {
          // refresh because height start changes
          scrollTrigger.refresh()
        },
      });

      ImageCardT1.to(".InnerCardRow", {
        yPercent: 0,
        duration: 10,
        ease: "Power4.easeOut",
      });
    }, ServicesCardRef);

    return () => ctx.revert();
  }, []);
  return (
    <div className="col-4 innerCardCol" ref={ServicesCardRef}>
      <div className="InnerCardItem InnerCardItemDesc">
        <div className="numberPanel">
          {icon ? <span className="numberCount">{counter}</span> : ""}
          {serviceCardHeading && titleShow && <h6>{parse(serviceCardHeading)}</h6> }
        </div>
        {parse(serviceCardDescription)}
      </div>
    </div>
  );
};
export default ServicesCard;
