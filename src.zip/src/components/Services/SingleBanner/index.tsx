import { HTMLAttributes, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import Image from "next/image";
import { useRouter } from 'next/router';
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))


interface EnhanceSeoProps extends HTMLAttributes<HTMLDivElement> {
  singleBannerImageAlt?: any;
  singleBannerImageURL?: any;
  singleBannerMobImageURL?: any;
  singleBannerMobImageAlt?: any;
}
const SingleBanner: React.FC<EnhanceSeoProps> = ({
  singleBannerImageAlt,
  singleBannerImageURL,
  singleBannerMobImageURL,
  singleBannerMobImageAlt,
}) => {
  const singleBannerRef = useRef<HTMLDivElement>(null);
  const router = useRouter();

  useIsomorphicLayoutEffect(() => {
    const pinnedRefEl = singleBannerRef.current;
    let timer: string | number | NodeJS.Timeout | undefined;
    if (!pinnedRefEl) return;
    let ctx = gsap.context(() => {
      // Add the Contact Team Section animation steps to the timeline
     timer = setTimeout(() => {
        // if(router){
      gsap.set(".enhanceSeoInnerbanner", { yPercent: 100, opacity: 0 });
      gsap.set(".enhanceSeoContent", { yPercent: 100, opacity: 0 });
      gsap.set(".enhanceLeft", { xPercent: -10, scale: 0.2, opacity: 0 });
      const singleBannerTl = gsap.timeline({});
      ScrollTrigger.create({
        animation: singleBannerTl,
        trigger: singleBannerRef.current,
        start: "top 60%",
        end: "bottom center",
        scrub: true,
        onToggle: scrollTrigger => {
          // refresh because height start changes
          scrollTrigger.refresh()
        },
      });

      singleBannerTl
        .to(".enhanceSeoInnerbanner", {
          yPercent: 0,
          duration: 10,
          opacity: 1,
        })
        .to(
          ".enhanceSeoContent",
          { yPercent: 0, opacity: 1, duration: 10, ease: "Power4.easeOut" },
          "<30%"
        );
      // }
      }, 1000);
    }, singleBannerRef);

    return () => {
      clearTimeout(timer)
      ctx.revert();
    }
  });
  return (
    <section className="enhanceSeoPin-2" ref={singleBannerRef}>
      <section className="enhanceSeo">
        <div className="enhanceSeoInnerbanner">
        <ImageConversion
            url={singleBannerImageURL}
            altext={singleBannerImageAlt}
            className="desktopView"
          />
          <ImageConversion
            
            url={singleBannerMobImageURL}
            altext={singleBannerMobImageAlt}
            className="mobileView"
          />
        </div>
      </section>
    </section>
  );
};
export default SingleBanner;
