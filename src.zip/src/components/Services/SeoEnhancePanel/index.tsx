import { useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import Image from "next/image";
import router, { useRouter } from 'next/router';
import parse from 'html-react-parser';

interface EnhanceSeoProps {
  singleBannerImageAlt?: any;
  singleBannerImageURL?: any;
  singleBannerMobImageURL?: any;
  singleBannerMobImageAlt?: any;
  enhanceSeoPinImage?: boolean;
  title?: any;
  subtitle?: any;
  description?: any;
  panelData? : any
}
const SeoEnhancePanel: React.FC<EnhanceSeoProps> = ({ title, subtitle, description, singleBannerImageURL, singleBannerMobImageURL, singleBannerImageAlt, singleBannerMobImageAlt }) => {
  const seoEnhancePanelRef = useRef<HTMLDivElement>(null);
  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      // Add the Contact Team Section animation steps to the timeline
      //setTimeout(() => {
        // router.events.on("routeChangeComplete", () => {
        gsap.set(".enhanceSeobanner", { yPercent: 0 });
        gsap.set(".enhanceSeoContent", { yPercent: 100, opacity: 0 });
        gsap.set(".enhanceLeft", { xPercent: -10, scale: 0.2, opacity: 0 });
        const seoEnhancePanelTl = gsap.timeline({});
        ScrollTrigger.create({
          animation: seoEnhancePanelTl,
          trigger: seoEnhancePanelRef.current,
          start: "top top",
          end: "bottom center",
          pin: seoEnhancePanelRef.current,
          scrub: true,
          onToggle: scrollTrigger => {
            // refresh because height start changes
            scrollTrigger.refresh()
          },
        });
    
        seoEnhancePanelTl
          .to(".enhanceSeobanner",{ yPercent: -100, duration: 5, opacity: 1 })
          .to(".enhanceSeoContent",{ yPercent: 0, opacity: 1, duration: 10, ease: "Power4.easeOut" },"<");
      // })
      
          //}, 3000);
        }, seoEnhancePanelRef);
    
        return () => ctx.revert();
      }, []);
    
  return (
    <div className={`enhanceSeoPin`} ref={seoEnhancePanelRef}>
      <div className="enhanceSeo">
      </div>
    </div>
  );
};
export default SeoEnhancePanel;
