import { useRef } from "react";
import "slick-carousel/slick/slick.css";
// import "slick-carousel/slick/slick-theme.css";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useRouter } from 'next/router'
import parse from 'html-react-parser';
interface ServicesProductSliderProps
  extends React.HTMLAttributes<HTMLDivElement> {
  children?: JSX.Element | JSX.Element[];
  sliderHeading?: string | any;
  flexibleSpace?: boolean;
  customClass?:string
}
const ServicesProductSlider: React.FC<ServicesProductSliderProps> = ({
  children,
  sliderHeading,
  flexibleSpace,
  customClass
}) => {
  const productSliderRef = useRef<HTMLDivElement>(null);
  const router = useRouter();
  useIsomorphicLayoutEffect(() => {
    const pinnedRefEl = productSliderRef.current;
    let timer: string | number | NodeJS.Timeout | undefined;
    if (!pinnedRefEl) return;
    let ctx = gsap.context(() => {
      // Add the Contact Team Section animation steps to the timeline
      timer = setTimeout(() => {
        // if(router){
      gsap.set(".ourProductHeading", { xPercent: 10, opacity: 0 });
      gsap.set(".ourProductContent", { xPercent: 60, opacity: 0 });
      gsap.set(".cardCarouselProduct", { yPercent: 160, opacity: 0 });
 
      const ourProductTwoTl = gsap.timeline({});

      ScrollTrigger.create({
        animation: ourProductTwoTl,
        trigger: productSliderRef.current,
        start: "top 40%",
        end: "bottom center",
        scrub: true,
        onToggle: scrollTrigger => {
          // refresh because height start changes
          scrollTrigger.refresh()
        },
      });

      ourProductTwoTl
        .to(".ourProductHeading", {
          xPercent: 0,
          opacity: 1,
          duration: 5,
          ease: "Power4.easeOut",
        })
        .to(
          ".ourProductContent",
          { xPercent: 0, opacity: 1, duration: 10, ease: "Power4.easeOut" },
          "<"
        )
        .to(
          ".cardCarouselProduct",
          { yPercent: 0, opacity: 1, duration: 5, ease: "Power4.easeOut" },
          "<"
        );
      // }
      }, 1000);
    }, productSliderRef);

    return () => {
      clearTimeout(timer);
      ctx.revert();
    }
  });
  return (
    <div>
      <div className="productSliderPanel" ref={productSliderRef}>
        <div className={`ourProductCarousel paddingY128 ${customClass}`}>
          <div className="container">
            <div className="row">
              <div className="col-12">
                <h3 className="ourProductHeading">{parse(sliderHeading)}</h3>
              </div>
            </div>
          </div>
          <div className={`ourSliderMain ${flexibleSpace ? "noMargin" : ""}`}>
            {children}
          </div>
        </div>
      </div>
    </div>
  );
};
export default ServicesProductSlider;
