import { useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import { useRouter } from 'next/router';
interface PartnerSlider extends React.HTMLAttributes<HTMLDivElement> {
  children?: JSX.Element | JSX.Element[];
}
const OurPartnerPanel: React.FC<PartnerSlider> = ({ children }) => {
  const OurPartnerPanelRef = useRef<HTMLDivElement>(null);
  const router = useRouter();

  useIsomorphicLayoutEffect(() => {
    const pinnedRefEl = OurPartnerPanelRef.current;
    let timer: string | number | NodeJS.Timeout | undefined;
    if (!pinnedRefEl) return;
    let ctx = gsap.context(() => {
      // Add the Contact Team Section animation steps to the timeline
      timer = setTimeout(() => {
        // if(router){
      gsap.set(".partnerLogo", { yPercent: 100, opacity: 0 });

      const OurpartnerT1 = gsap.timeline({});
      ScrollTrigger.create({
        animation: OurpartnerT1,
        trigger: OurPartnerPanelRef.current,
        start: "top 50%",
        end: "bottom center",
        scrub: true,
        onToggle: scrollTrigger => {
          // refresh because height start changes
          scrollTrigger.refresh()
        },
      });

      OurpartnerT1.to(".partnerLogo", {
        yPercent: 0,
        opacity: 1,
        duration: 4,
        ease: "Power4.easeOut",
      });
    // }
      }, 1000);
    }, OurPartnerPanelRef);

    return () => {
      clearTimeout(timer);
      ctx.revert();
    }
  });
  return (
    <section className="OurpartnerPin" ref={OurPartnerPanelRef}>
      <section className="OurpartnerService ">
        <div className="partnerLogo partnerLogoCustomWidth paddingB128 socialIcons">
          {children}
        </div>
      </section>
    </section>
  );
};
export default OurPartnerPanel;
