import { HTMLAttributes, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import Image from "next/image";
import router, { useRouter } from 'next/router';
import parse from 'html-react-parser';
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))


interface EnhanceSeoProps extends HTMLAttributes<HTMLDivElement> {
  singleBannerImageAlt?: any;
  singleBannerImageURL?: any;
  singleBannerMobImageURL?: any;
  singleBannerMobImageAlt?: any;
  enhanceSeoPinImage?: boolean;
  title?: any;
  subtitle?: any;
  description?: any;
  panelData?: any;
  customClass?: any;
}
const SeoEnhance: React.FC<EnhanceSeoProps> = ({ title, subtitle, description, singleBannerImageURL, singleBannerMobImageURL, singleBannerImageAlt, singleBannerMobImageAlt, customClass }) => {
  const seoEnhanceRef = useRef(null);
  const pinnedRefEl = seoEnhanceRef.current;
     useIsomorphicLayoutEffect(() => {
      let timer: string | number | NodeJS.Timeout | undefined;
        let ctx = gsap.context(() => {
      // Add the Contact Team Section animation steps to the timeline
      timer = setTimeout(() => {
        const seoEnhanceTl = gsap.timeline({});
          gsap.set('.enhanceSeobanner', { yPercent: 50 });
          gsap.set('.enhanceSeoContentHeading, .enhanceSeoContentSubHeading, .enhanceSeoContentText', { yPercent: 80, opacity: 0 });
          
          ScrollTrigger.create({
            animation: seoEnhanceTl,
            trigger: seoEnhanceRef.current,
            start: "top 90%",
            end: "+=1000px",
            scrub: true,
            onToggle: scrollTrigger => {
              // refresh because height start changes
              scrollTrigger.refresh()
            },
          });
    
          seoEnhanceTl
            .to(".enhanceSeobanner", { yPercent: 0 })
            .to(".enhanceSeoContentHeading", { yPercent: 0, opacity: 1 }, '<80%')
            .to(".enhanceSeoContentSubHeading", { yPercent: 0, opacity: 1 }, '<')
            .to(".enhanceSeoContentText", { yPercent: 0,  opacity: 1 }, '<');

          }, 1000);
        }, seoEnhanceRef);
        
        return () => {
          clearTimeout(timer);
          ctx.revert();
        }
      });
  return (
  <section className={`enhanceSeoPin ${customClass}`} >
      <div className="enhanceSeo" ref={seoEnhanceRef}>
        <div className="enhanceSeobanner">
        <ImageConversion
            url={singleBannerImageURL}
            altext={singleBannerImageAlt}
            className="desktopView"
          />
          <ImageConversion
            className="mobileView"
            url={singleBannerMobImageURL}
            altext={singleBannerMobImageAlt}
          />
        </div>
        <div className="enhanceSeoBottom paddingY128">
          <div className="container">
            <div className="row">
              <div className="col-5 enhanceLeft"></div>
              <div className="col-7">
                <div className="enhanceSeoContent">
                  {title ? <h3 className="enhanceSeoContentHeading"> {title} </h3> : ""}
                  { subtitle ? <h5 className="enhanceSeoContentSubHeading"> {subtitle} </h5> : ""}
                  <div className="enhanceSeoContentText"> {parse(description)}
                   </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
export default SeoEnhance;
