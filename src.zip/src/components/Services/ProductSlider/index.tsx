import { useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
interface ProductSliderProps extends React.HTMLAttributes<HTMLDivElement> {
  productSliderHeading?: string;
  children?: JSX.Element | JSX.Element[];
}
const ProductSliderPanel: React.FC<ProductSliderProps> = ({
  productSliderHeading,
  children,
}) => {
  const ProductSliderPanelRef = useRef<HTMLDivElement>(null);

  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      // Add the Contact Team Section animation steps to the timeline
      //setTimeout(() => {
      gsap.set(".ourProductHeading", { xPercent: 30, opacity: 0 });
      gsap.set(".ourProductContent", { xPercent: 60, opacity: 0 });
      gsap.set(".cardCarouselProduct", { yPercent: 160, opacity: 0 });

      const ourProductTwoTl = gsap.timeline({});

      ScrollTrigger.create({
        animation: ourProductTwoTl,
        trigger: ProductSliderPanelRef.current,
        start: "top 40%",
        end: "+=500px",
        scrub: true,
        onToggle: scrollTrigger => {
          // refresh because height start changes
          scrollTrigger.refresh()
        },
      });

      ourProductTwoTl
        .to(".ourProductHeading", {
          xPercent: 0,
          opacity: 1,
          duration: 5,
          ease: "Power4.easeOut",
        })
        .to(
          ".ourProductContent",
          { xPercent: 0, opacity: 1, duration: 10, ease: "Power4.easeOut" },
          "<"
        )
        .to(
          ".cardCarouselProduct",
          { yPercent: 0, opacity: 1, duration: 5, ease: "Power4.easeOut" },
          "<"
        );
      //}, 3000);
    }, ProductSliderPanelRef);

    return () => ctx.revert();
  }, []);
  return (
    <section
      className="ourProduct seoLedSuccesses servicesCarousel contentCarouselInner centeredSlide"
      id="servicesPanel"
      ref={ProductSliderPanelRef}
    >
      <div className="ourProductCarousel paddingY128 SlideSection">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <h3 className="ourProductHeading">{productSliderHeading}</h3>
            </div>
          </div>
          <div className="ourSliderMain nomargin mazonAdvertisementSlide">
            {children}
          </div>
        </div>
      </div>
    </section>
  );
};
export default ProductSliderPanel;
