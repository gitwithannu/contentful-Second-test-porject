import { useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import Image from "next/image";
import { useRouter } from 'next/router';
import parse from 'html-react-parser';
import Link from "next/link";
interface ContactTeamPanelProps extends React.HTMLAttributes<HTMLDivElement> {
  description?: string | any;
  ctatext?: string;
  ctaUrl?:any
}
const ContactTeamPanel: React.FC<ContactTeamPanelProps> = ({
  description,
  ctatext,
  ctaUrl
}) => {
  const ContactTeamRef = useRef<HTMLDivElement>(null);
  const router = useRouter();
  useIsomorphicLayoutEffect(() => {
    const pinnedRefEl = ContactTeamRef.current;
    let timer: string | number | NodeJS.Timeout | undefined;
    if (!pinnedRefEl) return;
    let ctx = gsap.context(() => {
      // Add the Contact Team Section animation steps to the timeline
      timer = setTimeout(() => {
        // if(router){
      gsap.set(".teamContectPin  .teamContactWrap .teamContactContent", {
        yPercent: -100,
        opacity: 0,
      });
      gsap.set(".teamContectPin  .teamContactWrap .contact-cta", {
        yPercent: 30,
        opacity: 0,
      });

      const teamContactT1 = gsap.timeline({});

      ScrollTrigger.create({
        animation: teamContactT1,
        trigger: ContactTeamRef.current,
        start: "top 60%",
        end: "bottom center",
        scrub: true,
        onToggle: scrollTrigger => {
          // refresh because height start changes
          scrollTrigger.refresh()
        },
      });

      teamContactT1
        .to(
          ".teamContectPin  .teamContactWrap .teamContactContent",
          {
            yPercent: 0,
            opacity: 1,
            duration: 1,
          },
          "<"
        )
        .to(
          ".teamContectPin  .teamContactWrap .contact-cta",
          { yPercent: 0, duration: 1, opacity: 1 },
          "<"
        );
      let mm = gsap.matchMedia();

      mm.add("(max-width: 1280px)", () => {
        teamContactT1.to(
          ".teamContectPin  .teamContactWrap .contact-cta",
          { yPercent: 0, duration: 1, opacity: 1 },
          "<"
        );
      });
    // }
      }, 1000);
    }, ContactTeamRef);

    return () => {
      clearTimeout(timer)
      ctx.revert();
    }
  });
  return (
    <section className="teamContectPin">
      <div
        className="teamContact teamContact-1 paddingY128 dark"
        ref={ContactTeamRef}
      >
        <div className="blueShadowCirclee">
          <Image src="/images/serviceEcillpse.png" alt="Blue Gradient" fill loading ="lazy" />
        </div>
        <div className="teamContactWrap">
          <h4 className="teamContactContent">{parse(description)}</h4>
          <Link
            href={ctaUrl}
            className="globalButton withCircle whiteBtn contact-cta"
            aria-label={ctatext}
          >
            {ctatext}
          </Link>
        </div>
      </div>
    </section>
  );
};
export default ContactTeamPanel;
