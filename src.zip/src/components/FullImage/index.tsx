import { FC } from 'react'
import Image from 'next/image'
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))


interface FullImageProp{
    alt?: string | any,
    src?: string | any
}

export const FullImage: FC<FullImageProp> = ({ alt, src }) =>{
    return <div className="fullImage">
         <ImageConversion
            url={src}
            altext={alt}
        />
    </div>
}
