import Image from "next/image";
import { FC } from "react";
import gsap from "gsap";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";

interface AnimateProps {
  className?: string;
  animate?: boolean;
  src?: string;
}

export const AnimateCircle: FC<AnimateProps> = ({
  className,
  animate = true,
  src = "global__animate__gradient.png",
}) => {
  useIsomorphicLayoutEffect(() => {
    const bubbletl = gsap.timeline({ repeat: -1 });
    gsap.set(".blueCircle--top", { scale: 1, xPercent: -10, ease: "ease" });
    bubbletl
      .to(".blueCircle--top", { left: "30%", duration: 2, ease: "ease" })
      .to(".blueCircle--top", {
        xPercent: -100,
        left: "70%",
        yPercent: 0,
        duration: 3,
        force3D: true,
      })
      .to(".blueCircle--top", {
        xPercent: -100,
        yPercent: 40,
        left: "90%",
        top: "40%",
        force3D: true,
        duration: 3,
      })
      .to(".blueCircle--top", {
        xPercent: -100,
        yPercent: 0,
        left: "60%",
        top: "80%",
        force3D: true,
        duration: 3,
      })
      .to(".blueCircle--top", {
        xPercent: -100,
        yPercent: 0,
        left: "00%",
        top: "40%",
        force3D: true,
        duration: 3,
      });
  }, []);

  return (
    <div
      className={`circle--animate ${
        animate ? `blueCircle--top` : ``
      } ${className}`}
    >
      <Image
        src={`/images/home/${src}`}
        alt="animate blue circle"
        fill
        loading ="lazy"
      />
    </div>
  );
};
