import { HTMLAttributes, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import Image from "next/image";
import parse from 'html-react-parser';
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))


interface EnhanceSeoProps extends HTMLAttributes<HTMLDivElement> {
  singleBannerImageAlt?: any;
  singleBannerImageURL?: any;
  singleBannerMobImageURL?: any;
  singleBannerMobImageAlt?: any;
  enhanceSeoPinImage?: boolean;
  title?: any;
  subtitle?: any;
  description?: any;
  customClass?: any;
}
export const ServicesEnhance: React.FC<EnhanceSeoProps> = ({title,subtitle,description,singleBannerImageURL,singleBannerMobImageURL,singleBannerImageAlt,singleBannerMobImageAlt,customClass}) => {
  const servicesEnhanceRef = useRef<HTMLDivElement>(null);
  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      // Add the Contact Team Section animation steps to the timeline
      setTimeout(() => {
        const servicesEnhanceTl = gsap.timeline({});
        let mm = gsap.matchMedia();

        gsap.set('.enhanceSeobanner', { yPercent: 50 });
        gsap.set('enhanceSeoContent', { yPercent: 80, opacity: 0 });
        
        ScrollTrigger.create({
          animation: servicesEnhanceTl,
          trigger: servicesEnhanceRef.current,
          start: "top 70%",
          end: "+=1000px",
          scrub: true,
          onToggle: scrollTrigger => {
            // refresh because height start changes
            scrollTrigger.refresh()
          },
        });
  
        servicesEnhanceTl
          .to(".enhanceSeobanner", { yPercent: 0 })
          .to(".enhanceSeoContent", { yPercent: 0, opacity: 1 }, '<80%');

      }, 1000);
    }, servicesEnhanceRef);

    return () => ctx.revert();
  }, []);
  return (
    <section className={`enhanceSeoPin ${customClass}`} ref={servicesEnhanceRef}>
      <div className="enhanceSeo">
        <div className="enhanceSeobanner">
          <ImageConversion
            className="desktopView"
            url={singleBannerImageURL}
            altext={singleBannerImageAlt}
          />
           <ImageConversion
            className="mobileView"
            url={singleBannerMobImageURL}
            altext={singleBannerMobImageAlt}
          />
        </div>
        <div className="enhanceSeoBottom paddingY128">
          <div className="container">
            <div className="row">
              <div className="col-5 enhanceLeft"></div>
              <div className="col-7">
                <div className="enhanceSeoContent">
                  <h3 className="enhanceSeoContentHeading">{title}</h3>
                  <h5 className="enhanceSeoContentSubHeading">
                    {parse(subtitle)}
                  </h5>
                  <div className="enhanceSeoContentText">
                    {parse(description)}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
