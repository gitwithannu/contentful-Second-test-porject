import Image from 'next/image'
interface LoaderType{
type?:"white" | "black"
}
export const Loader = ({ type = 'black' }:LoaderType) => {
     return (<>
          <div className="outerloadercfl">
               <div className="loaders">
                    <Image 
                         alt="loader" src={`/images/icons/loader.gif`}
                         width={64}
                         height={64}
                         loading ="lazy"
                    />
               </div>
          </div>

     </>
     );
}
Loader.defaultProps = {
     type: "white",
 };