import React, { useEffect, useState } from 'react';
import Image from "next/image";
import { removeBaseUrl } from "@/utils/helper"
interface Props {
	url?: any;
	altext?: any;
	type?: any;
	className?: any;
	height?: any;
	width?: any;
	imagetype?: any;
	role?:any;
}

const Index: React.FC<Props> = ({ url, altext, className, height, width, imagetype, role }: Props) => {
	const customImageUrl = url?.replace('https://images.ctfassets.net/', '/api/images/');
	return (<>

		{url?.match(/\.(jpeg|jpg|gif|png)$/) != null ?

			height ?				
			<Image src={customImageUrl}
				alt={altext}
				height={height}
				width={width}
				className={className}
				role={role}
				loading ="lazy"
			/>
			:
			<Image src={customImageUrl}
				alt={altext}
				fill
				className={className}
				role={role}
				loading ="lazy"
			/>
			:
			
			url?.match('/\.(svg)$/') ? (
				height ?				
				<Image src={`/api/images/${removeBaseUrl(url)}`}
				alt={altext}
				height={height}
				width={width}
				className={className}
				role={role}
			/>
			:
			<Image src={`/api/images${removeBaseUrl(url)}`}
				alt={altext}
				fill
				className={className}
				role={role}
			/>) :
			
			height ?				
			<Image src={`/api/images${removeBaseUrl(url)}`}
				alt={altext}
				height={height}
				width={width}
				className={className}
				role={role}
			/>
			:
			<Image src={`/api/images${removeBaseUrl(url)}`}
				alt={altext}
				fill
				className={className}
				role={role}
			/>

		}

	</>);
}
export default Index;