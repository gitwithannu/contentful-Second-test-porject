import { FC, useRef } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))

interface ExploreCardProp{
    icon?: string | any,
    iconAlt?:string | any,
    title?: string,
    desc?: string,
    className?: string,
    outlineText?: string,
    lists?: [] | any,
}

export const ExploreCard: FC<ExploreCardProp> = ({ icon, iconAlt, className, title, outlineText, desc, lists}) => {
  return (
  <div className={`explore-card ${className}`}>
    <div className="explore-card-icon">
              <div className="explore-card-outer">
              <ImageConversion
                url={icon}
                altext={iconAlt}
                />
        </div>
    </div>
    <h3>{title}</h3>
    <div className="explore-services-brand">{outlineText}</div>
    <p>{desc}</p>

    {lists?.length > 0 && <ul className="externallink-list">
        {lists?.map((el:any,index:any) => (<li key={index}>
            <Link href={el?.link} >
                <span>{el?.linktext}</span>
                <div className="externallink-icon">
                    <Image src="/images/Services/third-party-arrow.svg" fill loading ="lazy" alt={el?.linktext} />
                </div>
            </Link> 
        </li>))}
    </ul>}
</div>
)}