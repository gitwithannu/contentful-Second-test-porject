import Image from "next/image";
import React, { useRef } from "react";

import gsap from "gsap";

import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import Link from "next/link";

interface TopBannerProps extends React.HTMLAttributes<HTMLDivElement> {
  icon?: React.ReactNode;
  title?: string;
  subtitle?: string;
  className?: string;
  rowClass ?:string;
  buttonCta?: any;
  buttonURL?: any;
  mainTitle?: string;
  goBackUrl?: string;
  goBackName?: string;
  showHide?: boolean;
  cta?: boolean;
}

export const PageBanner: React.FC<TopBannerProps> = ({
  title = "Add Page title",
  subtitle,
  buttonURL,
  className = "",
  rowClass ="",
  buttonCta,
  mainTitle,
  goBackUrl = "",
  goBackName = "Page",
  showHide,
  cta = true,
}) => {
  const pageBanner = useRef<HTMLDivElement>(null);
  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      gsap.set(".mainBannerHeading", { scale: 2, opacity: 0 });
      gsap.set(".mainBannerSubheading", { xPercent: 20, opacity: 0 });

      gsap.to(".mainBannerHeading", { opacity: 1, scale: 1, duration: 1, ease: "Power4.easeOut", delay: 1 });
      gsap.to(".mainBannerSubheading", { xPercent: 0, opacity: 1, delay: 1, duration: 1 });
    }, pageBanner);
    return () => ctx.revert();
  }, []);

  return (
    <div>
      <section
        id="homeBanner"
        className={`mainBannerPin withoutbg ${className}`}
        ref={pageBanner}
        role="region"
      >
        <div className="mainBannerSection">
          <div className="mainBanner bannerPadding innerPageBanner">
            <div className="mainBannerOuter">
              <div className="blueGradientCircle">
                <Image
                  src="/images/halfCircle.svg"
                  alt="smallBlueCircle"
                  fill
                  loading ="lazy"
                />
              </div>
              <div className="mainBannerGraphics">
                <svg
                  width="930"
                  height="348"
                  viewBox="0 0 930 348"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <circle
                    opacity="0.5"
                    cx="173.5"
                    cy="174.5"
                    r="173"
                    stroke="#00A5D0"
                  />
                  <g opacity="0.5">
                    <mask id="path-2-inside-1_39_16" fill="white">
                      <path d="M347 0H930V347H347V0Z" />
                    </mask>
                    <path
                      d="M347 0V-1H346V0H347ZM347 347H346V348H347V347ZM347 1H930V-1H347V1ZM930 346H347V348H930V346ZM348 347V0H346V347H348Z"
                      fill="#00A5D0"
                      mask="url(#path-2-inside-1_39_16)"
                    />
                  </g>
                  <path
                    opacity="0.5"
                    d="M693.5 346.489C504.303 342.16 351.754 189.627 347.511 0.5H521.405C525.519 93.6721 600.306 168.477 693.5 172.674V346.489Z"
                    stroke="#00A5D0"
                  />
                </svg>
              </div>
              <div className="container">
                <div className={`row ${rowClass}`}>
                {!cta ? null : (
                    <div className={`goBackButton ${showHide ? "hide" : ""}`}>
                       <Link
                        href={goBackUrl}
                        aria-label={"click here for go back to"+goBackName}
                      >  <Image
                        src="/images/bannerArrow.svg"
                        width={32}
                        height={32}
                        alt="Arrow icon"
                        loading ="lazy"
                      /></Link>
                      <Link
                        href={goBackUrl}
                        aria-label={"click here for go back to"+goBackName}
                      >
                        Go back to {goBackName}
                      </Link>
                    </div>
                  )}
                  <div className="goBackOuter">
                    <div className="col-10 col-12-sm">
                      <h1 className="mainBannerHeading">{title}</h1>
                      {mainTitle && <h2 className="mainTitle">{mainTitle}</h2>}
                      {subtitle && (
                        <p className="mainBannerSubheading">{subtitle}</p>
                      )}
                      {buttonCta && (
                        <div className="goHome">
                          <Link
                            href={buttonURL}
                            className="globalButton withCircle  contact-cta"
                            aria-label={buttonCta}
                          >
                            {buttonCta}
                          </Link>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              <div className="blueShadowBottom"></div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};