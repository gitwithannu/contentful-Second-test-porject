import { useRef } from "react";
import Image from "next/image";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import { AnimateCircle } from "../AnimateCircle";
import Link from "next/link";
import { useRouter } from 'next/router';
import parse from 'html-react-parser';
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))

interface TopBannerProps extends React.HTMLAttributes<HTMLDivElement> {
  icon?: React.ReactNode;
  title?: any;
  subtitle?: string;
  bgAlt?: string | any;
  bg?: string | any;
  showHide?: boolean;
  shadowHide?: boolean;
  cta?: boolean;
  goBackUrl?: string;
  enablefeaturedImage?: boolean;
  goBackName?: string;
  postDesc?: boolean;
  authorDetails?: any | undefined;
  customClass?: string;
}

export const PageImageBanner: React.FC<TopBannerProps> = ({
  title,
  subtitle,
  bgAlt,
  bg,
  showHide,
  shadowHide,
  goBackUrl = "",
  goBackName = "Page",
  enablefeaturedImage=true,
  cta = true,
  postDesc = false,
  authorDetails,
  customClass
}) => {
  const pageImageBanner = useRef<HTMLDivElement>(null);
  const router = useRouter();
  let author = "";
  let category = ""
  let date = ""
  let time = ""
  let featuredImage = ""
  let EventDatetime = ""
  let location = ""
  if (authorDetails) {
    const parsedData = JSON.parse(authorDetails);
    author = parsedData[0]?.authorName;
    category = parsedData[0]?.category;
    date = parsedData[0]?.date;
    time = parsedData[0]?.time;
    featuredImage = parsedData[0]?.featuredImage;
    EventDatetime = parsedData[0]?.EventDatetime
    location = parsedData[0]?.place
  }
  // if (enablefeaturedImage) {
    useIsomorphicLayoutEffect(() => {
      const pinnedRefEl = pageImageBanner.current;
      let timer: string | number | NodeJS.Timeout | undefined;
      if (!pinnedRefEl) return;
      let ctx = gsap.context(() => {
        const PageImageBannerAnimation = () => {
          gsap.set(".mainBannerHeading", { scale: 2, opacity: 0 });
          gsap.set(".mainBannerSubheading", { xPercent: 20, opacity: 0 });
          gsap.set(".goBackButton", { xPercent: 50, opacity: 0 });
          gsap.to(".mainBannerHeading", { opacity: 1, scale: 1, duration: 1, ease: "Power4.easeOut", delay: 0.3 });
          gsap.to(".mainBannerSubheading", { xPercent: 0, opacity: 1, delay: 0.3, duration: 1 });
          gsap.to(".goBackButton", { xPercent: 0, opacity: 1, duration: 2, delay: 0.4, ease: "Power4.easeOut", });
  
          const pageImageBannerTl = gsap.timeline({});
          let mm = gsap.matchMedia();
          if (enablefeaturedImage) {
            mm.add("(min-width: 992px) ", () => {
              ScrollTrigger.create({
                animation: pageImageBannerTl,
                trigger: pageImageBanner.current,
                start: "top top",
                end: "+=100%",
                pin: pageImageBanner.current,
                scrub: true,
              });
              pageImageBannerTl.to(".mainBannerSection .mainBanner", {
                yPercent: -100,
              });
            });
          }
          mm.add("(min-width: 320.98px) and (max-width:991.98px) ", () => {
            gsap.set(".mainBannerImage", { yPercent: 100, opacity: 0 });
            gsap.to(".mainBannerImage", {
              yPercent: 0,
              opacity: 1,
              duration: 1,
              ease: "Power4.easeOut",
              delay: 0.7,
            });
            ScrollTrigger.create({
              animation: pageImageBannerTl,
              trigger: pageImageBanner.current,
              start: "top top",
              end: "+=100%",
              scrub: true,
              pin: false,
            });
  
            pageImageBannerTl.to(".mainBannerSection .mainBanner", {
              yPercent: 0,
            });
          });
        }
        if (router?.asPath.includes('/services/')) {
          PageImageBannerAnimation();
        } else {
          timer = setTimeout(() => {
            PageImageBannerAnimation();
          }, 10)
        }

      }, pageImageBanner);
      return () => {
        clearTimeout(timer);
        ctx.revert();
      }
    }, [title]);
// }

  return (
    <div>
      <section className="mainBannerPin" ref={pageImageBanner} id="homeBanner">
       <div className={`mainBannerSection mainBannerSectionNew ${customClass}`}>
          <div className="mainBanner bannerPadding innerPageBanner mainBannerNew">
            <AnimateCircle className="left-top" />
            <AnimateCircle animate={false} className="right-bottom" />
            <div className="mainBannerOuter">
              <div className="mainBannerGraphics">
                <svg
                  width="930"
                  height="348"
                  viewBox="0 0 930 348"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <circle
                    opacity="0.5"
                    cx="173.5"
                    cy="174.5"
                    r="173"
                    stroke="#00A5D0"
                  />
                  <g opacity="0.5">
                    <mask id="path-2-inside-1_39_16" fill="white">
                      <path d="M347 0H930V347H347V0Z" />
                    </mask>
                    <path
                      d="M347 0V-1H346V0H347ZM347 347H346V348H347V347ZM347 1H930V-1H347V1ZM930 346H347V348H930V346ZM348 347V0H346V347H348Z"
                      fill="#00A5D0"
                      mask="url(#path-2-inside-1_39_16)"
                    />
                  </g>
                  <path
                    opacity="0.5"
                    d="M693.5 346.489C504.303 342.16 351.754 189.627 347.511 0.5H521.405C525.519 93.6721 600.306 168.477 693.5 172.674V346.489Z"
                    stroke="#00A5D0"
                  />
                </svg>
              </div>
              <div className="container">
                <div className="row m0">
                  {!cta ? null : (
                    <div className={`goBackButton ${showHide ? "hide" : ""}`}>
                       <Link
                        href={goBackUrl}
                        aria-label={"click here for go back to"+goBackName}
                      >  <Image
                        src="/images/bannerArrow.svg"
                        width={32}
                        height={32}
                        alt="Arrow icon"
                        loading ="lazy"
                      /></Link>
                      <Link
                        href={goBackUrl}
                        aria-label={"click here for go back to"+goBackName}
                      >
                        Go back to {goBackName}
                      </Link>
                    </div>
                  )}
                  <div className="goBackOuter">
                    <div className="col-12 col-12-sm">
                      <h1 className="mainBannerHeading">{parse(title)}</h1>
                    </div>
                    <div className="col-10 col-12-sm">
                      <p className="mainBannerSubheading">{subtitle}</p>
                    </div>
                  </div>
                  {postDesc && (
                    <div className="postFilterBottom row ">
                      <div className="postDetails">
                        <div className="postFilter">
                          <div className="postCategory">
                          {category ? <span>{category} </span>: " "} 
                          </div>
                          {time &&
                            <div className="postReadTime">
                              <span>{time} mins read </span>
                            </div>
                          }
                          {date &&
                            <div className="postDate">
                              <span>{date} </span>
                            </div>
                          }
                          {EventDatetime &&
                          <div className="postReadTime">
                              <span>{EventDatetime}</span>
                            </div>
                          }
                          {location &&
                          <div className="postReadTime">
                              <span>{location}</span>
                            </div>
                          }
                        </div>
                      </div>
                     
                    </div>
                  )}
                </div>
              </div>
              {shadowHide ? <div className="blueShadowBottom"></div> : ""}
            </div>
          </div>
          {enablefeaturedImage &&
            <div className="mainBannerImage mainBannerImageNew">
             <Image
                src={bg ? bg : "/images/blog/placeholder-single.png"}
                alt={bgAlt}
                fill
                priority={true}
                className="relative"
              />
            </div>
          }
        </div>
      </section>
    </div>
  );
};