import Link from "next/link";
import { useRef } from "react";
import parse from 'html-react-parser';
export const LetsTalk = ({title,subTitle,buttonText,buttonUrl}:any) => {
  const letesWork = useRef<HTMLDivElement>(null);

  return (
    <div className="letsTalk--pin" ref={letesWork}>
      <section className="letsTalk paddingY128">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="letsTalkWrap">
                <div className="letsTalkHead">
                  <h2>{title}</h2>
                  <div className="buttonWrap">
                    <hr className="letsDivider" />
                    <Link
                      href= {buttonUrl ? buttonUrl : "#"}
                      className="getInTouch dFlex"
                      aria-label="Click here to Get in Touch"
                    >
                      {buttonText ? buttonText : "Get in Touch"}
                    </Link>
                  </div>
                  <div className="letsTalkHeadContent">
                    {parse(subTitle)}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
