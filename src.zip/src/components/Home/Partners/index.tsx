import { useRef } from "react";
import Image from "next/image";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
// import "slick-carousel/slick/slick-theme.css";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import parse from 'html-react-parser';
import Link from 'next/link';
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))


//Partner Logo
let partnerLogo = {
  centerMode: true,
  dots: false,
  infinite: true,
  slidesToShow: 8,
  slidesToScroll: 1,
  autoplay: true,
  speed: 1500, 
  arrows: false,
  autoplaySpeed: 1500,
  centerPadding: "7vw",
  responsive: [
    {
      breakpoint: 1660,
      settings: {
        slidesToShow: 6,
      },
    },
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 4,
      },
    },
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 4,
        centerMode: true,
        centerPadding: "80px",
      },
    },
    {
      breakpoint: 575,
      settings: {
        slidesToShow: 1,
        centerMode: true,
        centerPadding: "80px",
      },
    },
  ],
};

// export const Partners = () => {
function Partners({ title, description, sliderImage,enableButton,buttonText,buttonUrl }: any) {
    const partnerRef = useRef<HTMLDivElement>(null);
    const slider = JSON.parse(sliderImage);
  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      setTimeout(() => {
      const ourPartnerTl = gsap.timeline();

      ScrollTrigger.create({
        animation: ourPartnerTl,
        trigger: partnerRef.current,
        start: "top 70%",
        end: "+=1000px",
        scrub: true,
      });

      gsap.set(".ourPartnersHead, .ourProductHeading", {
        xPercent: 30,
        opacity: 0,
      });
      gsap.set(".ourPartnersContent, .ourProductContent", {
        xPercent: 60,
        opacity: 0,
      });
      gsap.set(".partnerLogo, .cardCarouselProduct", {
        yPercent: 100,
        opacity: 0,
      });

      ourPartnerTl
        .to(".ourPartnersHead", {
          xPercent: 0,
          opacity: 1,
          duration: 5,
          ease: "Power4.easeOut",
        })
        .to(
          ".ourPartnersContent",
          { xPercent: 0, opacity: 1, duration: 5, ease: "Power4.easeOut" },
          "<"
        )
        .to(
          ".partnerLogo",
          { yPercent: 0, opacity: 1, duration: 5, ease: "Power4.easeOut" },
          "<"
        );
      }, 1000);
    }, partnerRef);

    return () => ctx.revert();
  }, []);

  return (
    <section className="ourPartners" ref={partnerRef}>
      <div className="container">
        <div className="row">
          <div className="col-5">
            <div className="ourPartnersHead">
              <h3>{parse(title)}</h3>
            </div>
          </div>
          <div className="col-7">
            <div className="ourPartnersContent">
             {parse(description)}
             
              {enableButton && <Link
                className="globalButton withCircle"
                href={buttonUrl ? buttonUrl : "#"}
              >
                {buttonText ? buttonText : "Experience an Agency of Partners"}
              </Link>
              }
            </div>
          </div>
        </div>
      </div>
      <div className="partnerLogo">
        <Slider {...partnerLogo}>
        {
            slider.items.map((logo: any,key:any) => {
              return (
                <div key={key}>
                  <div className="partnerSlickSlide">
                  <ImageConversion
                      url={logo?.cardImage?.url}
                      altext={logo?.cardImage?.title}
                      />
                  </div>
                </div>
                  )
                })
        }
        </Slider>
      </div>
    </section>
  );
};
export {Partners}