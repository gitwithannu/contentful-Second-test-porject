import Image from "next/image";
import { useRef } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
// import "slick-carousel/slick/slick-theme.css";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";

function SlickNextArrow(props: any) {
  const { onClick } = props;
  return (
    <div className="sliderArrows">
      <button className="sliderRightArrow" onClick={onClick}>
        <span className="demo-icon icon-right-arrow-1"></span>
      </button>
    </div>
  );
}

function SlickPrevArrow(props: any) {
  const { onClick } = props;
  return (
    <div className="sliderArrows leftArrow">
      <button className="sliderLeftArrowProduct" onClick={onClick}>
        <span className="demo-icon icon-left-arrow"></span>
      </button>
    </div>
  );
}
// Banner Slider configuration
let cardCarousel = {
  infinite: false,
  slidesToShow: 3.5,
  slidesToScroll: 1,
  dots: false,
  nextArrow: <SlickNextArrow />,
  prevArrow: <SlickPrevArrow />,
  // adaptiveHeight: true,
  responsive: [
    {
      breakpoint: 1199,
      settings: {
        slidesToShow: 2.5,
      },
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 1.7,
      },
    },
    {
      breakpoint: 575,
      settings: {
        slidesToShow: 1,
      },
    },
  ],
};

export const Product = () => {
  const productRef = useRef<HTMLDivElement>(null);
  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      //setTimeout(() => {
      const ourProductTl = gsap.timeline();

      ScrollTrigger.create({
        animation: ourProductTl,
        trigger: productRef.current,
        start: "top 70%",
        end: "+=1000px",
        scrub: true,
      });

      gsap.set(".ourPartnersHead, .ourProductHeading", {
        xPercent: 30,
        opacity: 0,
      });
      gsap.set(".ourPartnersContent, .ourProductContent", {
        xPercent: 60,
        opacity: 0,
      });
      gsap.set(".partnerLogo, .cardCarouselProduct", {
        yPercent: 100,
        opacity: 0,
      });

      ourProductTl
        .to(".ourProductHeading", {
          xPercent: 0,
          opacity: 1,
          duration: 5,
          ease: "Power4.easeOut",
        })
        .to(
          ".ourProductContent",
          { xPercent: 0, opacity: 1, duration: 5, ease: "Power4.easeOut" },
          "<"
        )
        .to(
          ".cardCarouselProduct",
          { yPercent: 0, opacity: 1, duration: 5, ease: "Power4.easeOut" },
          "<"
        );
      //}, 3000);
    }, productRef);

    return () => ctx.revert();
  }, []);
  return (
    <section
      className="ourProduct paddingY128"
      id="servicesPanel"
      ref={productRef}
    >
      <div className="ourProductCarousel">
        <div className="container">
          <div className="row">
            <div className="col-5">
              <h3 className="ourProductHeading">
                Our <span className="display-block">Products </span>
              </h3>
            </div>
            <div className="col-7">
              <div className="ourProductContent">
                <p>Tools that push digital transformation</p>
                <p>
                  Our mission is always to solve real problems that face the
                  digital community. Check out our plugins and apps below used
                  by over 9 million+ users.
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="ourSliderMain">
          <div className="cardCarouselProduct">
            <Slider {...cardCarousel}>
              <div className="ourProductCard">
                <div>
                  <div className="cardIconBox">
                    <Image
                      src="/images/file-manager.svg"
                      fill
                      alt="file manager"
                      loading ="lazy"
                    />
                  </div>
                  <h4>File Manager</h4>
                  <p>
                    The most powerful, flexible, and easiest WordPress file
                    management plugin ever built. Over 3 million downloads!
                  </p>
                </div>
              </div>
              <div className="ourProductCard">
                <div>
                  <div className="cardIconBox">
                    <Image
                      src="/images/file-manager.svg"
                      fill
                      loading ="lazy"
                      alt="file manager"
                    />
                  </div>
                  <h4>Duplicate</h4>
                  <p>
                    You can duplicate your pages, posts and custom post in
                    Wordpress with just one click! Proudly powering 4+ million
                    websites.
                  </p>
                </div>
              </div>
              <div className="ourProductCard">
                <div>
                  <div className="cardIconBox">
                    <Image
                      src="/images/theme-editor.svg"
                      fill
                      loading ="lazy"
                      alt="theme manager"
                    />
                  </div>
                  <h4>Theme Editor</h4>
                  <p>
                    Edit any files from your theme directly using the WordPress
                    backend easily and conveniently with one click!
                  </p>
                </div>
              </div>
              <div className="ourProductCard">
                <div>
                  <div className="cardIconBox">
                    <Image
                      src="/images/stackabl.svg"
                      fill
                      loading ="lazy"
                      alt="stackabl"
                    />
                  </div>
                  <h4>Stackabl</h4>
                  <p>
                    With Stackabl, you can set up your local/hosted websites
                    environment with just one-click.
                  </p>
                </div>
              </div>
              <div className="ourProductCard">
                <div>
                  <div className="cardIconBox">
                    <Image
                      src="/images/file-manager.svg"
                      fill
                      loading ="lazy"
                      alt="stackabl"
                    />
                  </div>
                  <h4>File Manager</h4>
                  <p>
                    The most powerful, flexible, and easiest WordPress file
                    management plugin ever built. Over 3 million downloads!
                  </p>
                </div>
              </div>
            </Slider>
          </div>
        </div>
        <div className="container learnMoreButtonOuter">
          <div className="row">
            <div className="col-12 learnMoreButton">
              <a
                href="#"
                className="globalButton withCircle"
                aria-label="Click here to View All Products"
              >
                View All Products
              </a>
            </div>
          </div>
        </div>
      </div>
      <div className="blueBigShadowCircle"> </div>
      <div className="blueBigShadowCircleLeft"> </div>
      <div className="blueBigShadowCircleSection"> </div>
    </section>
  );
};
