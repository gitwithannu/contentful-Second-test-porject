import Image from "next/image";
import { useRef } from "react";

import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import Link from "next/link";

import { AnimateCircle } from "@/src/components";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import parse from 'html-react-parser';

export const AboutPin = ({ title, description, buttonEnable,buttonUrl, buttonText }: any) => {
  const aboutRef = useRef<HTMLDivElement>(null);

  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      setTimeout(() => {
      const aboutTl = gsap.timeline({});

      let mm = gsap.matchMedia();

      mm.add("(min-width: 1200px)", () => {
        gsap.set(".about--left", { scale: 3.2, xPercent: 205, yPercent: 139.6, opacity: 0 });
        gsap.set(".aboutPin--two--bg, .whiteOverlay", { opacity: 0 });
        gsap.set("#aboutPanel .headingSection", { opacity: 0, scale: 10 });
        gsap.set(".aboutSecThree", { opacity: 0 });
        gsap.set(".about--right", { yPercent: 80, opacity: 0 });
        gsap.set(".headingAbout", { opacity: 1, xPercent: 0 });
        gsap.set(".aboutSecBg", { alpha: 0 });

        ScrollTrigger.create({
          animation: aboutTl,
          trigger: aboutRef.current,
          start: "top top",
          end: "+=4000px",
          pin: aboutRef.current,
          scrub: true,
        });
        aboutTl
          .to("#aboutPanel .headingSection", { scale: 1, opacity: 1 })
          .to(".aboutPin--two--bg", { opacity: 1, scale: 1 }, "<")
          .to(".aboutSecBg", { opacity: 1, scale: 1 }, "<")
          .to(".truIcon", { scale: 10 })
          .to(".headingAbout", { opacity: 0, xPercent: 20 }, "<")
          .to(".aboutPin--two--bg, .aboutPin .headingSection, .aboutPin--two", { autoAlpha: 0 }, "<")
          .to(".aboutSecThree", { opacity: 1 }, "<")
          .to(".about--left", { opacity: 1 }, "<40%")
          .to(".about--left", { scale: 1, xPercent: 0, yPercent: 0 }, "<20%")
          .to(".about--right", { yPercent: 0, opacity: 1 }, "<10%");
      });
      mm.add("(min-width: 768px) and (max-width: 1199px)", () => {
        ScrollTrigger.create({
          animation: aboutTl,
          trigger: aboutRef.current,
          start: "top 40%",
          end: "+=700px",
          scrub: true,
        });
        gsap.set(".about--right", { yPercent: 80, opacity: 0 });
        gsap.set(".about--left", { scale: 4, x: 600, y: 300, opacity: 0 });
        aboutTl
          .to(".about--left", { scale: 1, x: 0, y: 0, opacity: 1 })
          .to(".about--right", { yPercent: 0, opacity: 1 }, "<");
      });
      mm.add("(max-width: 767px)", () => {
        gsap.set(".about--right", { yPercent: 40, opacity: 0 });
        gsap.set(".about--left", { yPercent: 50, opacity: 0 });

        ScrollTrigger.create({
          animation: aboutTl,
          trigger: aboutRef.current,
          start: "top 60%",
          end: "+=700px",
          scrub: true,
        });

        aboutTl
          .to(".about--left", { yPercent: 0, opacity: 1 })
          .to(".about--right", { yPercent: 0, opacity: 1 }, "<");

      });
      }, 1000);
    }, aboutRef);

    return () => ctx.revert();
  }, []);

  return (
    <div id="aboutPanel" className="aboutPin" ref={aboutRef}>
      <div className="aboutSecOne dFlex globalSection floatContent full-w">
        <video autoPlay loop muted playsInline>
          <source src="/images/home/TRU_Homepage_Bumper_V2_updated.mp4" type="video/mp4" />
        </video>
      </div>

      <div className="aboutSecBg"></div>

      <div className="aboutPin--two dFlex globalSection floatContent full-w zindex-2">
        <div className="aboutPin--two--bg floatContent h-screen full-w">
        </div>
        <div className="headingSection dFlex">
          <div className="truIcon">
            <Image
              src="/images/truicon.svg"
              fill
              loading ="lazy"
              alt="An Image of Tru Icon"
            />
          </div>
          <div className="headingAbout">
            <h2 className="bigHeading bigHeading--light">{title}</h2>
          </div>
        </div>
      </div>

      <div className="aboutSecThree dFlex globalSection floatContent full-w zindex-1">
        <AnimateCircle className="left-top" />
        <div className="container">
          <div className="row">
            <div className="col-4">
              <div className="leftAboutPanel">
                <h3 className="about--left">{title}</h3>
              </div>
            </div>
            <div className="col-8 about--right">
              <div className="rightAboutPanel">
                  {parse(description)}
               {buttonEnable && <div className="learnMoreButton">
                  <Link
                    href={buttonUrl ? buttonUrl : '#'}
                    className="globalButton withCircle"
                    aria-label="Click here to learn more"
                  >
                    {buttonText ? buttonText : 'Learn More'}
                  </Link>
                </div>
                 }
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
