import Image from "next/image";
import { useRef } from "react";

import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useIsomorphicLayoutEffect } from "../../../utils/useIsomorphicLayoutEffect";
import { AnimateCircle } from "@/src/components";
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
import parse from 'html-react-parser';

export const PortfolioHeading = ({title, description }: any) => {
  const portfolioHeadingRef = useRef<HTMLDivElement>(null);
  const portDesc = JSON.parse(description);
  let portfolioDes = documentToPlainTextString(portDesc?.json) 
  if (portfolioDes) {
    portfolioDes = portfolioDes;
  } else {
    portfolioDes = "";
  }
  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      setTimeout(() => {
      const portfolioWorkTwoTl = gsap.timeline();

      let mm = gsap.matchMedia();

      mm.add("(min-width: 1600px)", () => {
        gsap.set(".portfolioSection .headingSection", { xPercent: 52 });
      });
      mm.add("(min-width: 1280px)", () => {
        gsap.set(".portfolioSection .headingSection", { xPercent: 56 });
      });

      mm.add("(min-width: 1200px)", () => {
        gsap.set(".portfolioSection .portdesc", { yPercent: 30, opacity: 0 });
        gsap.set(".portfolio__circle", {
          scale: 0.1,
          transform: "translateX(-18%)",
        });
        gsap.set(".portfolio__circle__white", {
          scale: 0,
          transform: "translateY(-50%) translateX(50%)",
        });

        ScrollTrigger.create({
          animation: portfolioWorkTwoTl,
          trigger: portfolioHeadingRef.current,
          start: "top top",
          end: "bottom",
          pin: portfolioHeadingRef.current,
          scrub: true,
        });

        gsap.set(".portfolioSection .headingSection", { xPercent: 54 });
        portfolioWorkTwoTl
          .to(".portfolio__circle", {
            scale: 1,
            duration: 10,
            transform: "translateX(-38%)",
          })
          .to(
            ".portfolio__circle__white",
            {
              scale: 1,
              duration: 10,
              transform: "translateY(-50%) translateX(0%)",
            },
            "<40%"
          )
          .to(
            ".portfolioSection .headingSection",
            { xPercent: 0, duration: 5 },
            "<10%"
          )
          .to(
            ".portfolioSection .portdesc",
            { yPercent: 0, duration: 2, opacity: 1 },
            "<40%"
          );
      });

      mm.add("(min-width: 768px) and (max-width: 1199px)", () => {
        gsap.set(".portfolioSection .portdesc", { yPercent: 30, opacity: 0 });
        gsap.set(".portfolio__circle", {
          scale: 0.1,
          transform: "translateX(-18%)",
        });
        gsap.set(".portfolio__circle__white", {
          scale: 0,
          transform: "translateY(-50%) translateX(50%)",
        });
        gsap.set(".portfolioSection .headingSection", { xPercent: 54 });

        ScrollTrigger.create({
          animation: portfolioWorkTwoTl,
          trigger: portfolioHeadingRef.current,
          start: "top 60%",
          end: "+=60%",
          scrub: true,
        });

        portfolioWorkTwoTl
          .to(".portfolio__circle", {
            scale: 1,
            duration: 10,
            transform: "translateX(-38%)",
          })
          .to(
            ".portfolio__circle__white",
            {
              scale: 1,
              duration: 10,
              transform: "translateY(-50%) translateX(0%)",
            },
            "<40%"
          )
          .to(
            ".portfolioSection .headingSection",
            { xPercent: 0, duration: 5 },
            "<10%"
          )
          .to(
            ".portfolioSection .portdesc",
            { yPercent: 0, duration: 2, opacity: 1 },
            "<40%"
          );
      });
      mm.add("(max-width: 767px)", () => {
        gsap.set(".portfolioSection .portdesc", { yPercent: 30, opacity: 0 });
        gsap.set(".portfolio__circle", {
          scale: 0,
          transform: "translateX(-18%)",
        });
        gsap.set(".portfolio__circle__white", {
          scale: 0,
          transform: "translateY(-50%) translateX(50%)",
        });
        gsap.set(".portfolioSection .headingSection", { xPercent: 54 });

        ScrollTrigger.create({
          animation: portfolioWorkTwoTl,
          trigger: portfolioHeadingRef.current,
          start: "top 60%",
          end: "+=60%",
          scrub: true,
        });

        portfolioWorkTwoTl
          .to(".portfolioSection .headingSection", {
            xPercent: 0,
            duration: 5,
          })
          .to(
            ".portfolioSection .portdesc",
            { yPercent: 0, duration: 2, opacity: 1 },
            "<40%"
          );
      });
      }, 1000);
    }, portfolioHeadingRef);

    return () => ctx.revert();
  }, []);

  return (
    <div className="portfolioPinTwo">
      <section
        className="portfolioSection"
        id="portfolioPanel"
        ref={portfolioHeadingRef}
      >
        <div className="portfolioSectionBg">
          <Image
            src="/images/home/portfolio__bg.jpg"
            loading ="lazy"
            alt="Portfolio"
            fill
          />
        </div>
        <div className="portfolioSecTwo portfolio--light dFlex globalSection floatContent full-w">
          <div className="portfolio__circle"></div>
          <div className="portfolio__circle__white"></div>

          <AnimateCircle
            src="portfolio__animate__gradient.png"
            className="left-top z-index-minus"
          />

          <div className="container">
            <div className="row">
              <div className="col-7">
                <div className="headingSection dFlex mAlignLeft">
                  <h2 className="bigHeading">{title}</h2>
                </div>
              </div>
              <div className="col-5 flexFlowColumn portdesc">
                {parse(portfolioDes)}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
