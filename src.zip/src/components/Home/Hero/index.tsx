import Image from "next/image";
import { useRef } from "react";

import gsap from "gsap";

import { AnimateCircle } from "@/src/components";
import { useIsomorphicLayoutEffect } from "@/src/utils/useIsomorphicLayoutEffect";
import parse from 'html-react-parser';
// import ImageConversion from "@/src/components/ImageConversion"

import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))


export const Hero = ({ bannerTitle, bannerImage, bannerAlt,announcementData }: any) => {
  const welcomeRef = useRef<HTMLDivElement>(null);

  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      //Welcome section
      gsap.set(".homeLeftGraphics", {
        scale: 1.3,
        xPercent: -200,
        ease: "ease",
      });
      gsap.set(".bigHeading", { scale: 1.8, ease: "ease", opacity: 0 });
      gsap.to(".bigHeading", {
        scale: 1,
        ease: "ease",
        opacity: 1,
        duration: 0.5,
        delay: 0.3,
      });
      gsap.to(".homeLeftGraphics", {
        scale: 1,
        opacity: 1,
        xPercent: 0,
        ease: "ease",
        duration: 0.5,
        delay: 0.3,
      });
    }, welcomeRef);
    return () => ctx.revert();
  }, []);


  return (
    <section className="homeBanner" ref={welcomeRef}>
      <div className="homeBannerMain" id="homeBanner">
        <AnimateCircle className="left-top" />
        <AnimateCircle animate={false} className="right-bottom" />
        <div className="containerFluid absolutePanel homeBannerMobile">
          <div className="row">
            <div className="col-5 m0 banColLeft">
              <div className="homeLeftGraphics showDeskTop">
                  <ImageConversion
                            url={bannerImage}
                            altext={bannerAlt}
                            
                          />
              </div>
              <div className="homeLeftGraphics showiPad">
              <ImageConversion
                            url={bannerImage}
                            altext={bannerAlt}
                            
                />
              </div>
            </div>
            <div className="col-7 m0 homeBannerCol banColRight">
              <div className="homeBannerWrap">
                <h1 className="bigHeading">
                  {parse(bannerTitle)}
                </h1>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="scrollExplore">
        <div className="exploreWrap">
          <Image
            src="images/scroll.svg"
            fill
            alt="Scroll to Explore"
            className="scrollImg"
            loading ="lazy"
          />
          <span className="demo-icon icon-scroll-ixon"></span>
        </div>
      </div>
    </section>
  );
};
