import Image from "next/image";
import { useRef } from "react";

import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";

import { AnimateCircle } from "@/src/components";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import Link from "next/link";

export const AboutPinSecond = () => {
  const aboutRef = useRef<HTMLDivElement>(null);

  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      //setTimeout(() => {
      gsap.set(".aboutPin--two--bg, .whiteOverlay", { opacity: 0 });
      gsap.set("#aboutPanel .headingSection", { opacity: 0, scale: 10 });
      gsap.set(".aboutSecThree", { opacity: 0 });
      gsap.set(".about--right", { yPercent: 80, opacity: 0 });
      gsap.set(".headingAbout", { opacity: 1, xPercent: 0 });
      gsap.set(".aboutSecBg", { alpha: 0 });

      gsap.set(".aboutcontent--inner--desc", { opacity: 0 });
      gsap.set(".aboutcontent--inner", { yPercent: 40, xPercent: 14 });
      gsap.set(".aboutcontent", { opacity: 0 });

      const aboutTl = gsap.timeline({});

      ScrollTrigger.create({
        animation: aboutTl,
        trigger: aboutRef.current,
        start: "top top",
        end: "+=4000px",
        pin: aboutRef.current,
        scrub: true,
      });

      aboutTl
        .to("#aboutPanel .headingSection", { scale: 1, opacity: 1 })
        .to(".aboutPin--two--bg", { opacity: 1, scale: 1 }, "<")
        .to(".aboutSecBg", { opacity: 1, scale: 1 }, "<")
        .to(".truIcon", { scale: 10 })
        .to(".headingAbout", { opacity: 0, xPercent: 20 }, "<")
        .to(
          ".aboutPin--two--bg, .aboutPin .headingSection, .aboutPin--two",
          { autoAlpha: 0 },
          "<"
        )
        .to(".aboutcontent", { opacity: 1 }, "<")
        .to(".aboutcontent--inner", { xPercent: 0 }, "<80%")
        .to(".aboutcontent--inner", { scale: 1, yPercent: 0 }, "<80%")
        .to(".aboutcontent--inner--desc", { opacity: 1 }, "<");

      let mm = gsap.matchMedia();

      mm.add("(min-width: 1280px)", () => {
        gsap.set(".about--left", {
          scale: 3.2,
          xPercent: 205,
          yPercent: 139.6,
          opacity: 0,
        });
      });
      mm.add("(min-width: 768px) and (max-width: 1279px)", () => {
        gsap.set(".about--left", {
          scale: 3.2,
          xPercent: 140,
          yPercent: 139.6,
          opacity: 0,
        });
      });

      mm.add("(max-width: 767.98px)", () => {
        gsap.set(".about--left", {
          scale: 1,
          xPercent: 0,
          yPercent: 150,
          opacity: 0,
        });
      });
      //}, 3000);
    }, aboutRef);

    return () => ctx.revert();
  }, []);

  return (
    <div id="aboutPanel" className="aboutPin" ref={aboutRef}>
      <div className="aboutSecOne dFlex globalSection floatContent full-w">
        <video autoPlay loop  muted playsInline>
          <source src="/images/home/truinovation.mp4" type="video/mp4" />
        </video>
      </div>

      <div className="aboutSecBg"></div>

      <div className="aboutPin--two dFlex globalSection floatContent full-w zindex-2">
        <div className="aboutPin--two--bg floatContent h-screen full-w">
        </div>
        <div className="headingSection dFlex">
          <div className="truIcon">
            <Image
              src="/images/truicon.svg"
              fill
              loading ="lazy"
              alt="An Image of Tru Icon"
            />
          </div>
          <div className="headingAbout">
            <h2 className="bigHeading bigHeading--light">About Us</h2>
          </div>
        </div>
      </div>

      <div className="aboutSecThree dFlex globalSection floatContent full-w zindex-1 d-none">
        <AnimateCircle className="left-top" />
        <div className="container">
          <div className="row">
            <div className="col-4">
              <div className="leftAboutPanel">
                <h3 className="about--left">About Us</h3>
              </div>
            </div>
            <div className="col-8 about--right">
              <div className="rightAboutPanel">
                <h4>
                  We are seasoned aficionados, we are trailblazers of tech, we
                  are TRU.
                </h4>
                <h4>
                  With offices based around the world, in Canada, the US, India,
                  Indonesia, and beyond, our teams consist of a diverse range of
                  critical thinkers ready to bring our clients data-backed
                  decisions. With experts in websites, coding, social media,
                  marketing, branding, design, analytics, content, and so much
                  more, we tick the boxes for being the right end-to-end digital
                  services provider.
                </h4>
                <div className="learnMoreButton">
                  <Link
                    href="#"
                    className="globalButton withCircle"
                    aria-label="Click here to learn more"
                  >
                    Learn More
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="aboutcontent">
        <div className="aboutcontent--inner">
          <h2>About Us</h2>
          <div className="aboutcontent--inner--desc">
            <p>
              We are seasoned aficionados, we are trailblazers of tech, we are
              TRU.
            </p>
            <p>
              With offices based around the world, in Canada, the US, India,
              Indonesia, and beyond, our teams consist of a diverse range of
              critical thinkers ready to bring our clients data-backed
              decisions. With experts in websites, coding, social media,
              marketing, branding, design, analytics, content, and so much more,
              we tick the boxes for being the right end-to-end digital services
              provider.
            </p>
            <div className="learnMoreButton">
              <a
                href="#"
                className="globalButton withCircle"
                aria-label="Click here to learn more"
              >
                Learn More
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
