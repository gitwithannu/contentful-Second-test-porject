import Image from "next/image";
import { useRef,useState,useEffect } from "react";

import Slider from "react-slick";
import "slick-carousel/slick/slick.css";

import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";

import { AnimateCircle } from "@/src/components";

import { useIsomorphicLayoutEffect } from "../../../utils/useIsomorphicLayoutEffect";
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
import parse from 'html-react-parser';

import Link from 'next/link';
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))

function SampleNextArrow(props: any) {
  const { onClick } = props;
  return (
    <div className="sliderArrows">
      <button className="sliderRightArrow" onClick={onClick}>
        <span className="demo-icon icon-right-arrow-1"></span>
      </button>
    </div>
  );
}

function SamplePrevArrow(props: any) {
  const { onClick } = props;
  return (
    <div className="sliderArrows leftArrow">
      <button className="sliderLeftArrowProduct" onClick={onClick}>
        <span className="demo-icon icon-left-arrow"></span>
      </button>
    </div>
  );
}
// Banner Slider configuration
let cardCarousel = {
  infinite: false,
  slidesToShow: 3.5,
  slidesToScroll: 1,
  dots: false,
  nextArrow: <SampleNextArrow />,
  prevArrow: <SamplePrevArrow />,
  responsive: [
    {
      breakpoint: 1199,
      settings: {
        slidesToShow: 2.5,
      },
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 1.7,
      },
    },
    {
      breakpoint: 575,
      settings: {
        slidesToShow: 1,
      },
    },
  ],
};

function ServicePin({ bgImage, serviceData,bgImageAlt, title, description,enableButton, buttonUrl,buttonText }: any) {
  const servicesRef = useRef<HTMLDivElement>(null);

  const [isHovering, setIsHovered] = useState(false);
  const onMouseEnter = () => setIsHovered(true);
  const onMouseLeave = () => setIsHovered(false);

  const cursorRef = useRef<HTMLInputElement>(null);
  
  const serviceItems = JSON.parse(serviceData);
  const serviceTitle = title;
  const ServiceData = serviceItems.items;
  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      setTimeout(() => {
      const servicesTl = gsap.timeline({});

      let mm = gsap.matchMedia();
      mm.add("(min-width: 1200px)", () => {
        ScrollTrigger.create({
          animation: servicesTl,
          trigger: servicesRef.current,
          start: "top top",
          end: "+=3000px",
          pin: servicesRef.current,
          scrub: true,
        });

        gsap.set(".services--big--heading", { scale: 10, opacity: 1 });
        gsap.set(".services--heading", { scale: 10, opacity: 0 });
        gsap.set(".ourServiceCarousel", { opacity: 0 });
        gsap.set(".services--desc", { yPercent: 40, opacity: 0 });
        gsap.set(".ourSliderMain", { yPercent: 40, autoAlpha: 0 });
        gsap.set(".learnMoreButtonOuter", { yPercent: 50, opacity: 0 });
      });
      mm.add("(min-width: 1680px)", () => {
        servicesTl
          .to(".ourServiceCarousel", { opacity: 1 })
          .to(".services--big--heading", { scale: 4 }, "<")
          .to(".services--big--heading", { scale: 1, opacity: 1 })
          .to(
            ".ourServicesHeadingFull",
            { xPercent: -29.2, yPercent: -34, opacity: 1 },
            "<"
          )
          .to(".services--desc", { yPercent: 0, opacity: 1 }, "<40%")
          .to(".ourSliderMain", { yPercent: 0, autoAlpha: 1 }, "<")
          .to(".learnMoreButtonOuter", { yPercent: 0, opacity: 1 }, "<");
      });
      mm.add("(min-width: 1600px) and (max-width: 1679px)", () => {
        servicesTl
          .to(".ourServiceCarousel", { opacity: 1 })
          .to(".services--big--heading", { scale: 4 }, "<")
          .to(".services--big--heading", { scale: 1, opacity: 1 })
          .to(
            ".ourServicesHeadingFull",
            { xPercent: -29, yPercent: -24, opacity: 1 },
            "<"
          )
          .to(".services--desc", { yPercent: 33, opacity: 1 }, "<40%")
          .to(".ourSliderMain", { yPercent: 0, autoAlpha: 1 }, "<")
          .to(".learnMoreButtonOuter", { yPercent: 0, opacity: 1 }, "<");
      });
      mm.add("(min-width: 1536px) and (max-width: 1599px)", () => {
        servicesTl
          .to(".ourServiceCarousel", { opacity: 1 })
          .to(".services--big--heading", { scale: 4 }, "<")
          .to(".services--big--heading", { scale: 1, opacity: 1 })
          .to(
            ".ourServicesHeadingFull",
            { xPercent: -34, yPercent: -33, opacity: 1 },
            "<"
          )
          .to(".services--desc", { yPercent: 30, opacity: 1 }, "<40%")
          .to(".ourSliderMain", { yPercent: 0, autoAlpha: 1 }, "<")
          .to(".learnMoreButtonOuter", { yPercent: 0, opacity: 1 }, "<");
      });
      mm.add("(min-width: 1440px) and (max-width: 1535px)", () => {
        servicesTl
          .to(".ourServiceCarousel", { opacity: 1 })
          .to(".services--big--heading", { scale: 4 }, "<")
          .to(".services--big--heading", { scale: 1, opacity: 1 })
          .to(
            ".ourServicesHeadingFull",
            { xPercent: -33.5, yPercent: -27, opacity: 1 },
            "<"
          )
          .to(".services--desc", { yPercent: 30, opacity: 1 }, "<40%")
          .to(".ourSliderMain", { yPercent: 0, autoAlpha: 1 }, "<")
          .to(".learnMoreButtonOuter", { yPercent: 0, opacity: 1 }, "<");
      });
      mm.add("(min-width: 1400px) and (max-width: 1439px)", () => {
        servicesTl
          .to(".ourServiceCarousel", { opacity: 1 })
          .to(".services--big--heading", { scale: 4 }, "<")
          .to(".services--big--heading", { scale: 1, opacity: 1 })
          .to(
            ".ourServicesHeadingFull",
            { xPercent: -33.5, yPercent: -33, opacity: 1 },
            "<"
          )
          .to(".services--desc", { yPercent: 0, opacity: 1 }, "<40%")
          .to(".ourSliderMain", { yPercent: 0, autoAlpha: 1 }, "<")
          .to(".learnMoreButtonOuter", { yPercent: 0, opacity: 1 }, "<");
      });
      mm.add("(min-width: 1366px) and (max-width: 1399px)", () => {
        servicesTl
          .to(".ourServiceCarousel", { opacity: 1 })
          .to(".services--big--heading", { scale: 4 }, "<")
          .to(".services--big--heading", { scale: 1, opacity: 1 })
          .to(
            ".ourServicesHeadingFull",
            { xPercent: -37.5, yPercent: -31, opacity: 1 },
            "<"
          )
          .to(".services--desc", { yPercent: 20, opacity: 1 }, "<40%")
          .to(".ourSliderMain", { yPercent: 0, autoAlpha: 1 }, "<")
          .to(".learnMoreButtonOuter", { yPercent: 0, opacity: 1 }, "<");
      });
      mm.add("(min-width: 1280px) and (max-width: 1365px)", () => {
        servicesTl
          .to(".ourServiceCarousel", { opacity: 1 })
          .to(".services--big--heading", { scale: 4 }, "<")
          .to(".services--big--heading", { scale: 1, opacity: 1 })
          .to(
            ".ourServicesHeadingFull",
            { xPercent: -37.5, y: -206, opacity: 1 },
            "<"
          )
          .to(".services--desc", { yPercent: 30, opacity: 1 }, "<40%")
          .to(".ourSliderMain", { yPercent: 0, autoAlpha: 1 }, "<")
          .to(".learnMoreButtonOuter", { yPercent: 0, opacity: 1 }, "<");
      });
      mm.add("(min-width: 1231px) and (max-width: 1279px)", () => {
        servicesTl
          .to(".ourServiceCarousel", { opacity: 1 })
          .to(".services--big--heading", { scale: 4 }, "<")
          .to(".services--big--heading", { scale: 1, opacity: 1 })
          .to(
            ".ourServicesHeadingFull",
            { xPercent: -37.5, y: -245, opacity: 1 },
            "<"
          )
          .to(".services--desc", { yPercent: 0, opacity: 1 }, "<40%")
          .to(".ourSliderMain", { yPercent: 0, autoAlpha: 1 }, "<")
          .to(".learnMoreButtonOuter", { yPercent: 0, opacity: 1 }, "<");
      });

      mm.add("(min-width: 768px) and (max-width: 1199px)", () => {
        ScrollTrigger.create({
          animation: servicesTl,
          trigger: servicesRef.current,
          start: "top 90%",
          end: "+=1000px",
          scrub: true,
        });
      });
      mm.add("(max-width: 1199px)", () => {
        gsap.set(".ourServiceHeading", { scale: 4, x: 550, y: 200 });
        gsap.set(".services--desc", { y: 400, opacity: 0 });
        gsap.set(".ourSliderMainCard", { y: 400, opacity: 0 });
        gsap.set(".learnMoreButtonOuter", { y: 400, opacity: 0 });

        servicesTl
          .to(".ourServiceHeading", { scale: 1, x: 0, y: 0 })
          .to(".services--desc", { y: 0, opacity: 1 }, "<")
          .to(".ourSliderMainCard", { y: 0, opacity: 1 }, "<")
          .to(".learnMoreButtonOuter", { y: 0, opacity: 1 }, "<");
      });
      mm.add("(max-width: 767px)", () => {
        ScrollTrigger.create({
          animation: servicesTl,
          trigger: servicesRef.current,
          start: "top 80%",
          end: "+=60%",
          scrub: true,
        });
      });
      }, 1000);
    }, servicesRef);

    return () => ctx.revert();
  }, []);
  return (
    <div>
      <div className="servicePin">
        <section className="ourService" id="servicesPanel" ref={servicesRef}>
          <div className="ourServiceImage floatContent full-w">
          <ImageConversion
              url={bgImage}
              altext={bgImageAlt}
            />
          </div>
          <div className="ourServiceCarousel floatContent full-w zindex-1 paddingY128 homeOurServiceSlider">
            <div className="ourServiceCarouselInner">
              <div className="ourServicesCarouselBg">
                <Image
                  src="/images/home/services__bg.jpg"
                  fill
                  loading ="lazy"
                  alt="Group of people celebrating and enjoying a moment together"
                 
                />
              </div>
              <div className="ourServicesHeadingFull floatContent full-w dFlex h-screen">
                <h3 className="ourServiceHeading services--big--heading">
                {title}
                </h3>
              </div>
              <AnimateCircle
                className="left-top medium"
                src="services__animate__gradient.png"
              />
              <div className="container">
                <div className="row">
                  <div className="col-5 services--heading">
                    <h3 className="ourServiceHeading">{title}</h3>
                  </div>
                  <div className="col-7 services--desc">
                    <div className="ourServiceContent" >
                   {parse(description)}
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="ourSliderMainCard"  >
              
                <div className="ourSliderMain" onMouseEnter={onMouseEnter} onMouseLeave={onMouseLeave}>
                  <div className="cardCarousel">
                    <Slider {...cardCarousel} className="dragSlider">
                      {ServiceData?.map((service: any, index: any) => {
                        const serviceDescription = documentToPlainTextString(service?.description?.json);
                       return (
                      <div className="ourServiceCard" key={index}>
                        <div>
                          <div className="count"> </div>
                             <div className="ourServiceCardBrand">{service?.cardTextAbber ? service?.cardTextAbber :"" }</div>
                             <h4>{service?.title}</h4>
                             <p>{parse(serviceDescription)}</p>
                             <Link href={service?.buttonUrl ? service?.buttonUrl :"#"} aria-label="Click here to Learn More">{service?.buttonText ? service?.buttonText :"Learn More"} <span className="demo-icon icon-right-arrow-1"></span></Link>
                        </div>
                         </div>
                           )
                          })
                          }
                    </Slider>
                  </div>
                </div>
              </div>
              {enableButton &&
              <div className="container learnMoreButtonOuter">
                <div className="row">
                  <div className="col-12 learnMoreButton">
                    <Link
                      href={buttonUrl ? buttonUrl : "#"}
                      className="globalButton withCircle"
                      aria-label="Click here to View all services"
                    >
                      {buttonText ? buttonText : "View All Products"}
                    </Link>
                  </div>
                </div>
                </div>
              }
            </div>
          </div>

          <div className="blueBigShadowCircle"></div>
          <div className="blueBigShadowCircleSection"></div>
        </section>
      </div>
      {/* Services end */}
    </div>
  );
};

export { ServicePin }
