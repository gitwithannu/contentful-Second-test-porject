import Image from "next/image";
import { useRef } from "react";

import Slider from "react-slick";
import "slick-carousel/slick/slick.css";

import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";

import { AnimateCircle, DragCursor } from "@/src/components";

import { useIsomorphicLayoutEffect } from "../../../utils/useIsomorphicLayoutEffect";
import Link from "next/link";

function SampleNextArrow(props: any) {
  const { onClick } = props;
  return (
    <div className="sliderArrows">
      <button className="sliderRightArrow" onClick={onClick}>
        <span className="demo-icon icon-right-arrow-1"></span>
      </button>
    </div>
  );
}

function SamplePrevArrow(props: any) {
  const { onClick } = props;
  return (
    <div className="sliderArrows leftArrow">
      <button className="sliderLeftArrowProduct" onClick={onClick}>
        <span className="demo-icon icon-left-arrow"></span>
      </button>
    </div>
  );
}
// Banner Slider configuration
let cardCarousel = {
  infinite: false,
  slidesToShow: 4,
  slidesToScroll: 1,
  dots: false,
  arrows: false,
  nextArrow: <SampleNextArrow />,
  prevArrow: <SamplePrevArrow />,
  // adaptiveHeight: true,
  responsive: [
    {
      breakpoint: 1199,
      settings: {
        slidesToShow: 2.5,
      },
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 1.7,
      },
    },
    {
      breakpoint: 575,
      settings: {
        slidesToShow: 1,
      },
    },
  ],
};

export const ServicesPinSecond = () => {
  const servicesNewRef = useRef<HTMLDivElement>(null);
  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      //setTimeout(() => {
      const servicesTl = gsap.timeline({});

      ScrollTrigger.create({
        animation: servicesTl,
        trigger: servicesNewRef.current,
        start: "top top",
        end: "+=4000px",
        pin: servicesNewRef.current,
        scrub: true,
      });

      gsap.set(".services__content", { opacity: 0 });
      gsap.set(".services__content__inner", { yPercent: 90 });
      gsap.set(".services__content__slider, .services__btncontainer", {
        yPercent: 30,
        opacity: 0,
      });
      gsap.set(".services__content__inner p", { opacity: 0 });
      gsap.set(".services__content__inner h2", { opacity: 0, scale: 15 });

      servicesTl
        .to(".services__content__inner h2", { scale: 1, opacity: 1 })
        .to(".services__content", { opacity: 1 }, "<")
        .to(".services__content__inner", { yPercent: 0 })
        .to(".services__content__inner p", { opacity: 1 }, "<")
        .to(".services__content__slider, .services__btncontainer", {
          yPercent: 0,
          opacity: 1,
        });
      //}, 3000);
    }, servicesNewRef);

    return () => ctx.revert();
  }, []);

  return (
    <div>
      <div className="services" ref={servicesNewRef}>
        <div className="services__image">
          <Image
            src="/images/our-services-image.jpg"
            fill
            loading ="lazy"
            alt="our services"
          />
        </div>
        {/* Services Image End */}

        <div className="services__content">
          <div className="services__content__inner">
            <h2>Our Services</h2>
            <p>
              It is satisfying to know that we are able to help our clients
              build the strategic blueprints that enable them to connect and
              operate pivotal aspects of their business more efficiently and
              economically.
            </p>
          </div>

          <div className="services__content__slider">
            <DragCursor />
            <div className="cardCarousel">
              <Slider {...cardCarousel}>
                <div className="ourServiceCard">
                  <div>
                    <div className="count"> </div>
                    <div className="ourServiceCardBrand">UX</div>
                    <h4> User Experience</h4>
                    <p>
                      Through strategy and data-led planning, we create
                      experiences that connect with users to deliver authentic
                      engagement.
                    </p>
                    <Link href="#" aria-label="Click here to Learn More">
                      Learn More
                      <span className="demo-icon icon-right-arrow-1"></span>
                    </Link>
                  </div>
                </div>
                <div className="ourServiceCard">
                  <div>
                    <div className="count"> </div>
                    <h4> User Experience</h4>
                    <p>
                      Through strategy and data-led planning, we create
                      experiences that connect with users to deliver authentic
                      engagement.
                    </p>
                    <Link href="#" aria-label="Click here to Learn More">
                      Learn More
                      <span className="demo-icon icon-right-arrow-1"></span>
                    </Link>
                  </div>
                </div>
                <div className="ourServiceCard">
                  <div>
                    <div className="count"> </div>
                    <h4> User Experience</h4>
                    <p>
                      Through strategy and data-led planning, we create
                      experiences that connect with users to deliver authentic
                      engagement.
                    </p>
                    <Link href="#" aria-label="Click here to Learn More">
                      Learn More
                      <span className="demo-icon icon-right-arrow-1"></span>
                    </Link>
                  </div>
                </div>
                <div className="ourServiceCard">
                  <div>
                    <div className="count"> </div>
                    <h4> User Experience</h4>
                    <p>
                      Through strategy and data-led planning, we create
                      experiences that connect with users to deliver authentic
                      engagement.
                    </p>
                    <Link href="#" aria-label="Click here to Learn More">
                      Learn More
                      <span className="demo-icon icon-right-arrow-1"></span>
                    </Link>
                  </div>
                </div>
                <div className="ourServiceCard">
                  <div>
                    <div className="count"> </div>
                    <h4> User Experience</h4>
                    <p>
                      Through strategy and data-led planning, we create
                      experiences that connect with users to deliver authentic
                      engagement.
                    </p>
                    <Link href="#" aria-label="Click here to Learn More">
                      Learn More
                      <span className="demo-icon icon-right-arrow-1"></span>
                    </Link>
                  </div>
                </div>
              </Slider>
            </div>
          </div>
          <div className="services__btncontainer">
            <div className="container learnMoreButtonOuter">
              <div className="row">
                <div className="col-12 learnMoreButton">
                  <Link
                    href="#"
                    className="globalButton withCircle"
                    aria-label="Click here to view all products"
                  >
                    View All Products
                  </Link>
                </div>
              </div>
            </div>
          </div>
          <AnimateCircle
            className="left-top medium"
            src="services__animate__gradient.png"
          />
        </div>
      </div>
      {/* Services end */}
    </div>
  );
};
