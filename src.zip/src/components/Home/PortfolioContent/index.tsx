import Image from "next/image";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useRef } from "react";
import { useIsomorphicLayoutEffect } from "../../../utils/useIsomorphicLayoutEffect";
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))

export const PortfolioContent = ({ data,allPortfolioButtonUrl,allPortfolioButtonText }: any) => {
  const portfolioContentRef = useRef<HTMLDivElement>(null);
  const parsedData = JSON.parse(data);
  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      setTimeout(() => {
      const portfolioWorkTl = gsap.timeline();
      let mm = gsap.matchMedia();

      mm.add("(min-width: 1200px)", () => {
        gsap.set(".portfolioSlide-2, .portfolioSlide-3", { yPercent: 100 });
        ScrollTrigger.create({
          animation: portfolioWorkTl,
          trigger: portfolioContentRef.current,
          start: "top top",
          end: "+=1200px",
          pin: portfolioContentRef.current,
          scrub: true,
        });
        portfolioWorkTl
          .to(".portfolioSlide-2", { yPercent: 0 })
          .to(".portfolioSlide-3", { yPercent: 0 });
      });

      mm.add("(max-width: 1199px)", () => {
        gsap.set(".portfolioSlide-2, .portfolioSlide-3", {
          yPercent: 10,
          opacity: 0,
        });
        ScrollTrigger.create({
          animation: portfolioWorkTl,
          trigger: portfolioContentRef.current,
          start: "top 10%",
          end: "+=450px",
          scrub: true,
        });
        portfolioWorkTl
          .to(".portfolioSlide-2", { yPercent: 0, opacity: 1 })
          .to(".portfolioSlide-3", { yPercent: 0, opacity: 1 });
      });
      }, 1000);
    }, portfolioContentRef);

    return () => ctx.revert();
  }, []);

  return (
    <section className="portfolioPin">
      <section className="homePortfolio" ref={portfolioContentRef}>
      {parsedData.map((content: any, index: any) => {
          const title = content?.title;
          const splittedTitle = title?.split(' ');
          const value = index + 1;
          const featureImage = content?.cardImage?.url;
        const featureTitle = content?.cardImage?.title;
          return (
            <div key={index} className={"protfolioSlide  portfolioSlide-" +value  + " floatContent full-w h-screen dFlex"} >
          <div className="container">
            <div className="row">
              <div className="col-5">
                <div className="protfolioSlidehead">
                <ul>
                      <li className="PortfolioSlideCount">0{value}</li>
                      {splittedTitle?.map((tile: any,key:any) => { 
                        return <li key={key}>{tile}</li>  
                      })}
                      </ul>
                  <a
                        href={content?.buttonUrl ? content.buttonUrl : "#"}
                    className="globalButton withCircle whiteBtn"
                    aria-label="Click here to learn more"
                      >
                        {content?.buttonText ? content.buttonText : "Learn More"}
                  </a>
                  <a
                    href={ allPortfolioButtonUrl ? allPortfolioButtonUrl :"#"}
                    className="viewPorfolio"
                    aria-label="Click here to View All Portfolio"
                  >
                    { allPortfolioButtonText ? allPortfolioButtonText :"View All Portfolio"}
                    <span className="demo-icon icon-right-arrow-1"></span>
                  </a>
                </div>
              </div>
              <div className="col-7">
                  <div className="protfolioSlideContent">
                      
                  <ImageConversion
                    url={featureImage}
                    altext={featureTitle}
                    />

                </div>
              </div>
            </div>
          </div>
        </div>
             )
            })
          }
      </section>
    </section>
  );
};
