import Image from "next/image";
import Link from "next/link";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useRef } from "react";
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
import parse from 'html-react-parser';
import useWindowSize from '@/utils/hooks/useWindowSize';
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))


export const LatestStudio = ({title,subTitle,description,bolgPosts,buttonUrl,buttonText}:any) => {
  const latestStudio = useRef<HTMLDivElement>(null);
  const data = JSON.parse(bolgPosts);
  function renderDate(dateStr: any) {
    const today = new Date();
    today.setUTCHours(0, 0, 0, 0);
  
    const yesterday = new Date(today);
    yesterday.setUTCDate(today.getUTCDate() - 1);
  
    const inputDate = new Date(dateStr);
  
    if (inputDate.toUTCString() === today.toUTCString()) {
      return "Today";
    } else if (inputDate.toUTCString() === yesterday.toUTCString()) {
      return "Yesterday";
    } else {
      const months = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
      ];
  
      const monthName = months[inputDate.getUTCMonth()];
      const day = String(inputDate.getUTCDate()).padStart(2, "0");
      const year = inputDate.getUTCFullYear();
      return `${monthName} ${day}, ${year}`;
    }
  } 
  
  const { width } = useWindowSize();

  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      setTimeout(() => {
      const letsTalkTl = gsap.timeline();
      ScrollTrigger.create({
        animation: letsTalkTl,
        trigger: latestStudio.current,
        start: "top 80%",
        end: "+=1000px",
        scrub: true,
      });

      gsap.set(".latest--frame--1", { xPercent: 50, opacity: 0 });
      gsap.set(".latest--frame--2", { xPercent: 80, opacity: 0 });
      gsap.set(".latest--frame--3", { xPercent: 60, opacity: 0 });
      gsap.set(".latest--frame--5", { xPercent: 100, opacity: 0 });

      letsTalkTl
        .to(".latest--frame--1", {
          xPercent: 0,
          opacity: 1,
          duration: 2,
          ease: "Power4.easeOut",
        })
        .to(
          ".latest--frame--2",
          { xPercent: 0, opacity: 1, duration: 2, ease: "Power4.easeOut" },
          "<"
        )
        .to(
          ".latest--frame--3",
          { xPercent: 0, opacity: 1, duration: 2, ease: "Power4.easeOut" },
          "<"
        )
        .to(
          ".latest--frame--5",
          { xPercent: 0, duration: 5, opacity: 1, ease: "Power4.easeOut" },
          "<"
        );
      }, 1000);
    }, latestStudio);

    return () => ctx.revert();
  }, []);

  return (
    <section className="latestStudioPin" ref={latestStudio}>
      <div className="latestestStudioMain paddingY128 HomeBlog">
        <div className="container latestStudioInner">
          <div className="row">
            <div className="col-4 col-12-sm">
              <div className="leftPanel">
                <h3>
                  <span className="latest--frame--1">{title}</span>
                  <span className="latest--frame--2">{subTitle}</span>
                </h3>
                <div className="description">{parse(description)}</div>
                {width > 767 && <div className="button latest--frame--3">
                  <Link
                    href= {buttonUrl ? buttonUrl : "#"}
                    className="globalButton withCircle"
                    aria-label="All News"
                  >
                    {buttonText ? buttonText : "All News"}
                   
                  </Link>
                </div>}
              </div>
            </div>
            <div className="col-8 col-12-sm">
              <div className="rightPanel latest--frame--5">
                <div className="row">
                
                  {data.map((post: any, key: any) => {
                    let categoryName = post?.categories?.slice(0, 1);                  
                    const wpm = 225;
                    const words = documentToPlainTextString(post?.description).trim().split(/\s+/).length;
                    const time = Math.ceil(words / wpm);
                    return (
                      <div className="col-6 col-12-sm" key={key}>
                            <div className="newsPanel">
                              <div className="newsHeader">
                                <div className="adminHeader dFlex">
                                  <div className="iconPanel">
                                <Image src={`/images/trublogicon.svg`} alt="Tru icon" fill/>
                                  </div>
                                  <div className="headingPanel">
                                  <p className="postedBy">{renderDate(post.publishDate)}</p>
                                  <p className="author">{"TRU"}</p>
                                  </div>
                                </div>
                                 <Link href={`/blogs/${post.slug}`}><h4>{post?.postTitle}</h4></Link>
                              </div>
                              <div className="newsBody">
                                <div className="newsNav">
                                  <ul>
                                    {categoryName ? <li>{categoryName} </li>: " "}
                                    <li>{renderDate(post.publishDate)}</li>
                                    <li>{time} mins read</li>
                                  </ul>
                                </div>
                                <div className="newsImagePanel">
                              <Link href={`/blogs/${post.slug}`}>
                              <ImageConversion
                                      url={post?.gridFeaturedImage?.url ? post?.gridFeaturedImage?.url : "/images/blog/placeholder-desktop.png"}
                                      altext={post?.gridFeaturedImage?.title}

                                /> 
                                
                                </Link>
                                </div>
                              </div>
                            </div>
                          </div>
                      )
                      })
                    }

                {width < 768 && <div className="button latest--frame--3">
                  <Link
                    href= {buttonUrl ? buttonUrl : "#"}
                    className="globalButton withCircle"
                    aria-label="All News"
                  >
                    {buttonText ? buttonText : "All News"}
                   
                  </Link>
                </div>  }
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
