import parse from 'html-react-parser';
import Image from "next/image";
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))

export const Complaint = ({ imageUrl, imageAlt, description }: any) => {
    return<div className="complaint">
        <div className="container">
            <div className="complaint--left">
                <div className="complaint--left--logo">
                    {imageUrl && <ImageConversion
                        url={imageUrl}
                        altext={imageAlt}
                    />
                    }
                </div>
            </div>
            <div className="complaint--right">
                {description ? parse(description) : ""}
            </div>
        </div>
    </div>
}