import React, { useRef } from "react";
import gsap from "gsap";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import Link from "next/link";
interface TopBannerProps extends React.HTMLAttributes<HTMLDivElement> {

}

export const SocialShare: React.FC<TopBannerProps> = () => {
  const SocialShare = useRef<HTMLDivElement>(null);
  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      gsap.set(".sharePost", { scale: 2, opacity: 0 });
      gsap.set(".mainBannerSubheading", { xPercent: 20, opacity: 0 });

      gsap.to(".sharePost", {
        opacity: 1,
        scale: 1,
        duration: 1,
        ease: "Power4.easeOut",
        delay: 1,
      });
    }, SocialShare);
    return () => ctx.revert();
  }, []);

  return (
    <div>
      <div className="sharePost">
        <div className="sharePostHeading"> Share: </div>
        <div className="sharePostIcons">
          <ul>
            <li>
              <Link href="#" className="facebook dFlex">
                <span className="demo-icon icon-facebook"></span>
              </Link>
            </li>
            <li>
              <Link href="#" className="twitter dFlex">
                <span className="demo-icon icon-twitter-1"></span>
              </Link>
            </li>
            <li>
              <Link href="#" className="linkedin dFlex">
                <span className="demo-icon icon-linkedin-logo-svgrepo-com-1"></span>
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
