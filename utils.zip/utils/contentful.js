import gql from "graphql-tag";
import apolloClient from "./apollo-client"

export async function getHomepageData() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      homePageModelCollection(where:{pageSlug:"home-page"},limit:1) {
        items{
          ...on HomePageModel{
            pageSlug
            metaTitle
            metaDescription
            enableMetaIndex
            title
            allSectionsCollection(limit:10) {
          ... on HomePageModelAllSectionsCollection {
                items {
              ...on FullWidthImage{
                title
                image {
                  url
                  title
                }
                tag
              }
              ...on Headingsubheadingdescription {
                title
                subTitle
                description {
                  json
                }
                buttonText
                buttonUrl
                enableButton
                tag
              }
              ...on SectionWithCards {
                title
                image {
                  url
                  title
                }
                mobileImage {
                 url
                 title
               }
                description {
                     json
                }
                enableButton
                buttonText
                buttonUrl
                 cardsCollection {
                      items {
                      ...on CardWithImage {
                          title
                          description{
                           json
                         }
                         cardTextAbber
                          cardImage {
                            url
                            title
                          }
                          buttonText
                          buttonUrl
                        }
                    }
                }
                tag
              }
            }
          }
        }
       }
      }
     }
    } `
  });
     return data;
}


export async function getServiceArchive() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      homePageModelCollection(where:{pageSlug:"services"},limit:1) {
        items{
          ...on HomePageModel{
            pageSlug
            title
            metaTitle
            metaDescription
            enableMetaIndex
            allSectionsCollection(limit:10) {
          ... on HomePageModelAllSectionsCollection {
                items {
              ...on FullWidthImage{
                title
                image {
                  url
                  title
                }
                tag
              }
              ...on Headingsubheadingdescription {
                title
                subTitle
                description {
                  json
                }
                buttonText
                buttonUrl
                tag
              }
              ...on SectionWithCards {
                title
                image {
                  url
                  title
                }
                description {
                     json
                }
                buttonText
                buttonUrl
                 cardsCollection {
                      items {
                      ...on CardWithImage {
                          title
                          description{
                           json
                         }
                          cardImage {
                            url
                            title
                         }
                          showTitle
                          enableImage
                          buttonText
                          buttonUrl
                        }
                       ...on CardWithLinks {
                         title
                         description {
                           json
                         }
                         lineText
                         repeater
                         icon{
                          url
                          title
                        }
                       }
                    }
                }
                tag
              }
             ...on EnhanceSection{
               title
               subtitle
               description {
                 json
               }
               sectionImage {
                 url
                 title
               }
               mobileSectionImage {
                 url
                 title
               }
               tag
             }
            }
          }
        }
       }
      }
     }
    }`
  });
     return data;
}
export async function getPartnershipPage() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      homePageModelCollection(where:{pageSlug:"our-partnerships"},limit:1) {
        items{
          ...on HomePageModel{
            pageSlug
            title
            metaTitle
            enableMetaIndex
            metaDescription
            allSectionsCollection(limit:20) {
          ... on HomePageModelAllSectionsCollection {
                items {
              ...on FullWidthImage{
                title
                image {
                  url
                  title
                }
                tag
              }
              ...on Headingsubheadingdescription {
                title
                subTitle
                description {
                  json
                }
                buttonText
                buttonUrl
                tag
              }
              ...on SectionWithCards {
                title
                image {
                  url
                  title
                }
                description {
                     json
                }
                buttonText
                buttonUrl
                enableButton
                imagePosition
                enableTagline
                flexibleColumns
                tagLine
                 cardsCollection {
                      items {
                      ...on CardWithImage {
                          title
                        cardImage{
                          url
                          title
                        }
                        showTitle
                        showButton
                        buttonUrl
                        buttonText
                        }
                    }
                }
                tag
              }
            }
          }
        }
       }
      }
     }
    }`
  });
     return data;
}


export async function getPrivacyPage() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      homePageModelCollection(where:{pageSlug:"privacy-policy"},limit:1) {
        items{
          ...on HomePageModel{
            pageSlug
            title
            metaTitle
            enableMetaIndex
            metaDescription
            allSectionsCollection(limit:10) {
          ... on HomePageModelAllSectionsCollection {
                items {
              ...on FullWidthImage{
                title
                image {
                  url
                  title
                }
                tag
              }
              ...on Headingsubheadingdescription {
                title
                subTitle
                description {
                  json
                }
                buttonText
                buttonUrl
                tag
              }
            }
          }
        }
       }
      }
     }
    }`
  });
     return data;
}

export async function getcookiePolicyPage() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      homePageModelCollection(where:{pageSlug:"cookie-policy"},limit:1) {
        items{
          ...on HomePageModel{
            pageSlug
            title
            metaTitle
            enableMetaIndex
            metaDescription
            allSectionsCollection(limit:10) {
          ... on HomePageModelAllSectionsCollection {
                items {
              ...on FullWidthImage{
                title
                image {
                  url
                  title
                }
                tag
              }
              ...on Headingsubheadingdescription {
                title
                subTitle
                description {
                  json
                }
                buttonText
                buttonUrl
                tag
              }
            }
          }
        }
       }
      }
     }
    }`
  });
     return data;
}

export async function getTermPage() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      homePageModelCollection(where:{pageSlug:"terms-conditions"},limit:1) {
        items{
          ...on HomePageModel{
            pageSlug
            metaTitle
            metaDescription
            enableMetaIndex
            title
            allSectionsCollection(limit:10) {
          ... on HomePageModelAllSectionsCollection {
                items {
              ...on FullWidthImage{
                title
                image {
                  url
                  title
                }
                tag
              }
              ...on Headingsubheadingdescription {
                title
                subTitle
                description {
                  json
                }
                buttonText
                buttonUrl
                tag
              }
            }
          }
        }
       }
      }
     }
    }`
  });
     return data;
}



export async function getSingleServicePage(slug) {
     const { data } = await apolloClient.query({
       query: gql`
       query {
        singleServiceCollection(limit:1,where:{slug:"${slug}"}) {
          items {
            serviceTitle
            slug
            sectionsCollection(limit:15) {
              items {
                ...on ServiceContactSection{
                  __typename
                  title
                  description{
                    json
                  }
                 tag
                }
                ...on Headingsubheadingdescription{
                  title
                  subTitle
                  description{
                    json
                  }
                  tag
                }
                ...on SectionWithCards {
                 __typename
                  title
                  description {
                    json
                  }
                  image {
                       url
                       title
                      }
                  tag
                  cardsCollection(limit:50) {
                    items {
                      ...on Cards {
                        heading
                        description {
                          json
                        }
                      }
                     ... on CardWithImage {
                       title
                       description{
                         json
                       }
                       cardImage{
                         url
                         title
                       }
                     }
                    }
                  }
                 
                 
                }
                ...on CardSliderService{
                 __typename
                  cardSliderImagesCollection(limit:10){
                    items{
                      ...on CardWithImage{
                       title
                        cardImage{
                          url
                          title
                        }
                        showTitle
                      }
                    }
                  }
                 tag
                }
                ...on FullWidthImage{
                  title
                  image {
                    url
                    title
                  }
                  belowBannerTitle
                  belowBannerSubTitle
                  belowBannerDescription {
                    json
                  }
                  serviceContactSection
                  serviceContactSectionDescription {
                    json
                  }
                  serviceContactButtonText
                  serviceContactButtonUrl 
                  tag
                }
                ...on SectionHeading{
                 __typename
                  sectionHeading
                  description{
                    json
                  }
                 tag
                }
                ...on DescriptionWithHeading {
                 __typename
                  heading
                  sideDescription{
                    json
                  }
                 tag
                }
                ...on ServiceContactSection{
                 __typename
                  title
                  description{
                    json
                  }
                  buttonText
                  buttonUrl
                  tag
                }
                ...on HeadingWithDescription {
                  title
                  description{
                    json
                  }
                  buttonText
                  buttonUrl
                  tag
                }
              }
            }
          }
        }
  }  `
     });
        return data;
   }


   export async function getSingleServicePagenew(slug) {
    const { data } = await apolloClient.query({
      query: gql`
      query {
          singleServiceCollection(limit:1,where:{slug:"${slug}"}) {
            items {
              serviceTitle
              slug
              metaTitle
              enableMetaIndex
              metaDescription
              sectionsCollection(limit:15) {
                items {
                  ...on FullWidthImage {
                    title
                    image {
                      url
                      title
                    }
                    tag
                  }
                  ...on Headingsubheadingdescription {
                      title
                      subTitle
                      description {
                        json
                      }
                      enableButton
                      buttonText
                      buttonUrl
                      tag
                  }
                   ...on SectionWithCards {
                      title
                      description {
                        json
                      }
                    image {
                        url
                        title
                      }
                      imagePosition
                      tagLine
                      enableTagline
                      flexibleColumns
                      customClasses
                      customClassCardGrid
                     cardsCollection {
                      items{
                      ...on CardWithImage {
                         showTitle
                         showButton
                         title
                         description {
                          json
                         }
                         popupDescription
                         popupButtonText
                         popUpButtonUrl
                         cardImage {
                              url
                              title
                         }
                         showButton
                         buttonText
                         buttonUrl
                         }
                      }
                    }
                      tag
                    }
                    ...on EnhanceSection {
                      title
                      subtitle
                      description {
                        json
                      }
                      descriptionBottom
                      sectionImage {
                        url
                        title
                      }
                      mobileSectionImage {
                        url
                        title
                      }
                      tag
               }
                }
              }
            }
          }
    } `
    });
       return data;
  }

  
   
// export async function getSingleServicePage(slug) {
//   const { data } = await apolloClient.query({
//     query: gql`
//     query {
//       cardsCollection(limit:1,where:{slug:"${slug}"} ) {
//         items{
//           description{
//             json
//           }
//           heading
//           slug
//           buttonText
//         }
//       }
//     } `
//   });
//      return data;
// }

export async function allServicesHomePage(slug) {
     const { data } = await apolloClient.query({
       query: gql`
         query {
           singleServiceCollection(limit:50) {
           items{
             slug
             serviceTitle
             enableMetaIndex
           }
         }
       }`
     });
        return data;
}   

export async function aboutUsPage() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      aboutUsModelCollection(limit:5) {
        items{
          __typename
          ...on AboutUsModel {
            pageName
            subtitle
            pageSlug
            allSectionsCollection(limit:10) { 
              __typename
              ...on AboutUsModelAllSectionsCollection{
                items {
                  ...on WhatWeDone{
                    title
                    subHeading
                    description {
                      json
                    }
                    projectsCompleted
                    appsPlugins
                    membersOfStaff
                    countriesSaved
                    gitCommits
                    users
                    tag 
                  }
                  ...on FullWidthImage {
                    title
                    image {
                      url
                      title
                    }
                    tag
                  }
                  
                  ...on Headingsubheadingdescription {
                    title
                    subTitle
                    description{
                      json
                    }
                    tag
                  }
                  ...on SectionWithCards {
                    title
                    description {
                      json
                    }
                    tag
                  }
                  ...on CardSliderService {
                    tag
                    title
                    description{
                      json
                    }
                    image{
                      url
                      title
                    }
                    cardSliderImagesCollection {
                      items {
                        ...on CardWithImage{
                          title
                          description{
                            json
                          }
                          cardImage{
                            url
                            title
                          }
                        }
                        
                      }
                    }
                    
                  }
                }
              }
            }
          }
        }
      }
  } `
  });
     return data;
}

export async function getContactPage() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      contactUsPageCollection(limit:1) {
        items{
          ...on ContactUsPage{
            title
            pageSubTitle
            slug
            metaTitle
            enableMetaIndex
            metaDescription
            emailSupportTitle
            supportEmailAddress
            callSupportTitle
            supportPhoneNumber
            bannerImage{
              url
              title
            }
            contactFormTitle
            contactFormSubTitle
            faqSectionHeading
            subheading
            sectionsCollection{
                items {
                  ...on Accordion{
                   	 accordions
                    tag
                  }
                  ...on SectionWithCards {
                      cardsCollection(limit:5) {
                      items{
                         ...on CardWithImage {
                          showTitle
                          title
                          cardImage{
                            title
                            url
                          }
                          buttonUrl
                        }
                      }
                      
                    }
                    tag
                  }
                  
                  ...on Headingsubheadingdescription{
                    title
                    subTitle
                    description{
                      json
                    }
                    tag
                  }
                 
                  
                }
            }
            
          }
        }
      }
  }`
 });
        return data;
}
export async function getBlogsPosts(limit=6,skip=0) {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      blogPostsCollection(order:publishDate_DESC,limit:${limit},skip:${skip}) {
          total
          __typename
          items {
          __typename
          ...on BlogPosts {
            postTitle
            slug
            excerpt
            description {
              json
            }
            gridFeaturedImage{
              url
              title
            }
            featuredImage {
              url
              title
            }
            categories
            publishDate
          }
        }
        }
    }`
  });
  return data;
}

export async function getBlogsHome() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      blogPostsCollection(limit:2) {
          __typename
          items {
          __typename
          ...on BlogPosts {
            postTitle
            slug
            excerpt
            description {
              json
            }
            featuredImage {
              url
              title
            }
            gridFeaturedImage{
              url
              title
            }
            categories
            publishDate
          }
        }
        }
    }`
 });
        return data;
}

export async function getAllBlogsPost() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      blogPostsCollection(limit:100) {
          items {
          ...on BlogPosts {
            postTitle
            slug
          }
        }
        }
 }`
 });
        return data;
}

export async function getBlogByCategory(slug) {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      blogPostsCollection(where:{categories_contains_some:"${slug}"}) {
           __typename
          items {
          __typename
          ...on BlogPosts {
            postTitle
            slug
            excerpt
            description {
              json
            }
            gridFeaturedImage{
              url
              title
            }
            featuredImage {
              url
              title
            }
            categories
            publishDate
          }
        }
        }
      }`
    });
      return data;
}



export async function getCategoryFilterAndInput(categories=[], searchInput, skip = 0, limit = 6) {
  const result  = categories?.map(obj => ({ categories_contains_some: obj }));
  const { data } = await apolloClient.query({
    query: gql`
      query GetBlogPosts($result: [BlogPostsFilter!]!, $searchInput: String!,$skip: Int!, $limit: Int!) {
        blogPostsCollection(where: {
           AND: [
            { OR: [
              { postTitle_contains: $searchInput },
              { description_contains: $searchInput },
              { excerpt_contains: $searchInput }
            ]},
            { OR: $result }
          ]
        },order:publishDate_DESC
          skip: $skip,
          limit: $limit) {
          total
          items {
            __typename
            ... on BlogPosts {
              postTitle
              slug
              excerpt
              description {
                json
              }
              featuredImage {
                url
                title
              }
              gridFeaturedImage{
                url
                title
              }
              categories
              publishDate
            }
          }
        }
      }
    `,
    variables: { result, searchInput,skip, limit  }
  });

  return data;
}

export async function getInputData(searchInput) {
  const { data } = await apolloClient.query({
    query: gql`
      query  {
        blogPostsCollection(where: 
          {OR:
            [
            { postTitle_contains: "${searchInput}" },
            { description_contains: "${searchInput}" },
            { excerpt_contains: "${searchInput}" }
           ]
           },order:publishDate_DESC) {
          total
          items {
            __typename
            ...on BlogPosts {
              postTitle
              slug
              excerpt
              description {
                json
              }
              featuredImage {
                url
                title
              }
              gridFeaturedImage{
                url
                title
              }
              categories
              publishDate
            }
          }
        }
      }
    `,
  });

  return data;
}

export async function getAllBlogCategory() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      blogPostsCollection {
          items {
          ...on BlogPosts {
            categories
          }
        }
      }
    }`
    });
      return data;
}
export async function getAllPortfolio() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      homePageModelCollection(where:{pageSlug:"portfolio"},limit:1){
       items{
       title
         allSectionsCollection(limit:4){
           items{
             ...on SectionWithCards{
               title
               description{
                 json
               }
               tag
               cardsCollection{
                  items {
                   ...on CardWithImage{
                     title
                     popupDescription
                   }
                 }
               } 
             }
           }
         }
          
       }
     }
     }`
    });
      return data;
}
  
export async function getSingleBlogPage(slug) {
     const { data } = await apolloClient.query({
       query: gql`
       query {
        blogPostsCollection(where:{slug:"${slug}"} ,limit:1) {
             __typename
            items {
            __typename
            ...on BlogPosts {
              postTitle
              metaTitle
              enableMetaIndex
              metaDescription
              slug
              excerpt
              description {
                json
                links {
                  entries {
                    block {
                      sys {
                        id
                    }
                      ...on Headingsubheadingdescription {
                        title
                        subTitle
                        description{
                          json
                        }
                        buttonUrl
                        buttonText
                        enableButton
                        featureImage{
                          title
                          url
                        }
                        tag
                      }
                      ...on Accordion {
                         heading
                       	 accordions
                         tag
                      }
                      ...on SectionWithCards {
                        cardsCollection (limit:5) {
                          items{
                            ...on CardWithImage{
                              title
                              description{
                                json
                              }
                              cardImage{
                                url
                                title
                                description
                              }
                              
                            }
                          }
                        }
                        tag
                      }
                    }
                  }
                  assets {
                    block {
                      sys {
                        id
                    }
                      url
                      title
                      description
                    }
                  }
                }
              }
              enableFeaturedImage
              featuredImage {
                title
                url
              }
              tableOfContents
              categories
              publishDate
            }
          }
          }
        }`
       });
         return data;
   }
export async function getEntry(id) {
    const { data } = await apolloClient.query({
      query: gql`
      query {
        entryCollection(where:{sys:{id:"${id}"}},limit:1){
           items{
            ...on Headingsubheadingdescription{
                  title
                  subTitle
                  description{
                    json
                  }
                  enableButton
                  buttonText
                  buttonUrl
                  tag
                  featureImage {
                    url
                    title
                    description
                  }
            }
            ...on Accordion {
              heading
              accordions
              tag
            }
         }
       }
      }`
      });
        return data;
}
 
  

export async function getAboutNew() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      aboutUsModelCollection(limit:1) {
        items{
          ...on AboutUsModel {
            pageName
            metaTitle
            metaDescription
            enableMetaIndex
            subtitle
            pageSlug
            allSectionsCollection(limit:20) {
              ...on AboutUsModelAllSectionsCollection{
                items {
                  ...on FullWidthImage {
                    title
                    image {
                      url
                      title
                    }
                    tag
                  }
                  ...on Headingsubheadingdescription {
                    title
                    subTitle
                    description{
                      json
                    }
                    tag
                  }
                  ...on WhatWeDone{
                    title
                    subHeading
                    description {
                      json
                    }
                    projectsCompleted
                    appsPlugins
                    membersOfStaff
                    countriesSaved
                    gitCommits
                    users
                    tag 
                  }
                  ...on SectionWithCards {
                    title
                    description {
                      json
                    }
                    image{
                      url
                      title
                    }
                    buttonText
                    buttonUrl
                    tag
                    cardsCollection(limit:50) {
                      items {
                          ...on CardWithImage{
                            title
                            description{
                              json
                            }
                            cardImage{
                              url
                              title
                            }
                            cardTextAbber
                            buttonUrl
                            enableImage
                            showTitle
                          }
                      }
                    }
                  }
                  ...on FullWidthImage {
                    title
                    image {
                      url
                      title
                    }
                    tag
                  }
                  ...on Headingsubheadingdescription {
                    title
                    subTitle
                    description{
                      json
                    }
                   enableButton
                   buttonUrl
                   buttonText
                    tag
                  }
                }
              }
            }
          }
        }
      }
  } `
    });
      return data;
  }

  export async function getBlogPage() {
     const { data } = await apolloClient.query({
          query: gql`
          query {
            blogPageCollection {
                 items{
                pageName
                metaTitle
                metaDescription
                enableMetaIndex
                subtitle
                pageSlug
                 topBanner{
                   url
                   title
                 }
                     sectionCollection{
                       items{
                         ...on Headingsubheadingdescription{
                           title
                           subTitle
                           description{
                             json
                           }
                           tag
                         }
                       }
                     }
                
                 }
               }
          }`
});
return data;
}
   


export async function searchQuery(searchString) {
     const { data } = await apolloClient.query({
     query: gql`
     query {
          aboutUsModelCollection(where:
           {
             OR: 
               [
                 {excerpt_contains:"${searchString}"}
                 {pageName_contains:"${searchString}"}
               ]
           }) {
           items{
             pageName
             excerpt
             pageSlug
           }
         }
         homePageModelCollection(where:
           {
             OR:
               [
                 {excerpt_contains:"${searchString}"}
                 {title_contains:"${searchString}"}
               ]
             }){
           items {
             title
             excerpt
             pageSlug
             __typename
           }
         }
            blogPostsCollection(where:
           {
             OR:
               [
                 {excerpt_contains:"${searchString}"}
                 {postTitle_contains:"${searchString}"}
               ]
           }){
           items {
             postTitle
             excerpt
             slug
             __typename
           }
            }
            singleServiceCollection(where:
           {
              OR:
               [
                 {excerpt_contains:"${searchString}"}
                 {serviceTitle_contains:"${searchString}"}
               ]
           }){
         items {
           serviceTitle
           excerpt
           slug
           __typename
         }
       }
          }`
});
return data;
}

export async function getNavigation() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      topNavigationCollection {
            __typename
            items {
                __typename
                ...on TopNavigation {
                    metaTag
                    gtmCode
                    topNav
                    megaMenuDesktop
                    navLinks
                }
            }
        }
      }`
    }
  );
  return data;
}

export async function getAdminEmailInfo() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      topNavigationCollection {
            items {
              senderEmail
              senderPassword
              adminEmail
            }
        }
      }`
    }
  );
  return data;
}

export async function footerNavigation() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      footerCollection {
        __typename
        items {
          ...on Footer{
            title
            footerIcon{
              url
              title
            }
            quickLinkHeading
            quickLinks
            locationHeading
            bottomFooterLinks
            locationOne
            locationTwo
            locationThree
            supportEmailFooter
            tag
          }
        }
      }
    }`
    }
  );
  return data;
}

export async function getSearchSuggestions() {
  const { data } = await apolloClient.query({
    query: gql`
      query {
      topNavigationCollection {
            items {
              searchSuggestions
            }
        }
      }`
  });
  return data;
}
export async function getPortfolioPage() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      homePageModelCollection(where:{pageSlug:"portfolio"},limit:1){
       items{
       title
       metaTitle
       enableMetaIndex
       metaDescription
       excerpt
       pageSlug
         allSectionsCollection{
           items{
             ...on SectionWithCards {
               title
               description{
                 json
               }
              image{
                url
                title
              }
              imagePosition
              flexibleColumns
              tag
              buttonText
              enableButton
              tag
              cardsCollection(limit:50){
                  items {
                   ...on CardWithImage{
                     title
                     popupDescription
                     enablePopup
                     enableImage
                     cardImage{
                      url
                      title
                    }
                    showButton
                    buttonUrl
                   }
                 }
               } 
             }
            ...on Headingsubheadingdescription {
              subTitle
              tag
            	enableButton
              buttonUrl
              buttonText
            }
           }
         }
          
       }
      }
    }`
  });
  return data;
}

export async function getAnnouncementHeader() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      topAnnouncementHeaderCollection{
        items{
          enableSection
          desktopLogoRight{
            url
            title
          }
          mobileLogoRight {
            url
            title
          }
          desktopPatternLeft{
            url
            title
          }
          desktopPatternRight{
            url
            title
          }
          mobilePattern{
            url
            title
          }
          listItemsCollection{
            items{
              title
              showTitle
              enableImage
              cardImage{
                url
                title
              }
            }
          }
        }
      }
}`
  });
  return data;
}
export async function getJobPostings() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      jobPostingCollection(order:sys_firstPublishedAt_DESC){
        items {
          sys {
            id
            firstPublishedAt
          }
          jobTitle
          jobType
          industry
          jobCity
          province
          country
          aboutUs {
            json
          }
          jobDescription {
            json
          }
          requirements {
            json
          }
        }
      }
    }`
  });
  return data;
}

export async function getSingleJobPostings(id) {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      jobPostingCollection(where:{
          sys: {
            id: "${id}"
          }
      },limit:1) {
          items {
            sys {
              firstPublishedAt
            }
            jobTitle
            jobType
            industry
            jobCity
            province
            country
            aboutUs {
              json
            }
            jobDescription {
              json
            }
            requirements {
              json
            }
            questionsCollection{
              items{
                ...on Question {
                  fieldType
                  fieldLabel
                  required
                  fieldName
                  errorMessage
                }
              }
            }
        }
    } 
}`
  });
  return data;
}

export async function getJobSearchQuery(jobTitle,location) {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      jobPostingCollection( where: {
            AND: [{ jobTitle_contains: "${jobTitle}" }]
            OR: [
              { province_contains: "${location}" }
              { jobCity_contains: "${location}" }
              { country_contains: "${location}" }
            ]
          }) {
          items {
            sys {
              id
              firstPublishedAt
            }
            jobTitle
            jobType
            industry
            jobCity
            province
            country
            aboutUs {
              json
            }
            jobDescription {
              json
            }
            requirements {
              json
            }
          }
      }
    }`
  });
  return data;
}


export async function getAsset(id) {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      asset(id : "${id}"){
        title
        url
        description
        width
        height
      }
  }`
  });
  return data;
}

export async function getEventPage() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      homePageModelCollection(where:{pageSlug:"events"},limit:1){
       items {
       title
       pageSlug
         allSectionsCollection(limit:2) {
           items {
            ... on Headingsubheadingdescription {
              title
              subTitle
              tag
              description{
                json
              }
              featureImage{
                url
                title
              }
            }
           }
         }
       }
     }
  }`
    });
      return data;
}
export async function getAllEvents(useEventFrom = true , search = false, searchInput = "", limit=6,skip=0) {
  const date = new Date();
  const ISOString = date.toISOString().split('T')[0];
  let whereCondition = useEventFrom
    ? `{ eventTo_gte: "${ISOString}T00:00:00.000Z" }`
    : `{ eventTo_lte: "${ISOString}T00:00:00.000Z" }`;

  if (search) {
    const searchData = {
      AND: [
        { eventTo_lte: `${ISOString}` }, // Added eventTo_lte condition
        {
          OR: [
            { postTitle_contains: searchInput },
            { description_contains: searchInput },
          ]
        }
      ]
    };
    whereCondition = `{ AND: [${formatSearchData(searchData)}] }`;
  }
    
    function formatSearchData(searchData) {
      return JSON.stringify(searchData).replace(/\"([^(\")"]+)\":/g,"$1:").replace(/"(\w+)"(?=:)/g, '$1');
    }
  
  const { data } = await apolloClient.query({
    query: gql`
    query {
      singleEventCollection(where:${whereCondition}, limit: ${limit}, skip: ${skip},order: eventFrom_DESC){
      total
        items {
          slug
          postTitle
          metaTitle
          metaDescription
          archiveSocialImage {
            url
            title
            description
          }
          location
          eventFrom
          eventTo
        }
      }
    }`
  });
      return data;
}


export async function getSingleEvent(slug) {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      singleEventCollection(where:{slug:"${slug}"},  limit:1){
      total
      items {
        sys{
          firstPublishedAt
        }
        slug
        postTitle
        metaTitle
        enableMetaIndex
        metaDescription
        description {
          json
          links {
          entries {
            block {
              sys{
                id
              }
              __typename
              ...on Headingsubheadingdescription {
                subTitle
                description{
                  json
                }
                buttonUrl
                buttonText
                enableButton
                tag
              }
            }
          }
          assets {
            block {
              sys {
                id
              }
              url
              description
              title
            }
          }
        }
        }
        enableFeaturedImage
        archiveSocialImage {
          url
          title
          description
        }
        featuredImage {
          url
          title
          description
        }
        location
        eventFrom
        eventTo
      }
    }
  }`
    });
      return data;
}

export async function getAllEvent(slug) {
  const { data } = await apolloClient.query({
    query: gql`
    query {
      singleEventCollection{
      total
        items {
          slug
          postTitle
          metaTitle
          metaDescription
          archiveSocialImage {
            url
            title
            description
          }
          location
          eventFrom
          eventTo
        }
      }
    }`
    });
      return data;
}




export default {
  getSearchSuggestions, footerNavigation, getNavigation, searchQuery, getBlogPage,
  getAboutNew, getSingleServicePagenew, getAllBlogCategory, getBlogByCategory,
  getHomepageData, allServicesHomePage, getSingleServicePage, aboutUsPage,
  getContactPage, getBlogsPosts, getSingleBlogPage, getBlogsHome, getAnnouncementHeader, getJobPostings, getSingleJobPostings
};