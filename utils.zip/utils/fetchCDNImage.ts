// utils/fetchCDNImage.ts

import axios from 'axios';

export async function fetchCDNImage(url: string, headers: any) {
  try {
    const response = await axios.get(url, { headers, responseType: 'arraybuffer' });
    return Buffer.from(response.data, 'binary').toString('base64');
  } catch (error) {
    console.error('Error fetching CDN image:', error);
    return null;
  }
}
