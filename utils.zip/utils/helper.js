// export function capitalizeString(str) {
//      return str.charAt(0).toUpperCase() + str.slice(1);
// }
export function removeBaseUrl(url=""){
     const baseUrl = 'https://images.ctfassets.net';
     return url.replace(baseUrl, '');
};
