import { ApolloClient, InMemoryCache } from "@apollo/client";
import { ApolloLink } from "apollo-link";
import { HttpLink } from "apollo-link-http";

const TOKEN = `${process.env.NEXT_PUBLIC_CONTENTFUL_ACCESS_TOKEN}`;
const SPACE = `${process.env.NEXT_PUBLIC_CONTENTFUL_SPACE_ID}`;
const URL = `${process.env.NEXT_PUBLIC_GRAPHQL_URL}`;

const http = new HttpLink({
  uri: URL,
  headers: {
    Authorization: `Bearer ${TOKEN}`,
  },
});
const defaultOptions = {
  watchQuery: {
    fetchPolicy: 'no-cache',
    errorPolicy: 'ignore',
  },
  query: {
    fetchPolicy: 'no-cache',
    errorPolicy: 'all',
  },
};

const link = ApolloLink.from([http]);
const cache = new InMemoryCache();
const apolloClient = new ApolloClient({
  link,
  cache,
  defaultOptions,
});

export default apolloClient;