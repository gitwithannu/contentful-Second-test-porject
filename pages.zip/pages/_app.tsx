import { useEffect, useRef } from "react";
import "@/styles/globals.scss";
import "src/styles/main.scss";
import "src/styles/brand/css/animation.css";
import "src/styles/brand/css/fontello-codes.css";
import "src/styles/brand/css/fontello-embedded.css";
import "src/styles/brand/css/fontello-ie7-codes.css";
import "src/styles/brand/css/fontello-ie7.css";
import "src/styles/brand/css/fontello.css";
import { useRouter } from "next/router";

import type { AppProps } from "next/app";

import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import Scrollbar from "smooth-scrollbar";
import Layout from "./Layout";
import { getNavigation,footerNavigation,getAnnouncementHeader } from "@/utils/contentful";
interface CustomProp extends AppProps{
  props?: any
}

gsap.registerPlugin(ScrollTrigger);

export default function App({ Component, pageProps, props }: CustomProp) {
  gsap.config({ nullTargetWarn: false });
  const router = useRouter();
  const scroller = useRef<HTMLDivElement | null>(null);
  const bodyScrollBar = useRef();

  useEffect(() => {
    //@ts-ignore
    bodyScrollBar.current = Scrollbar.init(scroller.current);
    ScrollTrigger.scrollerProxy(scroller.current, {
      scrollTop(value) {
        if (arguments.length) {
          //@ts-ignore
          bodyScrollBar.current.scrollTop = value;
        }
        //@ts-ignore
        return bodyScrollBar.current.scrollTop;
      },
    });
    //@ts-ignore
    bodyScrollBar.current?.addListener(({ offset }:any) => {
      const { y } = offset;
      const header = document.querySelector('.header-custom');

      // Check if the user is scrolling
      if (y > 10) {

        header?.classList.add('fixed');
        header?.classList.add('headerBackground');
        // Add your scrolling-related logic here
      } else {
        header?.classList.remove('fixed');
        header?.classList.remove('headerBackground');
        // Additional logic when not scrolling
      }
     });
    //@ts-ignore
    bodyScrollBar.current.addListener(ScrollTrigger.update);
    ScrollTrigger.defaults({ scroller: scroller.current });
    return () => {
      // Clean up the event listeners or any resources if needed
      //@ts-ignore
      bodyScrollBar.current.destroy();
    };
  }, [router?.asPath]);

  useEffect(() => {
    const pageChanged = () => {
      ScrollTrigger.refresh();
      const header = document.querySelector('.header-custom');
      header?.classList.remove('fixed');
      header?.classList.remove('headerBackground');
    };
    router.events.on("routeChangeStart", pageChanged);
  }, [router.events]);

  //@ts-ignore
  return (
    //@ts-ignore
    <>
    <div ref={scroller} className="scroller" style={{ height: "100vh" }}>
      <Layout data={props?.data} announcementData={props?.announcementHeader} footerData={props?.footerData}>
        <Component {...pageProps} />
      </Layout>
    </div>
      </>
  );
}

App.getInitialProps = async (context : any) => {
  const data = await getNavigation();
  const announcementHeader = await getAnnouncementHeader();
  const footerData = await footerNavigation();
  return {
    props: {
      data,
      announcementHeader,
      footerData
    },
    revalidate: 60
  }
}
