import { NextApiRequest, NextApiResponse } from 'next';
import { getServicespublish, BlogDatePublic, allsitmapPage } from './api/siteMapindex';

interface Props {
	Blogpublish?:any,
	servicesPublish?:any,
	PagespublishDate:any
}

const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || '';
function generateSiteMap(posts: any[]) {
  return `<?xml version="1.0" encoding="UTF-8"?>
   <sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
     ${posts
       .map(({ url, date }) => {
         return `
		<sitemap>
			<loc>${`${BASE_URL}${url}`}</loc>
		</sitemap>
     `;
       })
       .join('')}
   </sitemapindex>
 `;
}

const SiteMap = () => null;

export async function getServerSideProps({ res }: { res: NextApiResponse }) {
	const [PagespublishDate,servicesPublish,Blogpublish] = await Promise.all([
	  allsitmapPage(),
	  getServicespublish(),
	  BlogDatePublic()
	]);
	
	const Bloglist = Blogpublish?.blogPostsCollection?.items;
	const BlogpublishDate  = Bloglist?.map((itemUrl:any) => itemUrl?.sys?.firstPublishedAt);
	const servicesPublishData = servicesPublish?.singleServiceCollection?.items;
	const ServicePublishdate  = servicesPublishData?.map((itemUrl:any) => itemUrl?.sys?.firstPublishedAt);
	let resultasd = Object.values(PagespublishDate);
  	var arrpages = Object.keys(resultasd).map(function (key:any) { return resultasd[key]; });
	const PagesPublisdDate = arrpages?.map((itemEach : any) => itemEach);
	const pagedatlaarya = PagesPublisdDate?.map((items) => items?.items);
	let pageArraymain:any = []
	pagedatlaarya.map((test:any) =>{
		test?.map((itemsarray :any ) => {
			pageArraymain?.push(itemsarray)
		})
	})
	const itempagedatemap = pageArraymain?.map((itemdate : any) => {
		const filteracending = itemdate?.sys?.firstPublishedAt
		return filteracending
	})
	function sortArrayByDateDescending(arr : any) {
		return arr.slice().sort((a:any, b:any) => {
		  const dateA = new Date(b);
		  const dateB = new Date(a);
		  const dayDifference = dateA.getUTCDate() - dateB.getUTCDate();
		  const monthDifference = dateA.getUTCMonth() - dateB.getUTCMonth();
		  const yearDifference = dateA.getUTCFullYear() - dateB.getUTCFullYear();
		  if (yearDifference !== 0) {
			return yearDifference;
		  } else if (monthDifference !== 0) {
			return monthDifference;
		  } else {
			return dayDifference;
		  }
		});
	}
	  
	const sortedData = sortArrayByDateDescending(itempagedatemap);
	const sortedDataService = sortArrayByDateDescending(ServicePublishdate);
	const sortedDatablog = sortArrayByDateDescending(BlogpublishDate);
	function convertUTCStringToDateAndTime(utcString:any) {
		const utcDate = new Date(utcString);
		const year = utcDate.getUTCFullYear();
		const month = utcDate.toLocaleString('default', { month: 'short' });
		const day = utcDate.getUTCDate();
		const hours = utcDate.getUTCHours();
		const minutes = utcDate.getUTCMinutes();
		const seconds = utcDate.getUTCSeconds();
		return `${day} ${month} ${year} ${hours}:${minutes}:${seconds}`;
	  }
	const sitemapFiles = [
		{url: `/sitemap_pages.xml`,date:`${convertUTCStringToDateAndTime(sortedData?.[0])}`},
		{url: `/sitemap_services.xml`,date:`${convertUTCStringToDateAndTime(sortedDataService?.[0])}`},
		{url: `/sitemap_blog.xml`,date:`${convertUTCStringToDateAndTime(sortedDatablog?.[0])}`}
	];
	const xmlContent = generateSiteMap(sitemapFiles);
	res.setHeader('Content-Type', 'application/xml');
	res.write(xmlContent);
	res.end();
	return { props: {} };
}

export default SiteMap;
