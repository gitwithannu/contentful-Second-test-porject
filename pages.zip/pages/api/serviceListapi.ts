import apolloClient from "@/utils/apollo-client";
import { gql } from "@apollo/client";

export async function getServiceArchive() {
    const { data } = await apolloClient.query({
      query: gql`
      query {
        singleServiceCollection {
          items {
            slug
          }
        }
   }`
    });
       return data;
  }