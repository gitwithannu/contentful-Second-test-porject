import apolloClient from "@/utils/apollo-client";
import { gql } from "@apollo/client";

export async function getBlogPages() {
    const { data } = await apolloClient.query({
      query: gql`
      query {
        blogPostsCollection {
            items {
              slug
            }
          }
        }`
    });
       return data;
  }