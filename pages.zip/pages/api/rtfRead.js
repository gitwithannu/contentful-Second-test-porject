import multer from 'multer';
import fs from 'fs';
import path from 'path';
import rtfToHtml from '@iarna/rtf-to-html';

const storage = multer.memoryStorage();
const upload = multer({ storage });

export const config = {
  api: {
    bodyParser: false,
  },
};

export default async function handler(req, res) {
  try {
    await upload.single('rtfFile')(req, res, async (err) => {
      if (err) {
        console.error('Error uploading file:', err);
        return res.status(500).json({ error: 'Error uploading file' });
      }

      const rtfBuffer = req.file.buffer;

      // Write the RTF buffer to a temporary file
      const tempRtfPath = path.join(__dirname, 'temp.rtf');
      fs.writeFileSync(tempRtfPath, rtfBuffer);

      try {
        // Convert RTF to HTML using @iarna/rtf-to-html
        const htmlContent = await rtfToHtml(tempRtfPath);

        // Clean up temporary file
        fs.unlinkSync(tempRtfPath);

        res.status(200).json({ tempRtfPath : tempRtfPath, success: true, message: 'RTF file converted to HTML successfully', htmlData: htmlContent });
      } catch (conversionError) {
        console.error('Error converting RTF to HTML:', conversionError);
        res.status(500).json({ error: 'Error converting RTF to HTML' });
      }
    });
  } catch (error) {
    console.error('Unexpected error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
}
