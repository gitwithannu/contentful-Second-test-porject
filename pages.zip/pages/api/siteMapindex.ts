import apolloClient from "@/utils/apollo-client";
import gql from "graphql-tag";

export async function allsitmapPage() {
     const { data } = await apolloClient.query({
       query: gql`
       query {
        aboutUsModelCollection {
           items{
            pageName
            sys{
              firstPublishedAt
            }
           }
         }
         homePageModelCollection{
           items {
             title
             sys{
              firstPublishedAt
            }
           }
         }
        contactUsPageCollection{
          items{
            title
            sys{
              firstPublishedAt
            }
          }
        }
  }`
     });
        return data;
   }


   export async function BlogDatePublic() {
    const { data } = await apolloClient.query({
      query: gql`
      query {
        blogPostsCollection {
            items {
              sys{
                firstPublishedAt
              }
              slug
            }
          }
        }`
    });
       return data;
}
   
export async function getServicespublish() {
  const { data } = await apolloClient.query({
    query: gql`
    query {
        singleServiceCollection {
          items {
            slug
            sys{
              firstPublishedAt
            }
          }
        }
      }`
  });
     return data;
}

export default {
    getServicespublish,BlogDatePublic,allsitmapPage
};