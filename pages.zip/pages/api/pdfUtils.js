// Import required modules
import multer from 'multer';
import fs from 'fs';
import path from 'path';
import pdfParse from 'pdf-parse';

// Set up Multer storage
const storage = multer.memoryStorage();
const upload = multer({ storage });

// Define the API route
export const config = {
  api: {
    bodyParser: false, // Disable built-in body parsing
  },
};

export default async function handler(req, res) {
  try {
    await upload.single('pdfFile')(req, res, async (err) => {
      if (err) {
        console.error('Error uploading file:', err);
        return res.status(500).json({ error: 'Error uploading file' });
      }
      const pdfBuffer = req.file.buffer;
      try {
        const filePath = path.join(process.cwd(), 'public', 'uploads', 'cv.pdf');
        fs.writeFileSync(filePath, pdfBuffer);
        const data = await pdfParse(pdfBuffer);
        res.status(200).json({ success: true, message: 'PDF file uploaded and parsed successfully',pdfData:data?.text });
      } catch (parseError) {
        console.error('Error parsing PDF:', parseError);
        res.status(500).json({ error: 'Error parsing PDF' });
      }
    });
  } catch (error) {
    console.error('Unexpected error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
}
