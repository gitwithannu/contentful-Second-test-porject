import multer from 'multer';
import fs from 'fs';
import path from 'path';
import { createODF } from 'simple-odf';

const storage = multer.memoryStorage();
const upload = multer({ storage });

export const config = {
  api: {
    bodyParser: false,
  },
};

export default async function handler(req, res) {
  try {
    await upload.single('odtFile')(req, res, async (err) => {
      if (err) {
        console.error('Error uploading file:', err);
        return res.status(500).json({ error: 'Error uploading file' });
      }

      const odtBuffer = req.file.buffer;
      const odfDocument = createODF(odtBuffer.toString('utf-8'));

      try {
        const textContent = odfDocument.getTextContent();
        res.status(200).json({ success: true, message: 'ODT file uploaded and parsed successfully', odtData: textContent });
      } catch (parseError) {
        console.error('Error parsing ODT:', parseError);
        res.status(500).json({ error: 'Error parsing ODT' });
      }
    });
  } catch (error) {
    console.error('Unexpected error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
}
