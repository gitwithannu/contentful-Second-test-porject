// pages/api/upload.ts

import type { NextApiRequest, NextApiResponse } from 'next';
import fs from 'fs';
import multiparty, { File } from 'multiparty';
import nodemailer, { Transporter } from 'nodemailer';
import { getAdminEmailInfo } from '@/utils/contentful';
export const config = {
  api: {
    bodyParser: false,
  },
};


interface FileData {
     fieldName: string;
     originalFilename: string;
     path: string;
     headers: Record<string, string>;
     size: number;
   }
   
   interface FilesData {
     [key: string]: FileData[];
   }

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }
     const navigation = await getAdminEmailInfo();
     const senderEmail = navigation?.topNavigationCollection?.items[0]?.senderEmail;
     const senderPass = navigation?.topNavigationCollection?.items[0]?.senderPassword;
     const adminEmail = navigation?.topNavigationCollection?.items[0]?.adminEmail;
     const form = new multiparty.Form();
     form.parse(req, async (err, fields, files) => {
     if (err) {
          return res.status(500).json({ error: 'Error parsing form data' });
     }
     const transporter = nodemailer.createTransport({
          service: 'gmail',
          auth: {
               user: senderEmail,
               pass: senderPass,
          },
     });
    try {
         if (fields?.formType[0] === "FormData") { 
                    const attachments:any = [];
                    for (const key in files) {
                         if (Object.hasOwnProperty.call(files, key)) {
                              const fileList:any = files[key];
                              fileList.forEach((file: FileData, index: number) => {
                                   const fileBuffer = fs.readFileSync(file.path);
                                        attachments.push({
                                        filename: file.originalFilename,
                                        content: fileBuffer  
                                   });
                              });
                         }
                    }
                    const { firstName, lastName, jobTitle, email } = JSON.parse(fields?.emailData[0]);
                    const userEmailMessage =
                         `<p>Dear ${firstName} ${lastName},Thank you for applying for the ${jobTitle} position at Tru. We have received your application and appreciate your interest in joining our team.</p> <p>Please note that we are currently in the process of reviewing all applications. If your qualifications match our requirements, we will contact you for the next steps in the recruitment process.</p> <p>We appreciate your time and effort in applying for this position.</p> <p>Best Regards,</p><p>Tru</p>`
                    const adminEmailMessage =
                         `<p> ${firstName} ${lastName}, Applied for the ${jobTitle} position at Tru. `
                    const userEmailOptions = {
                         from: senderEmail,
                         to: email,
                         subject: `Confirmation of job application for ${jobTitle} position`,
                         html: userEmailMessage,
                    };
                    const adminEmailOptions = {
                         from: senderEmail,
                         to: adminEmail,
                         subject: `Job application for ${jobTitle} position`,
                         html: adminEmailMessage,
                         attachments
                    };
                    try {
                         const info = await transporter.sendMail(adminEmailOptions);
                         const infoUser = await transporter.sendMail(userEmailOptions);
                         console.log('Email sent:', info);
                         console.log('Email sent:', infoUser);
                         res.status(200).json({ success: true, message: 'Email sent successfully' });
                    } catch (error) {
                         console.error('Error sending email:', error);
                         res.status(500).json({ success: false, message: 'Error sending email' });
                    }
         }
         
         if (fields?.formType[0] === "assessment") { 
              const assessmentData = JSON.parse(fields?.extraFormData[0])
              const { firstName, lastName, jobTitle, email } = JSON.parse(fields?.extraFormData[0]);
              const customFields:any = {};
              let concatenatedValue:any = "";
              Object.entries(assessmentData).forEach(([key, value]) => {
               if (key.startsWith('custom_') && typeof value === 'object') {
                 const { value: fieldValue, question } = value as { value: string; question: string };
                    customFields[key] = { value: fieldValue, question };
                    concatenatedValue += '<li> Question : '+ question+ '</li>';
                    concatenatedValue += '<li>Answer : ' + fieldValue + '</li>';
               }
              });
              const userEmailMessage = `<h4>User Assessment of ${firstName} </h4><p>${concatenatedValue}</p>`;
              const userEmailOptions = {
                    from: senderEmail,
                    to: adminEmail,
                    subject: `Job Assessment for ${jobTitle} position`,
                    html: userEmailMessage,
               };
               try {
                    const info = await transporter.sendMail(userEmailOptions);
                    console.log('Email sent:', info);
                    res.status(200).json({ success: true, message: 'Email sent successfully' });
               } catch (error) {
                    console.error('Error sending email:', error);
                    res.status(500).json({ success: false, message: 'Error sending email' });
               }    
         }
    } catch (error) {
      console.error('Error uploading data:', error);
      return res.status(500).json({ error: 'Internal Server Error' });
    }
  });
}
