import { NextApiRequest, NextApiResponse } from 'next';
import axios from 'axios';
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
     const { imagename } = req.query;
     const { spaceid } = req.query;
     const { uniqueid } = req.query;
     const { subimages } = req.query;
     const imageUrl = `https://images.ctfassets.net/${spaceid}/${uniqueid}/${subimages}/${imagename}`;
  try {
    const imageResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
    res.setHeader('Cache-Control', 'public, max-age=3600');
    res.setHeader('Server', 'Tru Agency');
    res.setHeader('Content-Type', 'image/svg+xml');
    res.status(200).send(imageResponse.data);
  } catch (error) {
    console.error('Error fetching image:', error);
    res.status(404).end();
  }
}
