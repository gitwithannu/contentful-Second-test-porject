const fs = require('fs');
const path = require('path');

async function handler(req, res) {
    const sitemapUrl = '/sitemap_index.xml';
    const webUrl = process.env.NEXT_PUBLIC_SITE_URL ? 
  `${process.env.NEXT_PUBLIC_SITE_URL}` :
          `https://${req.headers.host}`;
    const robotsTxtContent = `
User-agent: *
Disallow:
Sitemap: ${webUrl}${sitemapUrl}`;

    const robotsTxtPath = path.join(process.cwd(), 'public', 'robots.txt');
    fs.writeFileSync(robotsTxtPath, robotsTxtContent.trim());

    res.status(200).send('Robots.txt generated successfully');
}

module.exports = handler;
