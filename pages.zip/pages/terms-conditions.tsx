import { PageBanner } from "@/src/components";
import { getTermPage } from "@/utils/contentful";
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
import parse from 'html-react-parser';
import Head from 'next/head';
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || '';

const TermsCondition = ({ termPage }: any) => {
    const sectionData = termPage?.homePageModelCollection?.items;
    return sectionData?.map((section: any, key: any) => {
        const metaTitle = section?.metaTitle;
        const metaDescription = section?.metaDescription;
        const metaIndex = section?.enableMetaIndex;
        const pageSlug = section?.pageSlug;
        const allSections = section?.allSectionsCollection?.items
        const pageContent = allSections.filter((data: any) => {
            return data.tag === "pageContent";
        });
        return (
            <div key={key} className="termConditions">
                <Head>
                    <title>{metaTitle ? metaTitle : "TRU AGENCY"}</title>
                    {metaIndex && metaIndex != null ?
                        <meta name="robots" content="index, follow" />
                        :
                        <meta name="robots" content="noindex, nofollow" />
                    }
                    <meta
                    name="description"
                    content={metaDescription ? metaDescription : "TRU AGENCY"}
                    key="desc"
                    />
                    <link rel="canonical" href={`${BASE_URL}/${pageSlug}`} />
                    <script type="application/ld+json" dangerouslySetInnerHTML={{
                        __html: `{
                            "@context": "https://schema.org/", 
                            "@type": "BreadcrumbList",
                            "name": "BreadcrumbList",
                            "itemListElement": [{
                            "@type": "ListItem", 
                            "position": 1, 
                            "name": "Home",
                            "item": "${BASE_URL}"  
                            },{
                            "@type": "ListItem", 
                            "position": 2, 
                            "name": "${section?.title}",
                            "item": "${BASE_URL}/${pageSlug}"  
                            }]
                        }`
                    }} /> 
                </Head> 
                <PageBanner
                    title={section?.title}
                    className="hide-shadow"
                />
                {pageContent?.map((content: any, index: any) => {
                    const description = documentToPlainTextString(content?.description?.json)
                    return <div className="default-content" key={index}>
                        <div className="container">
                            <div className="row">
                                <div className="col-12">
                                    {description ? parse(description) : ""}
                                </div>
                            </div>
                        </div>
                    </div>
                })
                }
            </div>
        )
    })
}
export default TermsCondition;
  
export async function getStaticProps(context: any) {
    const termPage = await getTermPage();
    return {
      props: {
        termPage,
        },
        revalidate: 60
    };
}
  