import Image from "next/image";
import { PageBanner } from "@/src/components";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import { useRef } from "react";
import gsap from "gsap";
import Link from "next/link";
import { Modal } from "@/src/components/Modal";
import { PortfolioModal } from "@/src/components/PortfolioModal";
import { useState } from "react";
import Head from 'next/head';
import { getPortfolioPage } from "@/utils/contentful";
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
import dynamic from "next/dynamic";
import { removeBaseUrl } from "@/utils/helper"
import parse from 'html-react-parser';
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || '';
const Portfolio = ({ archivePortfolio }: any) => {
  const sectionData = archivePortfolio?.homePageModelCollection?.items;
  const portfolioRef = useRef<HTMLDivElement>(null);
  const [showModal, setShowModal] = useState(false);
  const [modalData, setModalData] = useState<any>();

  const toggleModal = (status: any) => {
    setShowModal(!showModal);
  };
  const toggle = (status: any) => {
    const modalData = status.target.getAttribute("modal-data");
    const enableModal = status.target.getAttribute("data-enable-modal");
    if (enableModal == 'true') {
      setModalData(modalData);
      setShowModal(!showModal);
    }
  }
  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      gsap.set(".mainBannerHeading", { scale: 2, opacity: 0 });
      gsap.set(".mainBannerSubheading", { xPercent: 20, opacity: 0 });

      gsap.to(".mainBannerHeading", {
        opacity: 1,
        scale: 1,
        duration: 1,
        ease: "Power4.easeOut",
        delay: 1,
      });
      gsap.to(".mainBannerSubheading", {
        xPercent: 0,
        opacity: 1,
        delay: 1,
        duration: 1,
      });
    }, portfolioRef);
    return () => ctx.revert();
  }, []);

  return sectionData?.map((section: any, index: any) => { 
    const allSections = section?.allSectionsCollection?.items;
    const pageSlug = section?.pageSlug;
    const metaIndex = section?.enableMetaIndex;
    const cardsData = allSections.filter((data: any) => {
      return data.tag === "cards";
    });
    const bottomContactSection = allSections.filter((data: any) => {
      return data.tag === "bottomContactSection";
    });
    const bottomServicePanel = allSections.filter((data: any) => {
      return data.tag === "bottomServicePanel";
    });
    return (
      <div key={section?.title}>
      <Head>
          <title>{section?.metaTitle}</title>
          {metaIndex && metaIndex != null ?
             <meta name="robots" content="index, follow" />
            :
             <meta name="robots" content="noindex, nofollow" />
          }
        <meta
          name="description"
            content={section?.metaDescription}
          key="desc"
          />
          <link rel="canonical" href={`${BASE_URL}/${pageSlug}`} />
          <script type="application/ld+json" dangerouslySetInnerHTML={{
            __html: `{
                "@context": "https://schema.org/", 
                "@type": "BreadcrumbList",
                "name": "BreadcrumbList",
                "itemListElement": [{
                "@type": "ListItem", 
                "position": 1, 
                "name": "Home",
                "item": "${BASE_URL}"  
                },{
                "@type": "ListItem", 
                "position": 2, 
                "name": "${section?.title}",
                "item": "${BASE_URL}/${pageSlug}"  
                }]
            }`
          }} /> 
      </Head>
      <PageBanner
        title={section?.title}
        subtitle={section?.excerpt}
          className="hide-shadow"
          goBackUrl="/" goBackName ="Home"
        />
      <div className="mainPortfolioPanel paddingT128">
        <div className="portfolioSection ">
          <div className="container">
            <div className="portfolioGlobalSection ">
              <div className="row">
          {
           cardsData?.map((singleSection: any, count: any) => {
             const title = singleSection?.title;
             const imagePosition = singleSection?.imagePosition;
             const twoColumn = singleSection?.flexibleColumns;
             const enableButton = singleSection?.enableButton;
             const cardsCollection = singleSection?.cardsCollection?.items;
             const additionalClass = twoColumn ? '' : 'portfolioFullWidth';
             const description = documentToPlainTextString(singleSection?.description?.json);
             const position = imagePosition ? "portfolioRowReverse" : "";
             return ( count % 3 == 0 || count % 3 == 3 ? <div className={`${additionalClass +' ' +position}`}>
                 <div className="portCol-4 " key={title}>
                   <div className="portfolioInfoPanel">
                    <h3>{title}</h3>
                     {parse(description)}
                       {enableButton && <p>{singleSection?.buttonText}</p>}
                    <ul className="default--list">
                      {cardsCollection?.map((singleCard: any, i: any) => {
                        const popupDescription = singleCard?.popupDescription;
                        return (<li key={i} onClick={toggle} data-enable-modal={singleCard?.enablePopup} modal-data={singleCard?.enablePopup ? `${popupDescription}`: ""}>{singleCard?.title}</li>
                        )
                      })
                      }
                     </ul>
                   </div>
                 </div>
                 <div className="portCol-8 ">
                   <div className="portfolioinnerPanel">
                   <div className="imagesPanel">
                     {singleSection?.image?.url && <ImageConversion
                       url={singleSection?.image?.url}
                       altext={singleSection?.image?.title}
                     />
                     }
                     </div>
                   </div>
                 </div>
               </div>  :  <div className="portCol-2 " key={title}>
                  <div className="portfolioinnerPanel  dFlex">
                    <div className="imagesPanel">
                      <div className="deskPortfolioImage">
                      {singleSection?.image?.url && <ImageConversion
                        url={singleSection?.image?.url}
                        altext={singleSection?.image?.title}
                      />
                     }
                      </div>
                    </div>
                  </div>
                  <div className="portfolioInfoPanel">
                    <h5>{title}</h5>
                   {parse(description)}
                   {enableButton && <p>{singleSection?.buttonText}</p>}
                    <ul className="default--list">
                     {cardsCollection?.map((singleCard: any, i: any) => {
                        const popupDescription = singleCard?.popupDescription
                       return ( <li key={i} onClick={toggle} data-enable-modal={singleCard?.enablePopup} modal-data={singleCard?.enablePopup ? `${popupDescription}` :""}>{singleCard?.title}</li>
                       )
                     })
                     }
                   </ul>
                  </div>
                </div>
                ) 
                })
                  }
                </div>
              </div>
            </div>
          </div>
        <section className="services-main-section pt-0 ">
            {
              bottomContactSection?.map((contact: any, count: any) => {
                return ( <div className="truAdsSolutions" key={count}>
                  <div className="teamContact teamContact-1 paddingY128 dark"><div className="teamContactWrap">
                    <div className="container">
                      <h5 className="teamContactContent " >
                        {parse(contact?.subTitle)}
                      </h5>
                    </div>
                    {contact?.enableButton &&
                      <Link className="globalButton withCircle  contact-cta" aria-label="Talk to an Expert" href= {contact?.buttonUrl ? contact?.buttonUrl :"#" } >
                        {contact?.buttonText}</Link>
                    }</div>
                  </div>
                </div>
                )

              })
            }
            <div className="services-page-cards  paddingB128">
            <div className="container">
                <div className="row">
                  {bottomServicePanel[0]?.cardsCollection?.items?.map((service: any, count: any) => {
                      return( <>
                        <div className="col-4" key={service.title} >
                          <div className="service-pages-card">
                            <div className="service-card-icon-outer">
                              <div className="service-card-icon">
                                {service?.enableImage &&
                                <ImageConversion
                                url={service?.cardImage?.url}
                                altext={service?.cardImage?.title}
                              /> }
                              </div>
                            </div>
                            <Link
                              href={service?.buttonUrl ? service.buttonUrl : "#" }
                              aria-label={service.title}
                              target="_self"
                            > <h4>{service.title}</h4></Link>
                            
                          </div>
                        </div>
                      </>)
                  })}
             </div>
            </div>
            </div>
          <div className="blueCircle">
            <Image src="/images/bottomGradient.png" fill priority alt="bottom gradient" />
          </div>
          </section>
               
        </div>
        <PortfolioModal showModal = { showModal } toggle = { toggleModal } modalData = { modalData } />
      </div>
    )
  })
};
export default Portfolio;
export async function getStaticProps(context: any) {
  const archivePortfolio = await getPortfolioPage();
  return {
    props: {
      archivePortfolio,
    },
    revalidate: 60
  };
}

