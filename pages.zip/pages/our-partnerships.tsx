
import { PageImageBanner, ServicesExternalTile } from "@/src/components";
import BlowSingleBanner from "@/src/templates/BlowSingleBanner";
import ServicesBlowPanel from "@/src/components/Services/BlowInnerPanel";
import OurPartnerPanel from "@/src/components/Services/OurPartner";
import Image from "next/image";
import SocialSlider from "@/src/components/SocialSlider";
import {PartnerShipPage} from "@/src/components/PartnershipCards";
import Link from "next/link";
import { getPartnershipPage } from "@/utils/contentful";
const ourPartner = "/images/our-partners.png";
const logo1 = "/images/Services/salesforce-logo.svg";
const salesforcelogosec = "/images/Services/salesforcelogosec.svg";
const blueCheck = "/images/blue-check.svg";
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
// const topBackgroundImage 
import parse from 'html-react-parser';
import ContactTeamPanel from "@/src/components/Services/ContactTeam";
import ServicesBottomPanel from "@/src/components/Services/ServicesBottomPanel";
import CardGrid from "@/src/components/Services/CardGrid";
import Slider from "react-slick";
import Head from 'next/head';
import dynamic from "next/dynamic";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || '';

const settings = {
  centerMode: true,
  dots: false,
  infinite: true,
  slidesToShow: 6,
  slidesToScroll: 1,
  autoplay: true,
  speed: 1000, 
  arrows: false,
  autoplaySpeed: 1000,
  centerPadding: "7vw",
  responsive: [
    {
      breakpoint: 1660,
      settings: {
        slidesToShow: 6,
      },
    },
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 4,
      },
    },
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 2,
        centerMode: true,
        centerPadding: "80px",
      },
    },
    {
      breakpoint: 575,
      settings: {
        slidesToShow: 1,
        centerMode: true,
        centerPadding: "80px",
      },
    },
  ],
};

const ourPartnership = (partner: any) => {
  const allData = partner?.partner?.homePageModelCollection?.items;
  return allData?.map((section: any, index: any) => {
    const allSections = section?.allSectionsCollection?.items;
    const metaTitle = section?.metaTitle;
    const metaDescription = section?.metaDescription;
    const pageSlug = section?.pageSlug;
    const metaIndex = section?.enableMetaIndex;
    const bannerData = allSections.filter((data: any) => {
      return data.tag === "topSectionImage";
    });
    const belowTopBanner = allSections.filter((data: any) => {
      return data?.tag === "belowBannerSection";
    });
    const partnerWithTitle = allSections.filter((data: any) => {
      return data?.tag === "partnerWithTitle";
    });
    const topContactSection = allSections.filter((data: any) => {
      return data?.tag === "topContactSection";
 });
    const cardGrid = allSections.filter((data: any) => {
      return data?.tag === "cardGrid";
    });
    const ServiceTiles = allSections.filter((data: any) => {
      return data?.tag === "ServiceTiles";
    });
    return (
      <>
        <Head>
          <title>{metaTitle ? metaTitle : "TRU AGENCY"}</title>
          {metaIndex && metaIndex != null ?
             <meta name="robots" content="index, follow" />
            :
             <meta name="robots" content="noindex, nofollow" />
          }
        <meta
          name="description"
          content={metaDescription ? metaDescription : "TRU AGENCY"}
          key="desc"
          />
          <link rel="canonical" href={`${BASE_URL}/${pageSlug}`} />
          <script type="application/ld+json" dangerouslySetInnerHTML={{
            __html: `{
                "@context": "https://schema.org/", 
                "@type": "BreadcrumbList",
                "name": "BreadcrumbList",
                "itemListElement": [{
                "@type": "ListItem", 
                "position": 1, 
                "name": "Home",
                "item": "${BASE_URL}"  
                },{
                "@type": "ListItem", 
                "position": 2, 
                "name": "${section?.title}",
                "item": "${BASE_URL}/${pageSlug}"  
                }]
            }`
          }} /> 
      </Head>  
        {
          bannerData.map((data: any,key:any) => {
            return (<PageImageBanner
              title={data?.title}
              key={key}
              subtitle=""
              bg={data?.image?.url}
              bgAlt={data?.image?.title}
              goBackUrl="/" goBackName ="Home"
            /> )
            }
           )
          }
        {
            belowTopBanner?.map((data: any, key: any) => {
                  return <BlowSingleBanner key={key}>
                      <ServicesBlowPanel
                            bannerHeading={data?.title}
                            bannerSubHeading={data?.subTitle}
                            bannerDescription={documentToPlainTextString(data?.description?.json)}
                      />
                  </BlowSingleBanner>
            })  
          }
          <div className="partner--main">
          <div className="blueCircle">
                <Image src="/images/bottomGradient.png" fill priority alt="bottom gradient" />
              </div>
            <div className="blue--gradient">
              <Image src="/images/blue-gradient-png.png" fill priority alt="blue-gradient" />
            </div>
        {
          partnerWithTitle?.map((data: any, key: any) => {
            const partnerData = data.cardsCollection.items;
                  return  <section className="brandPartnersSec paddingY128" key={key}>
                  <div className="container">
                    <div className="row">
                      <div className="col-12 col-12-sm ">
                        <h2 className="brandPartnersHeading">{parse(data?.title)}</h2>
                      </div>
                    </div>
                  </div>
                  <OurPartnerPanel>
                    <Slider {...settings} >
                        {partnerData.map((repeaterItem: any, key: any) => { 
                          return  <div key={key}>
                                    <div className="partnerSlickSlide partnerWithIcon">
                              <div className="partnerIcon">
                              <ImageConversion url={repeaterItem?.cardImage?.url} altext={repeaterItem?.cardImage?.title}/>
                                      </div>
                                    </div>
                                </div>
                        })
                        }
                    </Slider>
                  </OurPartnerPanel>
                </section>
            })  
          }
        {topContactSection.length > 0 ? <ServicesBottomPanel
                  teamContactDesc={topContactSection[0]?.subTitle}
                  ctaText={topContactSection[0]?.buttonText}
                  ctaUrl ={topContactSection[0]?.buttonUrl}
        /> : null
        }
    

    <div className="partnerShipBrandCards paddingY128">
      <div className="container">
            <div className="row">
              <div className="col-12">
              {cardGrid?.map((card: any, key: any) => {
                const index = key + 1;
                let data: any = [];
                let position = true;
                  if (card?.imagePosition) {
                    position = false;    
                  }
                  else {
                    position = true
                  }
                  const tagLine = card?.tagLine;
                  const enableButton = card?.enableButton;
                  const buttonText = card?.buttonText;
                  const buttonUrl = card?.buttonUrl;
                  const enable = card?.enableTagline;
                  const flexColumns = card?.flexibleColumns
                 card?.cardsCollection?.items?.map((singleCard: any, key: any) => {
                                   data.push({title:singleCard?.title,desc:documentToPlainTextString(singleCard?.description?.json),titleShow :singleCard?.showTitle})
                              })
                              let childrenDataTwo = {
                                title: card?.title,
                                imageUrl : card?.image?.url,
                                imageAlt : card?.image?.title,
                                desc: documentToPlainTextString(card?.description?.json),
                                enableButton: enableButton,
                                buttonText: buttonText,
                                buttonUrl: buttonUrl,
                                data
                              };
                
                return <PartnerShipPage
                  key={key}
                  reverse={position}
                  // flexibleCol={flexColumns}
                  bottomTagLine={enable}
                  tagline={tagLine}
                  cardData={childrenDataTwo}
                />
              })
              }
              </div>
            </div>  
          </div> 
        </div>
        {ServiceTiles.length > 0 ? 
      <ServicesExternalTile CardsData={ServiceTiles[0]?.cardsCollection?.items} />
  : null}
  
          </div>

             
      </>
    )
  })

}

export default ourPartnership;

export async function getStaticProps(context: any) {
  const partner = await getPartnershipPage();
  return {
    props: {
      partner,
    },
    revalidate: 60
  };
}
