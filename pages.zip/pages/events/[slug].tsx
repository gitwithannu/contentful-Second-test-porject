import { PageImageBanner, AccordionWrapper, Accordion, AccordionHeader, AccordionPanel } from "@/src/components";
import ContactSection from "@/src/components/Blog/ContactSection";
import { getAllEvent, getEntry, getSingleEvent } from "@/utils/contentful";
import Head from "next/head";
import Image from "next/image";
import { documentToReactComponents } from '@contentful/rich-text-react-renderer';
import { BLOCKS, INLINES } from '@contentful/rich-text-types';
import parse from 'html-react-parser';
import dynamic from "next/dynamic";
import YouTubeVideo from "@/src/components/YoutubeVideo";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'));
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || '';
const EventsSingle = (props: any) => {
const singleEvent = props?.singleEvent?.singleEventCollection?.items[0];
const pageTitle = singleEvent?.postTitle;
const metaTitle = singleEvent?.metaTitle;
const metaIndex = singleEvent?.enableMetaIndex;
const metaDescription = singleEvent?.metaDescription;
const enabelFeaturedImage = singleEvent?.enableFeaturedImage;
const linkedEntries = singleEvent?.description?.links?.entries?.block;
const linkedAssets = singleEvent?.description?.links?.assets?.block;
const startDate = formatDateFromISOString(singleEvent?.eventFrom);
const startDay = startDate?.day;
const starmonth = startDate?.month;
const endDate = formatDateFromISOString(singleEvent?.eventTo);
const endDay = endDate?.day;
const year = endDate?.year;
const dispalyDay = startDay === endDay ? startDay : `${startDay}-${endDay}`;
const isHtmlTag = (text:any) => /<\/?[a-z][\s\S]*>/i.test(text);
    function formatDateFromISOString(ISOString:any) {
        const date = new Date(ISOString);
        const year = date.getFullYear();
        const monthIndex = date.getMonth();
        const monthNames = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
          ];
        const month = monthNames[monthIndex];
        const day = String(date.getDate()).padStart(2, '0');
        return {
              day,
              month,
              year
            };
    }
    const authorDetails = [
        {
            EventDatetime: `${starmonth} ${dispalyDay}, ${year}`,
            place: `${singleEvent.location}`
        }
    ];
    return (
        <>
            <div className={`serviceDetails blogSinglePost blogWithoutImg eventsSinglePage`}>
            <Head>
                <title>{metaTitle ? metaTitle : "TRU AGENCY"}</title>
                {metaIndex && metaIndex != null ?
                    <meta name="robots" content="index, follow" />
                    :
                    <meta name="robots" content="noindex, nofollow" />
                }
                <meta
                name="description"
                content={metaDescription ? metaDescription : "TRU AGENCY"}
                key="desc"
                />
                <link rel="canonical" href={`${BASE_URL}/blogs/${singleEvent?.slug}`} />
                <meta property="og:image" content={singleEvent?.archiveSocialImage?.url} />
                <meta property="og:image:width" content="1600" />
                <meta property="og:image:height" content="400" />
                <script type="application/ld+json" dangerouslySetInnerHTML={{
                __html: `{
                      "@context": "https://schema.org/", 
                      "@type": "BreadcrumbList",
                      "name": "BreadcrumbList",
                      "itemListElement": [{
                        "@type": "ListItem", 
                        "position": 1, 
                        "name": "Home",
                        "item": "${BASE_URL}"  
                      },{
                        "@type": "ListItem", 
                        "position": 2, 
                        "name": "Events",
                        "item": "${BASE_URL}/events"  
                      },
                      {
                        "@type": "ListItem", 
                        "position": 3, 
                        "name": "${singleEvent?.postTitle}",
                        "item": "${BASE_URL}/events/${singleEvent?.slug}"  
                      }]
                    }`
                }} />  
                </Head>  
                <PageImageBanner
                    key={`events-index`}
                    title={pageTitle}
                    postDesc={true}
                    enablefeaturedImage={false}
                    goBackUrl="/events/"
                    goBackName="events"
                    authorDetails={JSON.stringify(authorDetails)}
                />
                <section className={`blogPageSingleMain paddingY128 eventsBlogs`}>
                    <div className="container">
                        <div className="row">
                            <div className="col-12">
                                <div className="width-1111">
                                    {singleEvent?.enableFeaturedImage && singleEvent?.featuredImage?.url && <div className="singleEventImage">
                                        <Image src={singleEvent?.featuredImage?.url} alt={singleEvent?.featuredImage?.title} width={500} height={300} />
                                    </div>
                                    }
                                    <div className="width-857 eventDetail">
                                        {documentToReactComponents(singleEvent?.description?.json, {
                                            renderNode: {
                                                [BLOCKS.EMBEDDED_ENTRY]: (node:any, children:any) => {
                                                    const entryId = node.data.target.sys.id;
                                                    const entry = linkedEntries.find((entry: any) => entry.sys.id === entryId);
                                                    if (entry && entry.__typename === 'Headingsubheadingdescription' && entry.tag === "blogContact") {
                                                        return (
                                                            <ContactSection
                                                                teamContactDesc={entry?.subTitle}
                                                                enableCta={entry?.enableButton}
                                                                ctaText={entry?.buttonText}
                                                                ctaUrl={entry?.buttonUrl}
                                                            />
                                                        );
                                                    }
                                                    if (entry && entry?.tag === "blogQuote") {
                                                        return (
                                                            <blockquote className="blogQuote">
                                                                <div className="blogQuoteIcon">
                                                                    <Image
                                                                      alt="quote icon"
                                                                      src="/images/quote-icon.svg"
                                                                      width="60"
                                                                      height="32"
                                                                      decoding="async"
                                                                      data-nimg="1"
                                                                      loading="lazy"
                                                                    />
                                                                </div>
                                                                {parse(entry?.subTitle)}
                                                            </blockquote>
                                                        );
                                                    }
                                                    if (entry && entry?.tag === "blogQuoteBorder") {
                                                        return (
                                                            <blockquote className="blogQuote blogQuoteborder">
                                                                <div className="blogQuoteIcon">
                                                                    <Image
                                                                      alt="quote icon"
                                                                      src="/images/quote-icon.svg"
                                                                      width="60"
                                                                      height="32"
                                                                      decoding="async"
                                                                      data-nimg="1"
                                                                      loading="lazy"
                                                                    />
                                                                </div>
                                                                {parse(entry?.subTitle)}
                                                            </blockquote>
                                                        );
                                                    }
                                                    if (entry && entry.tag === "blogFaqSection") {
                                                        return (
                                                          <div className="container blogFaQ">
                                                              <div className="faq">
                                                                  <div className="faq_title">
                                                                      <h3>{entry?.heading}</h3>
                                                                  </div>
                                                                  <AccordionWrapper>
                                                                  {
                                                                  entry?.accordions?.map((accordion: any, key: any) => {
                                                                    return (
                                                                        <Accordion key={key} customIndex={key}>
                                                                        <AccordionHeader>{accordion?.key}</AccordionHeader>
                                                                          <AccordionPanel>
                                                                          <p>{parse(accordion?.value)}</p>
                                                                          </AccordionPanel>
                                                                        </Accordion>
                                                                    )
                                                                  })
                                                                  }
                                                                </AccordionWrapper>
                                                              </div>
                                                           </div>
                                                        );
                                                    }
                                                    if (entry && entry?.tag === "imageWithDescription") {
                                                        return (
                                                          <div className="singleImage imageWithDescriptionSingle">
                                                              {entry?.title && <h3 className="imageInfoBlockTitle">{entry?.title}</h3>}
                                                              <div className="imageInfoTopText">{parse(entry?.subTitle)}</div>
                                                              <ImageConversion
                                                                  url={entry?.featureImage?.url}
                                                                  altext={entry?.featureImage?.title}
                                                              />
                                                              {entry?.featureImage?.description && 
                                                                  <div className="img-src-text">
                                                                      {parse(entry?.featureImage?.description)}
                                                                  </div>
                                                              }
                                                              {entry?.description?.json && 
                                                                  <div className="imageInfoBottomText">
                                                                      {parse(documentToPlainTextString(entry?.description?.json))} 
                                                                  </div>
                                                              }
                                                        </div>
                                                        )
                                                    }
                                                    if (entry && entry.__typename == 'Headingsubheadingdescription' && entry.tag == null) {
                                                        return (<>
                                                          {entry?.subTitle &&  <div className="imageInfoTopText">{parse(entry?.subTitle)}</div> }
                                                          </>
                                                        );
                                                    }
                                                    if(entry && entry.__typename == 'Headingsubheadingdescription' && entry?.tag == "blogVideo"){
                                                      return (
                                                        <div className="cardImageLeft">
                                                        <YouTubeVideo src={entry?.subTitle} title={entry?.title} />
                                                        <div className="img-src-text">{parse(documentToPlainTextString(entry?.description?.json))}</div>
                                                        </div>
                                                        )
                                                    }

                                                    return null;
                                                },
                                                [BLOCKS.PARAGRAPH]: (node: any, children: any) => {
                                                    let containsHtml = false;
                                                    let newChildren = children;
                                                    let paragraphContent = '';
                                                    node.content.forEach((childNode:any) => {
                                                      if (childNode.nodeType === 'text' && isHtmlTag(childNode.value)) {
                                                        containsHtml = true;
                                                      }
                                                      paragraphContent += childNode.value;
                                                    });
                                                    if (containsHtml) {
                                                      return <p>{parse(paragraphContent)}</p>;
                                                    }
                                                    return <p>{newChildren}</p>;
                                                  },
                                                [BLOCKS.EMBEDDED_ASSET]: (node:any, children:any) => {
                                                    const assetId = node.data.target.sys.id;
                                                    const asset = linkedAssets?.find((asset: any) => asset.sys.id === assetId);
                                                    if (asset && asset.__typename === 'Asset' ) {
                                                        return <div className="singleImage imageWithDescriptionSingle">
                                                            <ImageConversion url={asset?.url} altext={asset?.title} />
                                                            {asset?.description && <div className="img-src-text">{parse(asset?.description)}</div>}
                                                          </div>
                                                    }
                                                    return null;
                                                },
                                            } })}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

            </div>
        </>
    );
}
export default EventsSingle;
export async function getStaticProps(context: any) {
    const slug = context.params.slug;
    const singleEvent = await getSingleEvent(slug);
    const results = singleEvent?.singleEventCollection?.items;
    if(!results || results.length === 0) {
      return {
        notFound: true,
      };
    }
    return {
      props: {
        singleEvent,
      },
      revalidate: 60
    };
  }
  export async function getStaticPaths() {
    const singlePost = await getAllEvent();
    const paths = singlePost?.singleEventCollection?.items?.map((post:any) => ({
      params: { slug: post.slug },
    }))
    return { paths, fallback: 'blocking' }
  }  