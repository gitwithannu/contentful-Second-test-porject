import Link from "next/link";
import { PageBanner, PageImageBanner } from "@/src/components";
import { getEventPage, getAllEvents } from "@/utils/contentful";
import Head from "next/head";
import dynamic from "next/dynamic";
import parse from 'html-react-parser';
import Image from "next/image";
import { useEffect, useState } from "react";
import { documentToReactComponents } from '@contentful/rich-text-react-renderer';
import { BLOCKS, INLINES } from '@contentful/rich-text-types';
const ImageConversion = dynamic(
    () => import("@/src/components/ImageConversion/ImageConversion")
);
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || "";

const Events = (props: any) => {
    const [pastEventsFilter, setPastEventsFilter] = useState<any[]>([]);
    const [upcomingEventsFilter, setUpcomingEventsFilter] = useState<any[]>([]);
    const [pastTotalFilter, setPastTotalFilter] = useState<number>(0);
    const [upcomiongTotalFilter, setUpcomingTotalFilter] = useState<number>(0);
    const [loading, setLoading] = useState(false);
    const [loadData, setLoadData] = useState<string>();
    const [pastskip, setPastSkip] = useState(6);
    const [upComingSkip, setupComingSkip] = useState(6);

    const allData = props?.eventPage?.homePageModelCollection?.items;
    const upcomingEvents = props?.UpcomingEvents?.singleEventCollection?.items;
    const upcomingTotal = props?.UpcomingEvents?.singleEventCollection?.total;
    const pastEvents = props?.pastEvents?.singleEventCollection?.items;
    const pastTotal = props?.pastEvents?.singleEventCollection?.total;
    const isHtmlTag = (text:any) => /<\/?[a-z][\s\S]*>/i.test(text);
    function formatDateFromISOString(ISOString: any) {
        const date = new Date(ISOString);
        const year = date.getFullYear();
        const monthIndex = date.getMonth();
        const monthNames = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ];
        const month = monthNames[monthIndex];
        const day = String(date.getDate()).padStart(2, '0');
        return {
            day,
            month,
            year
        };
    }

    const searchInputChange = async (e: any) => {
        setLoading(true);
        const searchInput = e.target.value;
        try {
            setLoadData(searchInput)
            const req = await getAllEvents(false, true, searchInput, 6, 0);
            setPastTotalFilter(req?.singleEventCollection?.total);
            setPastEventsFilter(req?.singleEventCollection?.items);
            setPastSkip(6);
        } catch (error) {
            console.error('Error fetching posts:', error);
        } finally {
            setLoading(false);
        }
    }

    const loadMorePosts = async () => {
        const limit = 6; // Number of posts to load
        let searchVal = ''
        if (loadData !== '' && loadData !== undefined) {
            searchVal = loadData
        }
        try {
            console.log(pastskip,'passkiop')
            const req = await getAllEvents(false, true, searchVal, limit, pastskip);
            setPastEventsFilter((prevPosts) => [...prevPosts, ...req?.singleEventCollection?.items]);
            setPastTotalFilter(req?.singleEventCollection?.items);
            setPastSkip(pastskip + limit);
        } catch (error) {
            console.error("Error loading more posts:", error);
        } finally {
            console.log(pastskip + limit);
        }
    };
    const upcomingLoadMorePosts = async () => {
        const limit = 6; // Number of posts to load
        try {
            const req = await getAllEvents(true, false, '', limit, upComingSkip);
            setUpcomingEventsFilter((prevPosts) => [...prevPosts, ...req?.singleEventCollection?.items]);
            setupComingSkip(upComingSkip + limit);
        } catch (error) {
            console.error("Error loading more posts:", error);
        } finally {
            console.log(upComingSkip + limit);
        }
    };

    useEffect(() => {
        setLoading(true);
        setPastTotalFilter(pastTotal);
        setUpcomingTotalFilter(upcomingTotal)
        setUpcomingEventsFilter(upcomingEvents)
        setPastEventsFilter(pastEvents);
        setLoading(false);
    }, []);

    const filtered = allData?.filter((singleData: any) => {
        return singleData?.pageSlug === "events";
    });

    return filtered?.map((section: any, index: any) => {
        const metaTitle = section?.metaTitle;
        const metaDescription = section?.metaDescription;
        const metaIndex = section?.enableMetaIndex;
        const allSections = section?.allSectionsCollection?.items;
        const pageSlug = section?.pageSlug;
        const upcomingData = allSections.filter((data: any) => {
            return data.tag === "upcoming";
        });
        const pastData = allSections.filter((data: any) => {
            return data.tag === "past";
        });
        const pastTotal = props?.pastEvents?.singleEventCollection?.total;

        return (
            <div className="events" key={index}>
                <Head>
                    <title>{metaTitle ? metaTitle : "TRU AGENCY"}</title>
                    {metaIndex && metaIndex != null ?
                        <meta name="robots" content="index, follow" />
                        :
                        <meta name="robots" content="noindex, nofollow" />
                    }
                    <meta
                        name="description"
                        content={metaDescription ? metaDescription : "TRU AGENCY"}
                        key="desc"
                    />
                    <link rel="canonical" href={`${BASE_URL}`} />
                    <script type="application/ld+json" dangerouslySetInnerHTML={{
                        __html: `{
                            "@context": "https://schema.org/",
                            "@type": "BreadcrumbList",
                            "name": "BreadcrumbList",
                            "itemListElement": [{
                                "@type": "ListItem",
                                "position": 1,
                                "name": "Home",
                                "item": "${BASE_URL}"
                            }]
                        }`
                    }} />
                </Head>
                <PageBanner
                    title={section?.title}
                    subtitle={section?.subtitle}
                    className="hide-shadow"
                    rowClass="m0"
                    goBackUrl="/"
                    goBackName="Home"
                />
                <section className="blogsPin">
                    <section className="latestestStudioMain Blog">
                        <div className="container latestStudioInner">
                            <div className="row b-filter-tab-row">
                                <div className="col-12 mainTitleWrapper" style={{ borderBottom: "1px solid #ddd", marginBottom: "64px" }}>
                                    {upcomingData[0]?.title && <h2 className="mainTitle">{upcomingData[0]?.title}</h2>}
                                    {upcomingData[0]?.subTitle && <p className="mainBannerSubheading">{parse(upcomingData[0]?.subTitle)}</p>}
                                    <div className="row event-upcoming-col">
                                    {
                                        props?.UpcomingEvents?.singleEventCollection.total > 0 ? upcomingEventsFilter?.map((event: any, key: any) => {
                                            const startDate = formatDateFromISOString(event?.eventFrom);
                                            const startDay = startDate?.day;
                                            const starmonth = startDate?.month;
                                            const endDate = formatDateFromISOString(event?.eventTo);
                                            const endDay = endDate?.day;
                                            const year = endDate?.year;
                                            const dispalyDay = startDay === endDay ? startDay : `${startDay}-${endDay}`;
                                            return (<div className="col-4 col-12-sm boxes" key={key}>
                                                <div className="newsPanel blog-1">
                                                    <div className="newsHeader">
                                                        <Link href={"/events/" + event?.slug}>
                                                            <h4>{event?.postTitle}</h4>
                                                        </Link>
                                                    </div>
                                                    <div className="newsBody">
                                                    <div className="newsNav">
                                                        <ul className="eventCardInfo">
                                                        <li>{starmonth + ' ' + dispalyDay + ', ' + year}</li>
                                                        <li>{event?.location}</li>
                                                        </ul>
                                                    </div>
                                                    <div className="newsImagePanel">
                                                        <Link href={"/events/"+event?.slug}>  
                                                            <ImageConversion
                                                                url={event?.archiveSocialImage?.url ? event?.archiveSocialImage?.url :'/images/blog/placeholder-desktop.png'  }
                                                                altext={event?.archiveSocialImage?.title ? event?.archiveSocialImage?.title :"Picture of Latest Post"}
                                                            />
                                                        </Link>
                                                        </div>
                                                        </div>
                                                </div>
                                            </div>)
                                        }) :  props?.UpcomingEvents?.singleEventCollection.total === 0 && upcomingData[0]?.description?.json ? (
                                            <div className="col-12-sm">
                                                <div className="no-result-found ">
                                                        <ImageConversion
                                                        height={100} width={100}
                                                        url={upcomingData[0]?.featureImage?.url ? upcomingData[0]?.featureImage?.url :'/images/no-result-found.svg'  }
                                                        altext={upcomingData[0]?.featureImage?.title ?upcomingData[0]?.featureImage?.title :"Picture of upcoming events"}
                                                    />
                                                    <span className="b-filter-noresult">
                                                    {documentToReactComponents(upcomingData[0]?.description?.json, {
                                                        renderNode: {
                                                            [BLOCKS.PARAGRAPH]: (node: any, children: any) => {
                                                                let containsHtml = false;
                                                                let newChildren = children;
                                                                let paragraphContent = '';
                                                                node.content.forEach((childNode: any) => {
                                                                    if (childNode.nodeType === 'text' && isHtmlTag(childNode.value)) {
                                                                        containsHtml = true;
                                                                    }
                                                                    paragraphContent += childNode.value;
                                                                });
                                                                if (containsHtml) {
                                                                    return <p>{parse(paragraphContent)}</p>;
                                                                }
                                                                return <p>{newChildren}</p>;
                                                            },
                                                        }
                                                     })
                                                    } 
                                                    </span>
                                                </div>
                                            </div>
                                        ) : (
                                            <div className="col-12-sm">
                                               <div className="no-result-found ">
                                                    <Image 
                                                        src={'/images/no-result-found.svg'}
                                                        alt={`No Result found`}
                                                        width={100}
                                                        height={100} 
                                                    />
                                                    <span className="b-filter-noresult">
                                                        No result found
                                                    </span>
                                                </div>
                                            </div>
                                        )
                                        }

                                    {upcomingEventsFilter.length < upcomiongTotalFilter ? (
                                        <div className="col-12-sm">
                                            <div className="button loadMore">
                                                <button
                                                    className="globalButton"
                                                    aria-label="Click here to load more items"
                                                    onClick={upcomingLoadMorePosts}
                                                >
                                                    Load More
                                                </button>
                                            </div>
                                        </div>
                                    ) : (
                                        ``
                                    )}         
                                </div>
                                </div>
                                <div className="col-12 mainTitleWrapper">
                                    {pastData[0]?.title && <h2 className="mainTitle">{pastData[0]?.title}</h2>}
                                    {pastData[0]?.subTitle && <p className="mainBannerSubheading">{parse(pastData[0]?.subTitle)}</p>}
                                </div>
                              
                            </div>
                            <div className="blog-filter-col row">
                                  
                                    <div className="col-4 col-12-sm ">
                                    <div className="b-fiter-search-col ">
                                        <input
                                            name="blog-search"
                                            type="text"
                                            placeholder="Search..."
                                            className="b-fiter-search-box"
                                            onChange={searchInputChange}
                                        />
                                        <button className="searchButton">
                                            <span className="icon-search-1"></span>
                                        </button>
                                        </div>
                                        </div>
                                </div>
                        
                            <div className="row rightPanel paddingT64">
                                {loading ?
                                    <div className="loading-job-list paddingY128">
                                        <Image src="/images/icons/loading.svg" alt="loading-image" width="200" height="200" />
                                    </div>
                                    :
                                    pastTotal > 0 && pastEventsFilter?.map((event: any, key: any) => {
                                        const startDate = formatDateFromISOString(event?.eventFrom);
                                        const startDay = startDate?.day;
                                        const starmonth = startDate?.month;
                                        const endDate = formatDateFromISOString(event?.eventTo);
                                        const endDay = endDate?.day;
                                        const year = endDate?.year;
                                        const dispalyDay = startDay === endDay ? startDay : `${startDay}-${endDay}`;
                                        
                                        return <div className="col-4 col-12-sm boxes" key={key}>
                                            <div className="newsPanel blog-1">
                                                <div className="newsHeader">
                                                    <Link href={"/events/" + event?.slug}>
                                                        <h4>{event?.postTitle}</h4>
                                                    </Link>
                                                </div>
                                                <div className="newsBody">
                                                    <div className="newsNav">
                                                        <ul className="eventCardInfo">
                                                            <li>{starmonth + ' ' + dispalyDay + ', ' + year}</li>
                                                            <li>{event?.location}</li>
                                                        </ul>
                                                    </div>
                                                    <div className="newsImagePanel">
                                                    <Link href={"/events/"+event?.slug}>   
                                                      <ImageConversion
                                                            url={event?.archiveSocialImage?.url ? event?.archiveSocialImage?.url :'/images/blog/placeholder-desktop.png'  }
                                                            altext={event?.archiveSocialImage?.title ? event?.archiveSocialImage?.title :"Picture of Latest Post"}
                                                        />
                                                        </Link>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    }
                                    ) 
                                }

                                { pastTotalFilter == 0? (
                                    <div className="col-12-sm">
                                        <div className="no-result-found ">
                                            <Image src={'/images/no-result-found.svg'}
                                                alt={`No Result found`}
                                                width={100}
                                                height={100} />
                                            <span className="b-filter-noresult">
                                                No result found
                                            </span>
                                        </div>
                                    </div>
                                ) : null
                                }
                            

                            {pastEventsFilter.length < pastTotalFilter ? (
                                            <div className="col-12-sm">
                                                <div className="button loadMore">
                                                    <button
                                                        className="globalButton"
                                                        aria-label="Click here to load more items"
                                                        onClick={loadMorePosts}

                                                    >
                                                        Load More
                                                    </button>
                                                </div>
                                            </div>
                                        ) : (
                                            ``
                                            )}

                             
                            </div>
                        </div>
                    </section>
                </section>
                {/* <!--Blogs end Here--> */}
            </div>
        );
    })
};
export default Events;

export async function getStaticProps(context: any) {
    const eventPage = await getEventPage();
    const UpcomingEvents = await getAllEvents(true, false);
    const pastEvents = await getAllEvents(false, false);
    return {
        props: {
            eventPage,
            UpcomingEvents,
            pastEvents
        },
        revalidate: 60,
    };
}
