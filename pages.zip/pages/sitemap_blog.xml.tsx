import { GetServerSideProps } from 'next';
import { getBlogPages } from './api/blogListapi';

const BASE_URL = process.env.SITE_URL || '';

const Sitemap = () => {
  return null;
};

export const getServerSideProps: GetServerSideProps = async ({ res }) => {
  const siteUrl = BASE_URL;

  try {
    const [bloglist] = await Promise.all([
        getBlogPages()
    ]);

    const blogURL = bloglist?.blogPostsCollection?.items;
    
    const bloglisturl = blogURL?.map((itemUrl: { slug: string }) => `${siteUrl}/blogs/${itemUrl?.slug}`);
    const allData = [...bloglisturl];
    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
      <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
        ${allData
          .map((url) => {
            return `
              <url>
                <loc>${url}</loc>
                <lastmod>${new Date().toISOString()}</lastmod>
                <changefreq>monthly</changefreq>
                <priority>1.0</priority>
              </url>
            `;
          })
          .join('')}
      </urlset>`;

    res.setHeader('Content-Type', 'text/xml');
    res.write(sitemap);
    res.end();

    return {
      props: {},
    };
  } catch (error) {
    console.error('Error generating sitemap:', error);
    //res.status(500).send('Error generating sitemap');
    return {
      props: {},
    };
  }
};

export default Sitemap;
