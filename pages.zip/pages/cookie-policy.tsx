import { PageBanner } from "@/src/components";
import { getcookiePolicyPage } from "@/utils/contentful";
import { documentToPlainTextString } from "@contentful/rich-text-plain-text-renderer";
import Link from 'next/link'
import parse from 'html-react-parser';
import Head from 'next/head';
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || '';

const CokkiePolicy = ({ cookie }: any) => {
     const sectionData = cookie?.homePageModelCollection?.items;
     return sectionData?.map((section: any, index: any) => {
        const metaTitle = section?.metaTitle;
         const metaDescription = section?.metaDescription;
         const metaIndex = section?.enableMetaIndex;
        const pageSlug = section?.pageSlug;
         const allSections = section?.allSectionsCollection?.items
         const pageContent = allSections.filter((data: any) => {
             return data.tag === "pageContent";
           });
         return (
             <div key={index} className="cookiePolicyPage">
                 <Head>
                     <title>{metaTitle ? metaTitle : "TRU AGENCY"}</title>
                     {metaIndex && metaIndex != null ?
                        <meta name="robots" content="index, follow" />
                        :
                        <meta name="robots" content="noindex, nofollow" />
                    }
                    <meta
                    name="description"
                    content={metaDescription ? metaDescription : "TRU AGENCY"}
                    key="desc"
                     />
                     <link rel="canonical" href={`${BASE_URL}/${pageSlug}`} />
                     <script type="application/ld+json" dangerouslySetInnerHTML={{
                        __html: `{
                            "@context": "https://schema.org/", 
                            "@type": "BreadcrumbList",
                            "name": "BreadcrumbList",
                            "itemListElement": [{
                            "@type": "ListItem", 
                            "position": 1, 
                            "name": "Home",
                            "item": "${BASE_URL}"  
                            },{
                            "@type": "ListItem", 
                            "position": 2, 
                            "name": "${section?.title}",
                            "item": "${BASE_URL}/${pageSlug}"  
                            }]
                        }`
                     }} /> 
                     
                </Head> 
                 <PageBanner
                     title={section.title}
                     className="hide-shadow"
                 />
                 {pageContent?.map((content: any, key: any) => {
                    const description =  documentToPlainTextString(content?.description?.json)
                   
                   return  <div className="default-content" key={key}>
                         <div className="container">
                             <div className="row">
                                 <div className="col-12">
                                 {description ? parse(description) :""}
                                 </div>
                             </div>
                         </div>
                     </div>
                 })
                 }
             </div>
         )
     })
}
export default CokkiePolicy;

export async function getStaticProps(context: any) {
    const cookie = await getcookiePolicyPage();
    return {
      props: {
        cookie,
        },
      revalidate: 60
    };
}
  