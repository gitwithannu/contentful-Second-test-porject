// DynamicComponent.d.ts
declare module '*.js' {
   const value: React.ComponentType<any>;
   export default value;
 }
 