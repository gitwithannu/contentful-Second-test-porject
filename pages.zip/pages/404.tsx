import { PageBanner } from "@/src/components";
import Head from "next/head";
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || '';
const NotFoundPage = () => {
  return (
    <div className="notFoundPanel">
       <Head>
        <title>{`404 Page | TRU`}</title>
        <meta name="robots" content="noindex, nofollow" />
        <meta
          name="description"
          content={`The 404 error indicates that the origin server did not find a current representation for the target resource or is not willing to reveal that it exists.`}
          key="desc"
        />
        <link rel="canonical" href={`${BASE_URL}/404`} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{
          __html: `{
            "@context": "https://schema.org/", 
            "@type": "BreadcrumbList",
            "name": "BreadcrumbList",
            "itemListElement": [{
              "@type": "ListItem", 
              "position": 1, 
              "name": "Home",
              "item": "${BASE_URL}"  
            },{
              "@type": "ListItem", 
              "position": 2, 
              "name": "Not Found",
              "item": "${BASE_URL}/404"  
            }]
          }`
          }} />  
      </Head> 
      <PageBanner
        title="404"
        mainTitle="Page Not Found"
        subtitle="The page you were trying to visit has been relocated or does not exist. Please visit our home page or use the search tool above to find the page you are looking for."
        className="blogPageHeader"
        buttonCta="Go to home"
        goBackName="Home"
        goBackUrl ="/"
        buttonURL="/"
      />
    </div>
  );
};

export default NotFoundPage;
