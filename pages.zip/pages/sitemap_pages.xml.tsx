import fs from 'fs';
import { GetServerSideProps } from 'next';

const BASE_URL = process.env.SITE_URL || '';

const staticPaths = fs
  .readdirSync('pages')
  .filter((staticPage) => {
    return ![
      'api',
      '_app.tsx',
      '_document.tsx',
      'careers.tsx',
      'careers',
      'career',
      'menu',
      'test.tsx',
      'types',
      'not-found.tsx',
      'home-v2.tsx',
      'home-v3.tsx',
      'blog-detail',
      'sitemap_index.xml.tsx',
      'sitemap_pages.xml.tsx',
      'Layout.tsx',
      '.DS_Store',
      'noresultfound.tsx',
      '404.tsx',
      'sitemap_blog.xml.tsx',
      'sitemap_services.xml.tsx',
    ].includes(staticPage);
  })
  .map((staticPagePath) => {
    const path = staticPagePath.replace('.tsx', '');
    return path === 'index' ? `${BASE_URL}/` : `${BASE_URL}/${path}`;
  });

const Sitemap = () => {
  return null;
};

const AllpagePath = [`${BASE_URL}/`, ...staticPaths.filter(path => path !== `${BASE_URL}/`)];


const generateSitemap = (urls: string[]): string => {
  return `<?xml version="1.0" encoding="UTF-8"?>
    <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
      ${urls
        .map((url) => {
          return `
            <url>
              <loc>${url}</loc>
              <lastmod>${new Date().toISOString()}</lastmod>
              <changefreq>monthly</changefreq>
              <priority>1.0</priority>
            </url>
          `;
        })
        .join('')}
    </urlset>`;
};

export const getServerSideProps: GetServerSideProps = async ({ res }) => {
  const sitemap = generateSitemap(AllpagePath);
  
  res.setHeader('Content-Type', 'text/xml');
  res.write(sitemap);
  res.end();

  return {
    props: {},
  };
};

export default Sitemap;
