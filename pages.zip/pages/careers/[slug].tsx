import { PageImageBannerNew } from "@/src/components";
import Link from "next/link";
import { getSingleJobPostings, getJobPostings } from "@/utils/contentful";
import parse from "html-react-parser";
import { documentToHtmlString } from '@contentful/rich-text-html-renderer';
import React, { useState } from 'react';
import Scrollbar from 'smooth-scrollbar';
import SmoothScrollbar from 'smooth-scrollbar';


// import Head from 'next/head';
import { Form } from "@/src/components";
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || '';
const JobDetail = (singleJob: any) => {
    const singleJobDta = singleJob?.singleJob?.jobPostingCollection?.items;
    const [showJobDetail, setshowJobDetail] = useState(true);
    const [showForm, setshowForm] = useState(false);
    const handleChildClick = (data:any) => {
        setshowForm(data);
        setshowJobDetail(false);
    };
    const handleIntrested = (e:any) => {
        e.preventDefault();
        setshowForm(true);
        setshowJobDetail(false);
        scrollToBottom()
    };
    
    const scrollToBottom = () => {
        const containerElement = document.getElementsByClassName('scroller')[0] as HTMLElement;
        const scrollbar = SmoothScrollbar.init(containerElement);
        scrollbar.scrollTo(100, 700, 500); 
    }
    
    const closeClick = (data:any) => {
        setshowForm(false);
        setshowJobDetail(data);
    };
    
    return (
        <>
        {
                singleJobDta?.map((data: any, index: any) => {
                    const aboutUs = documentToHtmlString(data?.aboutUs?.json);
                    const jobDescription = documentToHtmlString(data?.jobDescription?.json);
                    const jobRequirement = documentToHtmlString(data?.requirements?.json);
                    const jobTitle = data?.jobTitle ? data?.jobTitle :"Job Title";
                    const Subtitle = data?.jobType;
                    const publishedDate = data?.sys?.firstPublishedAt;
                    let date = new Date(publishedDate);
                    var year = date.getFullYear();
                    var month = (date.getMonth() + 1).toString().padStart(2, '0'); // Adding 1, converting to string, and padding with zero
                    var dateVal = date.getDate();
                    const jobLocation = data?.jobCity + data?.province + data?.country;
                    return <div className="job-detail" key={index}>
                        <PageImageBannerNew title={jobTitle} subtitle={`${data?.jobCity ? data?.jobCity + ',' : ""}  ${data?.province ? data?.province + ',' : ""} ${data?.country ? data?.country : ""} | Posted on ${dateVal}/${month}/${year}`}
                            goBackUrl="/careers" goBackText="Go Back Careers"
                            customClass="job-detail-header"
                            jobApplicationUrl='#'
                            jobApplicationText="I'm interested"
                            jobReferText="Refer a friend"
                            jobReferUrl={`mailto:?subject=${jobTitle}&body=${jobTitle}`}
                            onChildClick={handleChildClick}
                        />
                        {showJobDetail &&
                            <div className="job-detail--inner paddingT128 paddingB128">
                                <div className="container">
                                    <div className="col-11">
                                        <div className="row">
                                            <div className="col-8">
                                                <h4 className="job-content-heading"> About us</h4>
                                                <div className="job-description"> {parse(aboutUs)} </div>
                                                <h4 className="job-content-heading">Job Description</h4>
                                                <div className="job-description"> {parse(jobDescription)} </div>
                                                <h4 className="job-content-heading">Requirements</h4>
                                                <div className="job-description"> {parse(jobRequirement)} </div>

                                            </div>
                                            <div className="col-4 job-info-sidebar">
                                                <h4 className="job-content-heading"> Job Information</h4>
                                                <ul className="none-ul-style">
                                                {data?.industry && <li>
                                                        <label> Industry</label>
                                                        <span> {data?.industry}</span>
                                                    </li>
                                                }
                                                {data?.jobCity && <li>
                                                        <label> City</label>
                                                        <span> {data?.jobCity}</span>
                                                    </li>
                                                }
                                                {data?.province && <li>
                                                        <label> Province</label>
                                                        <span> {data?.province}</span>
                                                    </li>
                                                }
                                                {data?.country && <li>
                                                    <label> Country</label>
                                                    <span> {data?.country}</span>
                                                </li>
                                                }
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="col-8"> 
                                                <button className="globalButton job-cta" onClick={handleIntrested}>{`I'm interested`}</button>
                                            </div>
                                            <div className="col-4"></div>

                                        </div>
                            
                                    </div>
                                </div>
                        </div>
                        }
                        {showForm &&
                            <div className="job-application-from">
                                <Form questionsData={data?.questionsCollection} onChildClick={closeClick} jobTitle={jobTitle} formClass="job-application-form" fileInputClass="file-upload-class" />
                            </div>
                        }
                        </div>
            })
        }
    </>
    );
}
export default JobDetail;


export async function getStaticProps(context: any) {
     const slug = context.params.slug;
     const singleJob = await getSingleJobPostings(slug);
     return {
       props: {
        singleJob,
       },
       revalidate: 60
     };
   }
   
   export async function getStaticPaths() {
     const singlePost = await getJobPostings();
     const paths = singlePost?.jobPostingCollection?.items?.map((post:any) => ({
       params: { slug: post?.sys?.id },
     }))
     return { paths, fallback: 'blocking' }
   
   }

