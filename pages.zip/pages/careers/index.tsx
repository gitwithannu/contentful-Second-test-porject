import { PageBanner } from "@/src/components";
import Head from 'next/head';
import Link from "next/link";
import Image from "next/image";
import React, { useState, useEffect } from 'react';
import { getJobPostings, getJobSearchQuery } from "@/utils/contentful";
import parse from "html-react-parser";
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';

const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || '';

interface FormDataCustom {
  [key: string]: string;
}

const CareerNew = (jobPosting: any) => {
  const [customFields, setCustomFields] = useState<FormDataCustom>({});
  const [displayedPosts, setDisplayedPosts] = useState<Array<any>>([]);
  const [loading, setLoading] = useState<any>(false);

  const allJobs = jobPosting?.jobPosting?.jobPostingCollection?.items;

  const handleTitleChange = (e: any) => {
    e.preventDefault();
    const value = e.target.value.toLowerCase();
    if (value.charAt(0) === ' ') {
      return false;
    }
  };

  const fetchData = async ({ jobTitle, jobLocation }: any) => {
    try {
      const req = await getJobSearchQuery(jobTitle, jobLocation);
      const searchData = req.jobPostingCollection?.items;
      setDisplayedPosts(searchData);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    const inputFields = e.target.querySelectorAll('input');
    const updatedCustomFields: FormDataCustom = {};
    inputFields.forEach((input: any) => {
      updatedCustomFields[input.name] = input.value;
    });
      setLoading(true);
      await setCustomFields(updatedCustomFields);
      setTimeout(() => {
        fetchData(updatedCustomFields);
      }, 2000);
  };

  useEffect(() => {
    setDisplayedPosts(allJobs);
  }, []);

  useEffect(() => {
    setLoading(false);
  }, [displayedPosts]);

  return (
    <div className="career">
      <Head>
        <title>Careers With Us | TRU</title>
        <meta
          name="description"
          content={`Explore exciting career opportunities with TRU Agency. Join our squad and be part of innovative projects that shape the future of digital marketing.`}
          key="desc"
        />
        <link rel="canonical" href={`${BASE_URL}/careers`} />
      </Head>
      <PageBanner title="At Tru, Innovation Starts Here." subtitle="Embark on your professional journey with us by exploring the exciting career opportunities currently available." />
      <div className="career--inner">
        <div className="container">
          <div className="col-10">
            <div className="row">
              <div className="col-12">
                <h3> Join us</h3>
                <p>Current Openings</p>
              </div>
            </div>
            <div className="row">
              <div className="col-12">
                <div className="job-search-bar">
                  <form className="job-search-form" onSubmit={handleSubmit}>
                    <div className="job-search-fields">
                      <div className="job-fields-col">
                        <label>What</label>
                        <input type="search" placeholder="Job title or skill" name="jobTitle" onChange={handleTitleChange} />
                        <span className="demo-icon icon-search-1"></span>
                      </div>
                      <div className="job-fields-col">
                        <label> Where</label>
                        <input type="search" name="jobLocation" placeholder="City, state/province or country" />
                        <span className="demo-icon icon-location-outline"></span>
                      </div>
                    </div>
                    <button className="globalButton" type="submit" >Submit</button>
                  </form>
                </div>
              </div>
            </div>
            {/* jobs search list start here */}
            <div className="job-list">
              <div className="row">
                <div className="col-12">
                  {loading ? (
                    <div className="loading-job-list">
                      <Image src="/images/icons/loading.svg" alt="loading-image" width="200" height="200" />
                    </div>
                  ) : (
                    displayedPosts?.map((job: any, index: any) => {
                      const jobDescription = documentToPlainTextString(job?.jobDescription?.json);
                      const words = jobDescription.split(/\s+/);
                      const first50Words = words.slice(0, 20).join(' ');
                      const publishedDate = job?.sys?.firstPublishedAt;
                      let date = new Date(publishedDate);
                      var year = date.getFullYear();
                      var month = (date.getMonth() + 1).toString().padStart(2, '0');
                      var dateVal = date.getDate();
                      return (
                        <div className="job-list-outer" key={index}>
                          <div className="job-list-left-col col-10">
                            <h4 className="job-list-title"> <Link href={`/careers/${job?.sys?.id}`}>{job?.jobTitle}</Link> </h4>
                            <p className="job-location">{job?.jobCity ? job?.jobCity + ',' : ""}  {job?.province ? job?.province + ',' : ""} {job?.country ? job?.country : ""}</p>
                            <div className="job-description">{words.length > 50 ? parse(first50Words + '...') : first50Words}</div>
                          </div>
                          <div className="job-list-right-col col-4">
                            <div className="search-date-type">
                              {job?.jobType && <span className="search-full-time"> <strong>{job?.jobType}</strong> </span>}
                              {month && dateVal && year && <span className="job-search-date">{dateVal}/{month}/{year}</span>}
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                  {displayedPosts?.length === 0 && !loading &&
                    <div className="col-12">
                      <div className="job-no-results">
                        <div className="no-results-outer">
                          <Image fill priority src="/images/no-jobs.svg" alt="nojobs" />
                        </div>
                        <h4> There are no results that match your search.</h4>
                      </div>
                    </div>
                  }
                </div>
              </div>
            </div>
            {/* jobs search list end here */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CareerNew;

export async function getStaticProps(context: any) {
  const jobPosting = await getJobPostings();
  return {
    props: {
      jobPosting,
    },
    revalidate: 60
  };
}
