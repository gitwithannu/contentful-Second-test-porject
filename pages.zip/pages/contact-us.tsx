import Image from "next/image";
import { PageImageBanner, AccordionWrapper, Accordion, AccordionHeader, AccordionPanel,ServicesExternalTile } from "@/src/components";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import { useCallback, useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { getContactPage } from "@/utils/contentful";
import parse from 'html-react-parser';
import { ContactForm } from "@/src/components/ContactForm";
import BlowSingleBanner from "@/src/templates/BlowSingleBanner";
import ServicesBlowPanel from "@/src/components/Services/BlowInnerPanel";
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
import Head from 'next/head';
import { useRouter } from "next/router";
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || '';
const ContactUs = (props: any) => {
  const router = useRouter();
  const contactRef = useRef<HTMLDivElement>(null);
  const contactPage = props?.contactPage?.contactUsPageCollection?.items;
  const filtered = contactPage.filter((singleData: any) => {
      return singleData.slug === "contact-us";
  });
  useIsomorphicLayoutEffect(() => {
    let ctx = gsap.context(() => {
      gsap.set(".mainBannerHeading", { scale: 2, opacity: 0 });
      gsap.set(".mainBannerSubheading", { xPercent: 20, opacity: 0 });
      gsap.to(".mainBannerHeading", {
        opacity: 1,
        scale: 1,
        duration: 1,
        ease: "Power4.easeOut",
        delay: 1,
      });
      gsap.to(".mainBannerSubheading", {
        xPercent: 0,
        opacity: 1,
        delay: 1,
        duration: 1,
      });
    }, contactRef);
    return () => ctx.revert();
  }, []);

  useEffect(() => {
    // Function to reload the page when the route changes to /contactus
    const handleRouteChange = (url: string) => {
      if (url === '/contact-us') {
        router.reload();
      }
    };

    // Subscribe to router events and attach the route change handler
    router.events.on('routeChangeComplete', handleRouteChange);

    // Cleanup the event listener to avoid memory leaks
    return () => {
      router.events.off('routeChangeComplete', handleRouteChange);
    };
  }, [router]);

  return filtered.map((section: any, key: any) => {

    const allsection = section?.sectionsCollection?.items;
    const metaTitle = section?.metaTitle;
    const pageSlug = section?.slug;
    const metaIndex = section?.enableMetaIndex;
    const metaDescription = section?.metaDescription;
    const faq = allsection.filter((data: any) => {
      return data.tag === "faq";
    });
    const contactServicePanel = allsection.filter((data: any) => {
      return data.tag === "contactServicePanel";
    });
    
    const belowBannerSection = allsection.filter((data: any) => {
      return data.tag === "belowBannerSection";
    });

    let faqData: string[] = [];
    return (
      
      <div key={key} className="contact--parent">
        <Head>
          <title>{metaTitle ? metaTitle : "TRU AGENCY"}</title>
          {metaIndex && metaIndex != null ?
             <meta name="robots" content="index, follow" />
            :
             <meta name="robots" content="noindex, nofollow" />
          }
            <meta
            name="description"
            content={metaDescription ? metaDescription : "TRU AGENCY"}
            key="desc"
          />
          <link rel="canonical" href={`${BASE_URL}/${pageSlug}`} />
          
          <script type="application/ld+json" dangerouslySetInnerHTML={{
          __html: `{
            "@context": "https://schema.org/", 
            "@type": "BreadcrumbList",
            "name": "BreadcrumbList",
            "itemListElement": [{
              "@type": "ListItem", 
              "position": 1, 
              "name": "Home",
              "item": "${BASE_URL}"  
            },{
              "@type": "ListItem", 
              "position": 2, 
              "name": "${section?.title}",
              "item": "${BASE_URL}/${pageSlug}"  
            }]
          }`
          }} /> 

            {
              faq[0]?.accordions?.forEach((accordion: any) => { 
                const faqItem = {
                  "@type": "Question",
                  "name": accordion?.key, // Assuming each accordion object has a "question" property
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": accordion?.value // Assuming each accordion object has an "answer" property
                  }
                };

                // Convert the object to a string and push it to faqData array
                faqData.push(JSON.stringify(faqItem));
              })
          }
          

<script type="application/ld+json" dangerouslySetInnerHTML={{
          __html: `{
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "name": "FAQPage",
              "mainEntity":
              [${faqData}]
            }`
          }} /> 
          
        </Head> 
        <PageImageBanner
          title={section?.title}
          subtitle={section?.pageSubTitle}
          bg={section?.bannerImage.url}
          bgAlt={section?.bannerImage.title}
          cta={true}
          goBackName="Home"
          goBackUrl="/"
        />

        {belowBannerSection?.length > 0 ? <BlowSingleBanner>
          <ServicesBlowPanel
              bannerHeading={belowBannerSection[0]?.title}
              bannerSubHeading={belowBannerSection[0]?.subTitle}
              bannerDescription={documentToPlainTextString(belowBannerSection[0]?.description?.json)}
          />
        </BlowSingleBanner> : null}
        
        <div className="contatUsForm paddingB128">
           <div className="contact--main paddingT128 paddingB128">
              <ContactForm />
              <p className="desc-center">{`Your privacy is important to us; we take every step to make sure your data is kept secure.`}</p>
           </div> 
            
            <div className="container">
                <div className="faq">
              <div className="faq--title">
                <h2>{section?.faqSectionHeading}</h2>
                <p>{parse(section?.subheading)}</p>
              </div>
              <AccordionWrapper>
              {
                faq[0]?.accordions?.map((accordion: any, key: any) => {
                   return (
                      <Accordion key={key} customIndex={key}>
                       <AccordionHeader>{accordion?.key}</AccordionHeader>
                        <AccordionPanel>
                         <p>{parse(accordion?.value)}</p>
                        </AccordionPanel>
                      </Accordion>
                   )
                })
                }
                </AccordionWrapper>
            </div>
               
            </div>
          <ServicesExternalTile className="paddingT128 pb-0" CardsData={contactServicePanel[0].cardsCollection.items} />
          <div className="blueCircle">
                <Image src="/images/bottomGradient.png" fill priority alt="bottom gradient" />
              </div>
        </div>
        
      </div>
    )
  })
}

export default ContactUs;

export async function getStaticProps(context: any) {
  const contactPage = await getContactPage();
  return {
    props: {
      contactPage
    },
    revalidate: 60
  };
}

