import { AnimateCircle, PageBanner } from "@/src/components";
import { useRef, useState, useEffect } from "react";
import { searchQuery,getSearchSuggestions } from "@/utils/contentful";
import Router, { useRouter } from "next/router";
import Link from "next/link";
import Image from "next/image";
import { Loader } from "@/src/components/Loader";
import Head from "next/head";
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || '';
const SearchPage = (props:any) => {
  const router = useRouter();
  const data = props?.searchSuggestions?.topNavigationCollection?.items[0]?.searchSuggestions;
  const [loading, setLoading] = useState(false);
  const [searchData, setData] = useState<any[]>([]);
  const [searchValue, setSearchValue] = useState<any[]>([]);
  const [searchValueSearchBar, setSearchValueSearchBar] = useState<any[]>([]);
  const [values, setValues] = useState<any[]>([]);
  const [suggestions, setSuggestions] = useState([]);
  const [suggestionIndex, setSuggestionIndex] = useState(0);
  const [suggestionsActive, setSuggestionsActive] = useState(false);

  const inputRef = useRef<any>(null);
  let count = 0;
  let combinedData:any = [];
  let searchedVal: any;
  const [typing, setTyping] = useState(false);
  const fetchData = async (searchString: any) => {
    let arraydata: any = [];
    if (searchString != "" && searchString != undefined) {
      const req = await searchQuery(searchString);
      arraydata.push({
        about: req?.aboutUsModelCollection?.items,
        blogs: req?.blogPostsCollection?.items,
        home: req?.homePageModelCollection?.items,
        service: req?.singleServiceCollection?.items,
      })
      
      setData(arraydata);
      setLoading(false)
    } else {
      setData([]);
    }
  };

  useEffect(() => {
    setLoading(true);
    setTimeout(function () {
      
      searchedVal = router.query.s;
      if (searchedVal != "" && searchedVal != undefined) {
        inputRef.current.value = searchedVal
        setSuggestionsActive(false);
        setSearchValue(searchedVal);
        setValues(searchedVal);
        fetchData(searchedVal);
      }
      setLoading(false);
    }, 600);
    
  }, [router.query]);
  
  const handleClick = (e:any) => {
    setSuggestions([]);
    setSearchValue(e.target.innerText);
    setSuggestionsActive(false);
    setValues(e.target.innerText);
    const targetElement = document.getElementById('searchTextField') as any;
    targetElement.value = e.target.innerText.toLowerCase();
    if (e.target.innerText != "" && e.target.innerText != undefined) {
      fetchData(e.target.innerText);
    }
  };

  const handleChange = (e: any) => {
    e.preventDefault();
   
    const value = e.target.value.toLowerCase();
    if (value.charAt(0) === ' ') {
      return false
    }
    
    if (value.length > 1 ||  e.key === 'Enter') {
      const filterSuggestions = data?.filter(
        (suggestion:any) =>
          suggestion.toLowerCase().indexOf(value) > -1
      );
      setSuggestions(filterSuggestions);
      setSuggestionsActive(true);
      setSearchValue(value)
      setValues(value)
      } else {
      setSearchValue([]);
      setSuggestionsActive(false);
      }
  };


  const clickedData = (e: any) => {
    const searcVal = inputRef.current.value;
    if (searcVal.charAt(0) === ' ') {
      return false
    } else {
      setSearchValueSearchBar(searcVal.trimStart())
      setSearchValue(searcVal.trimStart());
      setValues(searcVal.trimStart());
    }
  }

  useEffect(() => {
    fetchData(searchValueSearchBar);
    
  }, [searchValueSearchBar]);

  const Suggestions = () => {
    return (
      <ul className="suggestions">
        {suggestions?.map((suggestion, index) => {
          return (
            <li
              className={index === suggestionIndex ? "active" : ""}
              key={index}
              onClick={handleClick}
            >
              {suggestion}
            </li>
          );
        })}
      </ul>
    );
  };

  searchData?.map((data: any) => {
    var array = Object.keys(data).map(function (key: any) { return data[key]; });
    array?.map((arrData: any,index:any) => {
      arrData?.map((finalData: any,i:any) => {
        combinedData.push(finalData)
        count = count + 1;
      })
    })
  })

  return (
    <div className="SearchPageMain">
       <Head>
        <title>{`Search Page | TRU`}</title>
        <meta name="robots" content="noindex, follow" />
        <meta
          name="description"
          content={`Search for any service, product, or blog on any webpage on the TRU website, Any page you're looking for. Type the keyword in the box & get related results.`}
          key="desc"
        />
         <link rel="canonical" href={`${BASE_URL}/search`} />
         <script type="application/ld+json" dangerouslySetInnerHTML={{
            __html: `{
                "@context": "https://schema.org/", 
                "@type": "BreadcrumbList",
                "name": "BreadcrumbList",
                "itemListElement": [{
                "@type": "ListItem", 
                "position": 1, 
                "name": "Home",
                "item": "${BASE_URL}"  
                },{
                "@type": "ListItem", 
                "position": 2, 
                "name": "Search",
                "item": "${BASE_URL}/search"  
                }]
            }`
          }} /> 
      </Head> 
      <div className="searchTopPanel">
        <AnimateCircle className="left-top" />
        <AnimateCircle animate={false} className="right-bottom" />
        <div className="container">
          <h1 className="mainBannrHeading">How can we help you?</h1>
          <div className="SearchBox">
            <input
              id="searchTextField"
              type="text"
              defaultValue={searchValue}
              placeholder="Type your keyword here..."
              onChange={handleChange}
              ref={inputRef}
            />
            <button onClick={clickedData}><span className="demo-icon icon-search-1"></span></button>

            {suggestionsActive && <Suggestions />}

          </div>
        </div>
      </div>

      <div className="innerSearchPage container">
        <div className="searchResultPanel">
        {loading ? <Loader />:""}
        {count > 0 ?
          <p className="result">{count} results found for “{searchValue}”</p>
            :
            <div className={`innerSearchPage container ${loading ? "hideMessage" :""}`}>
              <div className="searchResultPanel textCenter">
                <div className="bookIcon">
                  <Image src="/images/book.svg" alt="Icon" width={50} height={50} />
                </div>
                 <p className="result">0 results found for “{searchValue}” </p>
                  <div className="searchResultBlock">
                    <h5 className="text-center">{`Sorry! We looked everywhere, but could not find "${searchValue ? searchValue :""}"`}</h5>
                    <p>{`Try a different search, or browse our help topic instead.`}</p>
                  </div>
              </div>
            </div>
          }
          {combinedData?.map((data: any, key: any) => {
            let slug;
            if (data?.pageSlug) {
              slug = data?.pageSlug;
            }
            if (data?.pageSlug && data?.__typename==="HomePageModel") {
              slug = "/";
            }
             if (data?.slug && data?.__typename==="BlogPosts") {
              slug = "/blogs/"+data?.slug;
            }
             if (data?.slug && data?.__typename==="SingleService") {
              slug = "/services/"+data?.slug;
            }
          return (
            <div className="searchResultBlock" key={key}>
               <Link
                    href= {slug}
                    className=""
                    aria-label="All News"
                  >
                <h5>{data?.title} {data?.pageName} {data?.postTitle} {data?.serviceTitle}</h5>
                </Link>
                  <p>
                  {data?.excerpt}
              </p>
            </div>
            )})}
        </div>
      </div>
    </div>
  );
};
export default SearchPage;

export async function getStaticProps(context: any) {
  const searchSuggestions = await getSearchSuggestions();
  return {
    props: {
      searchSuggestions,
    },
    revalidate: 60
  };
}
