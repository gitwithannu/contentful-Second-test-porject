import {
  AboutPin,
  Hero,
  LatestStudio,
  LetsTalk,
  Partners,
  PortfolioContent,
  PortfolioHeading,
  ServicePin,
} from "@/src/components";
import { Complaint } from "@/src/components/Home";
import Head from 'next/head';

import { getHomepageData, getBlogsHome } from "@/utils/contentful";
import { documentToHtmlString } from '@contentful/rich-text-html-renderer';
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || '';
const Home = (props: any) => {
  const blogPosts = props?.blogs.blogPostsCollection?.items
  const allData = props?.posts?.homePageModelCollection?.items;
  const filtered = allData.filter((singleData: any) => {
    return singleData?.pageSlug === "home-page";
  });
  return filtered.map((section: any, index: any) => {
    const metaTitle = section?.metaTitle;
    const metaDescription = section?.metaDescription;
    const metaIndex = section?.enableMetaIndex;
    const allSections = section.allSectionsCollection.items
    const pageSlug = section.pageSlug;
    const bannerData = allSections.filter((data: any) => {
      return data.tag === "homePageBanner";
    });
    const aboutData = allSections.filter((data: any) => {
      return data.tag === "homePageAbout";
    });

    const services = allSections.filter((data: any) => {
      return data.tag === "homePageServices";
    });
    const potfolios = allSections.filter((data: any) => {
      return data.tag === "homePagePortfolio";
    });
    const partners = allSections.filter((data: any) => {
      return data.tag === "homePagePartner";
    });
    const partnersSlider = allSections.filter((data: any) => {
      return data.tag === "homePagePartnerSlider";
    });
     
    const products = allSections.filter((data: any) => {
      return data.tag === "homePageProduct";
    });

    const latestPost = allSections.filter((data: any) => {
      return data.tag === "homePageBlogs";
    });
    const homeLetsWork = allSections.filter((data: any) => {
      return data.tag === "homeLetsWork";
    });
    const complaintBottom = allSections.filter((data: any) => {
      return data.tag === "complaintBottom";
    });
    
   
    return (
      <div className="home" key={index}>
        <Head>
          <title>{metaTitle ? metaTitle : "TRU AGENCY"}</title>
          {metaIndex && metaIndex != null ?
             <meta name="robots" content="index, follow" />
            :
             <meta name="robots" content="noindex, nofollow" />
          }
        <meta
          name="description"
          content={metaDescription ? metaDescription : "TRU AGENCY"}
          key="desc"
          />
          <link rel="canonical" href={`${BASE_URL}`} />
          <script type="application/ld+json" dangerouslySetInnerHTML={{
          __html: `{
            "@context": "https://schema.org/",
            "@type": "BreadcrumbList",
            "name": "BreadcrumbList",
            "itemListElement": [{
              "@type": "ListItem",
              "position": 1,
              "name": "Home",
              "item": "${BASE_URL}"
            }]
          }`
          }} />
      </Head> 
        
        {
          bannerData.map((data: any,key:any) => {
            return (<Hero key={key} bannerTitle={data?.title} bannerImage={data?.image?.url} bannerAlt={data?.image?.title} /> )
            }
           )
        }
         {
          aboutData.map((data: any, key: any) => {
            const buttonUrl = data?.buttonUrl;
            const buttonText = data?.buttonText;
            const enableButton = data?.enableButton;
            const dess = data?.description
            return (<AboutPin key={key} title={data?.title} buttonEnable={enableButton} description={documentToPlainTextString(dess?.json)} buttonUrl={buttonUrl} buttonText={buttonText} /> )
            }
           )
        }
        {
          services.map((service: any,key:any) => {
            const bgImage = service?.image;
             const mobileImage = service?.mobileImage;
            const servicesDescription = service?.description;
             const servicesCollection = service?.cardsCollection;
            const servicesTitle = service?.title;
            const buttonText = service?.buttonText;
            const buttonURL = service?.buttonUrl;
            const enableButton = service?.enableButton;
            return (<ServicePin key={key} mobileImage={mobileImage} bgImageAlt={bgImage?.title} bgImage={bgImage?.url} serviceData={JSON.stringify(servicesCollection)} title={servicesTitle} description={documentToPlainTextString(servicesDescription.json)} enableButton={enableButton} buttonUrl={buttonURL} buttonText={buttonText} />)
            })
        }
        {
          potfolios?.map((portfolio: any,key:any) => {
            const portfolioHeading = portfolio?.title;
            const portfolioDescription = portfolio?.description;
            const allPortfolioButtonText = portfolio?.buttonText;
            const allPortfolioButtonUrl = portfolio?.buttonUrl;
            const portfolioItems = JSON.stringify(portfolio.cardsCollection.items);
            return (
               <div key={key}>
               <PortfolioHeading title={portfolioHeading} description={JSON.stringify(portfolioDescription)} />
                <PortfolioContent data={portfolioItems} allPortfolioButtonUrl={allPortfolioButtonUrl} allPortfolioButtonText={allPortfolioButtonText} />
                 </div>)
              })
        }
        {
          partnersSlider.map((partner: any,key:any) => {
            let partnerDescription = partner?.description;
            const sliderImages = partner?.cardsCollection
            if (partnerDescription) {
              partnerDescription = documentToPlainTextString(partnerDescription?.json)
            } else {
              partnerDescription = ''
            }
            const buttonUrl = partner?.buttonUrl ? partner?.buttonUrl : "";
            const buttontext = partner?.buttonText ? partner?.buttonText : "";
            const enableButton = partner?.enableButton;
            return <Partners key={key} title={partner?.title} description={partnerDescription} sliderImage={JSON.stringify(sliderImages)} enableButton={enableButton} buttonText={buttontext} buttonUrl={buttonUrl}/>
           })
        }
        {
          latestPost.map((post: any, key: any) => {
            
            const buttonUrl = post?.buttonUrl
            const buttonText = post?.buttonText
            const description = post?.description;
             return <LatestStudio key={key} description={documentToPlainTextString(description?.json)} title={post.title} subTitle={post.subTitle} bolgPosts={JSON.stringify(blogPosts)} buttonUrl={buttonUrl} buttonText={buttonText} />
           })
        }
        {
          homeLetsWork.map((letsWork: any, key: any) => {
          
            return <LetsTalk key={key} title={letsWork?.title} subTitle={letsWork?.subTitle} buttonText={letsWork?.buttonText} buttonUrl = {letsWork?.buttonUrl} />
          })
        }
        {
          complaintBottom.map((box: any, key: any) => {
            const imageAlt = box?.image?.title;
            const imageUrl = box?.image?.url;
            const description = box?.description;
            return <Complaint imageUrl={imageUrl} imageAlt={imageAlt} description={documentToPlainTextString(description?.json)} key={key} />
          })
        }
      </div>
    );
  });
  };

export default Home;

export async function getStaticProps(context: any,res:any) {
  const posts = await getHomepageData();
  const blogs = await getBlogsHome();
  return {
    props: {
      posts,
      blogs
    },
    revalidate: 60
  };
}
