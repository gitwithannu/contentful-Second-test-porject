import React, { useRef } from "react";
import BlowSingleBanner from "@/src/templates/BlowSingleBanner";
import ServicesBlowPanel from "@/src/components/Services/BlowInnerPanel";
import ContactTeamPanel from "@/src/components/Services/ContactTeam";
import Image from "next/image";
import { FullImage, PageImageBanner, ExploreCard } from "@/src/components";
import Link from 'next/link';
import ServicesBottomPanel from "@/src/components/Services/ServicesBottomPanel";
import { servicescard } from "@/src/static";
import { useIsomorphicLayoutEffect } from "@/src/utils/useIsomorphicLayoutEffect";
import { getServiceArchive } from "@/utils/contentful";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
import { ServicesEnhance } from '@/src/components';
import parse from 'html-react-parser';
import Head from 'next/head';
import dynamic from "next/dynamic";
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || '';
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))
const Services = (serviceArchive: any) => {
const allData = serviceArchive?.serviceArchive?.homePageModelCollection?.items;
const servicesRef = useRef<HTMLDivElement>(null);
  useIsomorphicLayoutEffect(() => {
        let ctx = gsap.context((self) => {
          setTimeout(() => {
            let sections = gsap.utils.toArray('.boxes');
            gsap.set(".boxes", { yPercent: 20, opacity: 0 })
            gsap.set(".boxes-2, .boxes-4, .boxes-6", { yPercent: 40, opacity: 0 })
            sections.forEach((section:any) => {
              gsap.to(section, { yPercent: 0, autoAlpha: 1,
                scrollTrigger: {
                    trigger: section,
                    start: 'top 80%',
                    scrub: true,
                    end: '+=300'
                }
            });
              
            })
          }, 1000)
  

        }, servicesRef)
        return () => ctx.revert();  
  }, []);

  return allData?.map((section: any, index: any) => {
    const pageClass = section?.pageSlug;
    const allSections = section?.allSectionsCollection?.items;
    const metaTitle = section?.metaTitle;
    const metaDescription = section?.metaDescription;
    const metaIndex = section?.enableMetaIndex;
      const bannerData = allSections.filter((data: any) => {
        return data.tag === "topSectionImage";
      });
     
      const belowTopBanner = allSections.filter((data: any) => {
        return data?.tag === "belowBannerSection";
      });
      const topContactSectiom = allSections.filter((data: any) => {
        return data?.tag === "topContactSectiom";
   });
      const middleSingleBanner = allSections.filter((data: any) => {
        return data.tag === "middleSingleBanner";
      });
      const serviceCardSection = allSections.filter((data: any) => {
        return data.tag === "serviceCardSection";
      });
      const enhanceSection = allSections.filter((data: any) => {
        return data.tag === "enhanceSection";
      });
      const bottomServiceCardSection = allSections.filter((data: any) => {
        return data.tag === "bottomServiceCardSection";
      });
      return (
        <div key={index} className={`service-archive`}>
          <Head>
            <title>{metaTitle ? metaTitle : "TRU AGENCY"}</title>
            {metaIndex && metaIndex != null ?
                <meta name="robots" content="index, follow" />
                :
                <meta name="robots" content="noindex, nofollow" />
              }
            <meta
              name="description"
              content={metaDescription ? metaDescription : "TRU AGENCY"}
              key="desc"
            />
            <link rel="canonical" href={`${BASE_URL}/${section?.pageSlug}`} />
            <script type="application/ld+json" dangerouslySetInnerHTML={{
          __html: `{
            "@context": "https://schema.org/", 
            "@type": "BreadcrumbList",
            "name": "BreadcrumbList",
            "itemListElement": [{
              "@type": "ListItem", 
              "position": 1, 
              "name": "Home",
              "item": "${BASE_URL}"  
            },{
              "@type": "ListItem", 
              "position": 2, 
              "name": "About",
              "item": "${BASE_URL}/${section?.pageSlug}"  
            }]
          }`
          }} />  
          </Head> 
          {
          bannerData.map((data: any,key:any) => {
            return (<PageImageBanner
              title={data?.title}
              key={key}
              subtitle=""
              bg={data?.image?.url}
              bgAlt={data?.image?.title}
              goBackUrl="/" goBackName ="Home"
            /> )
            }
           )
          }
          {
            belowTopBanner?.map((data: any, key: any) => {
                  return <BlowSingleBanner key={key}>
                      <ServicesBlowPanel
                            bannerHeading={data?.title}
                            bannerSubHeading={data?.subTitle}
                            bannerDescription={documentToPlainTextString(data?.description?.json)}
                      />
                  </BlowSingleBanner>
            })  
          }
          {
            topContactSectiom?.map((section: any, key: any) => {
                    return <ContactTeamPanel key={key}
                          description={section?.subTitle}
                      ctatext={section?.buttonText}
                      ctaUrl ={section?.buttonUrl}
                      />
                })
          }
          { middleSingleBanner?.map((banner: any, key: any) => {
                return <FullImage  key={key} src={banner?.image?.url} alt={banner?.image?.title} /> 
          })}  

          {serviceCardSection?.map((card: any, key: any) => {
            let desc;
            const serviceCollection = card?.cardsCollection?.items;
            let servicescardss:any=[];
            serviceCollection?.map((item: any, key: any) => {
              let itemDescription;
              const description = documentToPlainTextString(item?.description.json);
              if (description) {
                itemDescription = description
              } else {
                itemDescription = "";
              }
              let repaterArray:any=[];
              item?.repeater.map((repeaterItem: any, key: any) => {
                let linkText;
                if (repeaterItem?.value) {
                  linkText = repeaterItem?.value
                } else {
                  linkText = "#";
                }
                repaterArray.push({
                  link : repeaterItem?.value,
                  linktext : repeaterItem?.key,
                })
              })
              const dess =  documentToPlainTextString(item.description.json)
              servicescardss.push({
                icon: item?.icon?.url,
                iconAlt: item?.icon?.title,
                title : item?.title,
                lineText : item?.lineText,
                desc: dess,
                usefulLink  : repaterArray
                })
            });
            const cardDescription = documentToPlainTextString(card?.description?.json);
            return (
              <div key={key} className="explore-services" ref={servicesRef}>
              <div className="container explore-services-intro">
                <div className="row">
                  <div className="col-5">
                      <h2 className="boxes">{parse(card?.title)}</h2>
                  </div>
                  <div className="col-7 explore-services-intro boxes">
                    {cardDescription ? parse(cardDescription) :""}
                  </div>
                </div>
              </div>  
              <div className="explore-sevices-inner">
                <div className="container">
                  <div className="row">
                      {
                      
                      servicescardss?.map((el:any, index:any) =>(
                        <div className="col-6" key={el?.title}>
                          <ExploreCard 
                            icon={el?.icon} 
                            iconAlt ={el?.iconAlt}
                            title={el?.title} 
                            outlineText={el?.linetext} 
                            desc={el?.desc} 
                            lists={el?.usefulLink} 
                            className={`boxes-${index+1} boxes`}
                          />
                        </div> 
                      ))
                    }
                  </div>
                </div>
              </div>
              <div className="explore-services-bg">
                <Image src="/images/Services/services-bg.jpg" alt="Services Gradient" fill priority />
              </div>
            </div>
            )
            
          })}  

          {enhanceSection?.map((sectionData: any, key: any) => {
            let desc;
            const description = documentToPlainTextString(sectionData?.description?.json);
            if (description) {
              desc = description;
            } else {
              desc = ""
            }
            return <ServicesEnhance key={key}
              title={sectionData?.title ? `${sectionData?.title}` : ""}
              customClass={`enhance-${pageClass}`}
                    subtitle={sectionData?.subtitle ? sectionData?.subtitle : ""}
                    description={description ? description : ""}
                    singleBannerImageURL={sectionData?.sectionImage?.url}
                    singleBannerMobImageURL={sectionData?.mobileSectionImage?.url}
                    singleBannerImageAlt={sectionData?.sectionImage?.title}
                    singleBannerMobImageAlt={sectionData?.mobileSectionImage?.title} />
          })
          }

          {bottomServiceCardSection?.map((sectionData: any, key: any) => {
            return (
              <section className="services-main-section paddingT128" key={key}>
                <div className="truAdsSolutions">
                  <div className="teamContact teamContact-1 dark"><div className="teamContactWrap"><h5 className="teamContactContent" >{sectionData.title}</h5>
                    <Link href={sectionData?.buttonUrl ? sectionData?.buttonUrl: "Find the TRU way"} className="globalButton withCircle  contact-cta" aria-label="Find the TRU way" >
                      {sectionData?.buttonText ? sectionData?.buttonText : "Find the TRU way"}
                    </Link>
                  </div>
                  </div>
                </div>
              <div className="services-page-cards paddingT128 paddingB128">
                <div className="container">
                  <div className="row">
                    {sectionData?.cardsCollection?.items?.map((single: any, indexing: any) => {
                      return (
                        <div className="col-4" key={indexing}>
                        <div className="service-pages-card">
                          <div className="service-card-icon-outer">
                              <div className="service-card-icon">
                                <ImageConversion url={single?.cardImage?.url} altext={single?.cardImage?.title}/>
                            </div>
                          </div>
                            {single?.title && <Link
                              href={single?.buttonUrl ? single?.buttonUrl : "#"}
                              aria-label={single?.title}
                              target="_self"> <h4>{single?.title}</h4>
                            </Link> }
                        </div>
                      </div>
                      )
                    })}
                  </div>
                </div>
              </div>
              <div className="blueCircle">
                <Image src="/images/bottomGradient.png" fill priority alt="bottom gradient" />
              </div>
              </section>
            )
          })
          }          
        </div>
      );
    })
}
export default Services;

export async function getStaticProps(context: any) {
  const serviceArchive = await getServiceArchive();
  return {
    props: {
       serviceArchive,
    },
    revalidate: 60
  };
}