import { PageImageBanner } from "@/src/components";
import { ImageCardPin } from "@/src/components/ImageCardPin";
import BlowSingleBanner from "@/src/templates/BlowSingleBanner";
import SocialSlider from "@/src/components/SocialSlider";
import CommonSlider from "@/src/components/CommonSlider";
import Image from "next/image";
import ServicesBlowPanel from "@/src/components/Services/BlowInnerPanel";
import CardGrid from "@/src/components/Services/CardGrid";
import OurPartnerPanel from "@/src/components/Services/OurPartner";
import ContactTeamPanel from "@/src/components/Services/ContactTeam";
import ServicesBottomPanel from "@/src/components/Services/ServicesBottomPanel";
import SingleBanner from "@/src/components/Services/SingleBanner";
import ServicesProductSlider from "@/src/components/Services/ServicesProductSlider";
import { getSingleServicePagenew, allServicesHomePage } from "@/utils/contentful";
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
import { documentToHtmlString } from "@contentful/rich-text-html-renderer";
import { Modal } from "@/src/components/Modal";
import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import SeoEnhance from "@/src/components/Services/SeoEnhance";
import parse from 'html-react-parser';
import { useRouter } from "next/router";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { ServicesExternalTile } from '@/src/components'
import Head from 'next/head';
import dynamic from "next/dynamic";
import { removeBaseUrl } from "@/utils/helper"
import Slider from "react-slick";

import "slick-carousel/slick/slick.css";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || '';

const Services = (service: any) => {
  const headingRef = useRef(null);

  const [showModal, sethowModal] = useState(false);
  const [modalData, setModalData] = useState<any>();
  const [topBanner, setTopBanner] = useState<any>([]);
  const [showTitle, setShowTitle] = useState(true);
  
     const toggle = (status: any) => {
          const imageUrl = status.target.getAttribute("data-image");
          const description = status.target.getAttribute("data-description");
          const buttonText = status.target.getAttribute("data-button-text");
          const buttonUrl = status.target.getAttribute("data-button-url");
          const modalData = status.target.getAttribute("data-modal");
           setModalData(modalData);
       
          sethowModal(!showModal);
  };

  const toggleModal = (status:any) => {
     sethowModal(!showModal);
   };
 
  useEffect(() => {
    let selectBody = document.querySelector("body");
    if (showModal) {
      //@ts-ignore
      selectBody.classList.add("hideScroll");
    } else {
      //@ts-ignore
      selectBody.classList.remove("hideScroll");
    }
  }, [showModal]);
  
  const singleService = service?.singleService?.singleServiceCollection?.items[0];
  const pageClass = singleService?.slug;
  const metaTitle = singleService?.metaTitle;
  const metaDescription = singleService?.metaDescription;
  const metaIndex = singleService?.enableMetaIndex;
  const ourPartnerBottom = {
    centerMode: true,
  dots: false,
  infinite: true,
  slidesToShow: 8,
  slidesToScroll: 1,
  autoplay: true,
  speed: 1500, 
  arrows: false,
  autoplaySpeed: 1500,
  centerPadding: "7vw",
    responsive: [
      {
        breakpoint: 1660,
        settings: {
          slidesToShow: 6,
        },
      },
      {
        breakpoint: 991,
        settings: {
          slidesToShow: 4,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          centerMode: true,
          centerPadding: "80px",
        },
      },
      {
        breakpoint: 575,
        settings: {
          slidesToShow: 2,
          centerMode: true,
          centerPadding: "80px",
        },
      },
    ],
  };
  
  useEffect(() => {
    setTopBanner(service.topBanner)
    setShowTitle(false)
  }, [service.topBanner]);

  const toggleClose = () => {
    sethowModal(!showModal);
  };
  const router = useRouter();
  const bannerTitle = service.topBanner[0]?.title;
  return <div className={`home ${pageClass} psr`}>
        <Head>
            <title>{metaTitle ? metaTitle : "TRU AGENCY"}</title>
            {metaIndex && metaIndex != null ?
                <meta name="robots" content="index, follow" />
                :
                <meta name="robots" content="noindex, nofollow" />
              }
              <meta
                name="description"
                content={metaDescription ? metaDescription : "TRU AGENCY"}
                key="desc"
      />
      <link rel="canonical" href={`${BASE_URL}/services/${pageClass}`} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{
          __html: `{
            "@context": "https://schema.org/", 
            "@type": "BreadcrumbList",
            "name": "BreadcrumbList",
            "itemListElement": [{
              "@type": "ListItem", 
              "position": 1, 
              "name": "Home",
              "item": "${BASE_URL}"  
            },{
              "@type": "ListItem", 
              "position": 2, 
              "name": "Services",
              "item": "${BASE_URL}/services"  
            },{
              "@type": "ListItem", 
              "position": 3, 
              "name": "${service?.topBanner[0]?.title ? service?.topBanner[0]?.title.replace(/<\/?[^>]+(>|$)/g, "") : 'Single service'}",
              "item": "${BASE_URL}/services/${pageClass}"  
            }]
          }`
          }} />  
    </Head>  
    {showTitle ? <h1 className="mainBannerHeading-new" ref={headingRef}> {parse(bannerTitle)}</h1> : null}
        {topBanner.length > 0 ? <PageImageBanner 
          title={topBanner[0]?.title} 
          bgAlt={topBanner[0]?.image?.title} 
          goBackUrl="/services/" 
          goBackName ="services" 
          bg={topBanner[0]?.image?.url}
        /> : null}  

       {service.belowSingleBanner?.length > 0 ? <BlowSingleBanner>
          <ServicesBlowPanel
              bannerHeading={service.belowSingleBanner[0]?.title}
              bannerSubHeading={service.belowSingleBanner[0]?.subTitle}
              bannerDescription={documentToPlainTextString(service.belowSingleBanner[0]?.description?.json)}
          />
        </BlowSingleBanner> : null}

        {service.contactTeamPanel?.length > 0 ? <ContactTeamPanel
          description={service.contactTeamPanel[0]?.subTitle}
          ctatext={service.contactTeamPanel[0]?.buttonText}
          ctaUrl ={service.contactTeamPanel[0]?.buttonUrl}
        /> : null}

        { service.topCardGrid.length > 0 ? service.topCardGrid?.map((card: any, key: any) => {
     const index = key + 1;
         let data: any = [];
         let position = true;
           if (card?.imagePosition) {
             position = false;    
           }
           else {
             position = true
           }
     
           const tagLine = card?.tagLine;
           const enable = card?.enableTagline;
           const flexColumns = card?.flexibleColumns
                       card?.cardsCollection?.items?.map((singleCard: any, key: any) => {
                            data.push({title:singleCard?.title,desc:documentToPlainTextString(singleCard?.description?.json),titleShow :singleCard?.showTitle})
                       })
                       let childrenDataTwo = {
                            imageUrl: card?.image?.url,
                            imageAlt: card?.image?.title,
                            title: card?.title,
                            desc: documentToPlainTextString(card?.description?.json),
                            data
                       };
           return  <CardGrid
           // cardData={childrenData}
           sectionClass={'topCardGrid-'+index}
           key={key} 
           cardData={childrenDataTwo}
           flexibleCol={flexColumns}
           bottomTagLine={enable}
           reverse={position}
           tagline={tagLine}
           />
   
       }) : null }

{ service?.ourPartners && service?.ourPartners.length > 0? service?.ourPartners?.map((data: any, key: any) => {
        const settings = {
          centerMode: true,
          dots: false,
          infinite: true,
          slidesToShow: 6,
          slidesToScroll: 1,
          autoplay: true,
          speed: 1500, 
          arrows: false,
          autoplaySpeed: 1500,
          centerPadding: "80px",
          responsive: [
            {
              breakpoint: 1660,
              settings: {
                slidesToShow: 6,
              },
            },
            {
              breakpoint: 991,
              settings: {
                slidesToShow: 4,
              },
            },
            {
              breakpoint: 768,
              settings: {
                slidesToShow: 4,
                centerMode: true,
                centerPadding: "80px",
              },
            },
            {
              breakpoint: 575,
              settings: {
                slidesToShow: 1,
                centerMode: true,
                centerPadding: "80px",
              },
            },
          ],
        };
    const customClassName = data?.customClasses;
       return <OurPartnerPanel key={key}>
         <div className={`${pageClass} ${customClassName ? customClassName : ""}`}>
         <Slider {...settings}>
         {data?.cardsCollection?.items?.map((partner: any,index:any) => {
         return <div key={index}>
                   <div className="partnerSlickSlide partnerWithIcon">
             <div className="partnerIcon">
                <ImageConversion
                    url={partner?.cardImage?.url}
                    altext={partner?.cardImage?.title}
                  />
                     </div>
                      {partner?.showTitle ? <span>{partner?.title}</span> : ""}
                   </div>
               </div>
            })
       }
             </Slider>
         </div>
            </OurPartnerPanel>
       }) : null
 }

{ service?.ourPartnersWithTitle && service?.ourPartnersWithTitle.length > 0 ? service?.ourPartnersWithTitle?.map((data: any, key: any) => {
        const settings = {
          centerMode: true,
  dots: false,
  infinite: true,
  slidesToShow: 8,
  slidesToScroll: 1,
  autoplay: true,
  speed: 1500, 
  arrows: false,
  autoplaySpeed: 1500,
  centerPadding: "7vw",
  responsive: [
    {
      breakpoint: 1660,
      settings: {
        slidesToShow: 6,
      },
    },
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 4,
      },
    },
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 4,
        centerMode: true,
        centerPadding: "80px",
      },
    },
    {
      breakpoint: 575,
      settings: {
        slidesToShow: 1,
        centerMode: true,
        centerPadding: "80px",
      },
    },
  ],
        };
        const customClassName = data?.customClasses;
       return <OurPartnerPanel key={key} >
         <div className={customClassName ? customClassName : ""}>
         <Slider {...settings}>
         {data?.cardsCollection?.items?.map((partner: any,key:any) => {
           return <div key={key}>
                   <div className="partnerSlickSlide partnerWithIcon">
                     <div className="partnerIcon">
                 <ImageConversion
                    url={partner?.cardImage?.url}
                    altext={partner?.cardImage?.title}
                  />
                     </div>
                      <span>{partner?.showTitle ? partner?.title:""}</span>
                   </div>
               </div>
            })
       }
             </Slider>
         </div>
            </OurPartnerPanel>
       }) : null
 }

{ service?.socialMediaPartner.length > 0 ? service?.socialMediaPartner?.map((data: any, key: any) => {
        const settings = {
          centerMode: true,
  dots: false,
  infinite: true,
  slidesToShow: 5,
  slidesToScroll: 1,
  autoplay: true,
  speed: 1500, 
  arrows: false,
  autoplaySpeed: 1500,
  centerPadding: "180px",
  responsive: [
    {
      breakpoint: 1660,
      settings: {
        slidesToShow: 6,
      },
    },
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 4,
      },
    },
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 4,
        centerMode: true,
        centerPadding: "80px",
      },
    },
    {
      breakpoint: 575,
      settings: {
        slidesToShow: 1,
        centerMode: true,
        centerPadding: "80px",
      },
    },
  ],
        };
        const customClassName = data?.customClasses;
       return <OurPartnerPanel key={key} >
         <div className={customClassName ? customClassName : ""}>
         <Slider {...settings}>
           {data?.cardsCollection?.items?.map((partner: any, key: any) => {
           const description = documentToPlainTextString(partner?.description?.json)
           return <div key={key}>
                   <div className="partnerSlickSlide partnerWithIcon">
                     <div className="partnerIcon">
                 <ImageConversion
                    url={partner?.cardImage?.url}
                    altext={partner?.cardImage?.title}
                 />
                 
                 </div>
               {partner?.showTitle ? <strong> {parse(partner?.title)} </strong> : ""}
               
               {description ? <span> {parse(description)}</span> : ""}
                   </div>
               </div>
            })
       }
             </Slider>
         </div>
            </OurPartnerPanel>
       }) : null
    }
    
    {service?.seoEnhance && service?.seoEnhance?.map((data: any, key: any) => {
      const description = data?.descriptionBottom;
      const title = data?.title;
      const mobileSectionImage = data?.mobileSectionImage?.url;
      const mobileSectionImageALt = data?.mobileSectionImage?.title;
      const sectionImage = data?.sectionImage?.url;
      const sectionImageAlt = data?.sectionImage?.title;
      {
       return description ? <SeoEnhance
         title={title}
         customClass={`enhance-${pageClass}`}
          subtitle={service?.seoEnhance[0]?.subtitle}
          description={description}
          singleBannerImageURL={sectionImage}
          singleBannerMobImageURL={mobileSectionImage}
          singleBannerImageAlt={sectionImageAlt}
          singleBannerMobImageAlt={mobileSectionImageALt}
        /> : ""
      }
    })
    }    

{
      service?.cardGridRight.length > 0 ? service?.cardGridRight?.map((card: any, key: any) => {
        const index = key + 1;
        let position = true
        if (card?.imagePosition) {
          position = false;
        }
        else {
          position = true
        }
                 let data:any = [];
                 card?.cardsCollection?.items?.map((singleCard: any, key: any) => {
                      data.push({title:singleCard?.title,desc:documentToPlainTextString(singleCard?.description?.json),titleShow :singleCard?.showTitle})
                 })
                 const flexColumns = card?.flexibleColumns
                 let childrenDataTwo = {
                      imageUrl: card?.image?.url,
                      imageAlt: card?.image?.title,
                      title: card?.title,
                      desc: documentToPlainTextString(card?.description?.json),
                      data
                 };
     return <CardGrid sectionClass={`cardGridRight${index} ${card?.customClassCardGrid}`} key={key} cardData={childrenDataTwo} reverse={position} flexibleCol={flexColumns} />
       }) : null }   
                       
  {
   service?.cardGridTagline.length > 0 ? service?.cardGridTagline?.map((card: any, key: any) => {
     const index = key + 1;
     let position = true
     if (card?.imagePosition) {
       position = false;    
     }
     else {
       position = true
     }
     const tagLine = card?.tagLine;
     const enable = card?.enableTagline;
     const flexColumns = card?.flexibleColumns;
                 let data:any = [];
                 card?.cardsCollection?.items?.map((singleCard: any, key: any) => {
                      data.push({title:singleCard?.title,desc:documentToPlainTextString(singleCard?.description?.json),titleShow :singleCard?.showTitle})
                 })
                 let childrenDataTwo = {
                      imageUrl: card?.image?.url,
                      imageAlt: card?.image?.title,
                      title: card?.title,
                      desc: documentToPlainTextString(card?.description?.json),
                      data
                 };
     return  <CardGrid
     sectionClass={'cardGridRight-'+index}
     key={key} 
     cardData={childrenDataTwo}
     flexibleCol={flexColumns}
     bottomTagLine={enable}
     reverse={position}
     tagline={tagLine}
   />
   }) : null}       

{  service?.cardGridNumber.length > 0 ? service?.cardGridNumber?.map((card: any, key: any) => {
     let data: any = [];
     let index = key+1
     let position = false;
           if (card?.imagePosition) {
             position = false;    
           }
           else {
             position = true
           }
           const tagLine = card?.tagLine;
           const enable = card?.enableTagline;
           const flexColumns = card?.flexibleColumns
                       card?.cardsCollection?.items?.map((singleCard: any, key: any) => {
                            data.push({title:singleCard?.title,desc:documentToPlainTextString(singleCard?.description?.json),icon: key+1,titleShow :singleCard?.showTitle})
                       })
                       let childrenDataTwo = {
                            imageUrl: card?.image?.url,
                            imageAlt: card?.image?.title,
                            title: card?.title,
                            desc: documentToPlainTextString(card?.description?.json),
                            data
                       };
           return  <CardGrid
           sectionClass={'topCardGrid-'+index}
           key={key} 
           cardData={childrenDataTwo}
           flexibleCol={flexColumns}
           bottomTagLine={enable}
           reverse={position}
           tagline={tagLine}
           />
   }) : null} 

{
   service?.cardInfoGridNumber.length > 0 ? service?.cardInfoGridNumber?.map((card: any, keyindex: any) => {
     let position = true
     if (card?.imagePosition) {
       position = false;    
     }
     else {
       position = true
     }
     let data:any = [];
     card?.cardsCollection?.items?.map((singleCard: any, key: any) => {
           data.push({title:singleCard?.title,desc:documentToPlainTextString(singleCard?.description?.json), icon: key+1,})
     })
     let expertsData = {
           imageUrl: card?.image?.url,
           imageAlt: card?.image?.title,
           title: card?.title,
           desc: documentToPlainTextString(card?.description?.json),
           data
     };
     return <ImageCardPin key={keyindex} cardData={expertsData} />
   }) : null
 }

{service?.ourPartnersBottom.length > 0 ? <OurPartnerPanel>
         <Slider {...ourPartnerBottom}>
         {service?.ourPartnersBottom[0]?.cardsCollection?.items?.map((partner: any,key:any) => {
                  let button = "";
           if (partner.showTitle) {
             button =  "<span>"+partner?.title+"</span>"
           } else {
             button = "";
           }
         return <div key={key}>
               <div className="partnerSlickSlide partnerWithIcon">
             <div className="partnerIcon">
             <ImageConversion
              url={partner?.cardImage?.url}
              altext={partner?.cardImage?.title}
              />
             </div>
                 {parse(button)}
               </div>
               </div>
           })}
             </Slider>
            </OurPartnerPanel> : null
       }

       {service?.middleSingleBanner.length > 0 ? <SingleBanner
          singleBannerImageURL={service?.middleSingleBanner[0]?.image?.url}
          singleBannerImageAlt={service?.middleSingleBanner[0]?.image?.title}
          singleBannerMobImageURL={service?.middleSingleBanner[0]?.image?.url}
        /> : null}

         {service?.contactSectionCenter.length > 0 ? <ContactTeamPanel
            description={service?.contactSectionCenter[0]?.subTitle}
            ctatext={service?.contactSectionCenter[0]?.buttonText}
            ctaUrl ={service?.contactSectionCenter[0]?.buttonUrl}
          /> : null}

{ service?.ourClients.length > 0 ? <ServicesProductSlider sliderHeading={service?.ourClients[0]?.title}>
            <CommonSlider
                 settings={{
                 infinite: false,
                 slidesToShow: 3.5,
                 slidesToScroll: 1,
                 adaptiveHeight: true,
                 responsive: [
                 {
                      breakpoint: 1199,
                      settings: {
                      slidesToShow: 2.5,
                      },
                 },
                 {
                      breakpoint: 767,
                      settings: {
                      slidesToShow: 1.7,
                      },
                 },
                 {
                      breakpoint: 575,
                      settings: {
                      slidesToShow: 1,
                      },
                 },
                 ],
                 }}
                 className="cardCarouselProduct">
        {service?.ourClients[0]?.cardsCollection?.items?.map((section: any, key: any) => {
          const desc = documentToPlainTextString(section?.description?.json);
          let customModalData:any = [];
          customModalData.push({ image: `/api/images/${removeBaseUrl(section?.cardImage?.url)}`, buttonText: section?.popupButtonText, buttonUrl: section?.popUpButtonUrl, description: section?.popupDescription });     
          return <div className="ourProductCard" key={key}>
                                <div>
              <div className="cardIconBox">
              <ImageConversion url={section?.cardImage?.url} altext={section?.cardImage?.title} />
                                     </div>
                                    <h5>{section.title}</h5>
                                     <p>
                                       {parse(desc)}
                                     </p>
                                     
                                  {/* <span className="arrow-icon" data-modal={JSON.stringify(customModalData)} onClick={toggle} tabIndex={0}>
                                         {section?.buttonText ? section?.buttonText :
                                         "Read More"}
                                          <span>
                                               <Image
                                                    src="/images/right-arrow.svg"
                                                    fill
                                                    priority
                                                    alt="right arrow"
                                               />
                                          </span>
                                     </span>  */}
                                </div>
                           </div>
                 
                      })}
                     </CommonSlider>
                     </ServicesProductSlider>    : null 
       }

       {service?.servicesBottomPanel.length > 0 ? <ServicesBottomPanel
          teamContactDesc={service?.servicesBottomPanel[0]?.subTitle}
          ctaText={service?.servicesBottomPanel[0]?.buttonText}
          ctaUrl ={service?.servicesBottomPanel[0]?.buttonUrl}
    /> : null}
    <Modal showModal={showModal} toggle={toggleModal} modalData={modalData} />
    
    {service?.ServiceTiles.length > 0 ? 
      <ServicesExternalTile CardsData={service?.ServiceTiles[0]?.cardsCollection?.items} />
      : null}
    
    <div className="blueCircle">
        <Image
          src="/images/bottomGradient.png"
          alt="bottomOrangeBlueradient"
          fill
          priority
        />
    </div>         
  </div>
}

export default Services;
export async function getStaticProps(context: any) {
     const slug = context.params.slug;
     const singleService = await getSingleServicePagenew(slug);
     const results = singleService?.singleServiceCollection?.items; 
     const data = singleService?.singleServiceCollection?.items[0]?.sectionsCollection?.items;
     const topBanner = data.filter((data: any) => data?.tag === "topSectionImage")
     const seoEnhance = data.filter((data: any) => data?.tag === "enhancePanel")
     const belowSingleBanner = data.filter((data: any) => data?.tag === "belowBannerSection")
     const contactTeamPanel = data.filter((data: any) => data?.tag === "topContactSectiom")
     const topCardGrid = data.filter((data: any) => data?.tag === "topCardGrid")
     const servicesBottomPanel = data.filter((data: any) => data?.tag === "contactSectionBottom")
     const ourClients = data.filter((data: any) => data?.tag === "ourClients")
     const contactSectionCenter = data.filter((data: any) => data?.tag === "contactSectionCenter")
     const middleSingleBanner = data.filter((data: any) => data?.tag === "middleSingleBanner")
     const ourPartnersBottom = data.filter((data: any) => data?.tag === "ourPartnersBottom")
     const cardInfoGridNumber = data.filter((data: any) => data?.tag === "cardInfoGridNumber")
     const cardGridNumber = data.filter((data: any) => data?.tag === "cardGridNumber")
     const cardGridTagline = data.filter((data: any) => data?.tag === "cardGridTagline")
     const cardGridRight = data.filter((data: any) => data?.tag === "cardGridRight")
     const socialMediaPartner = data.filter((data: any) => data?.tag === "socialMediaPartner")
     const ourPartnersWithTitle = data.filter((data: any) => data?.tag === "ourPartnersWithTitle")
     const ourPartners = data.filter((data: any) => data?.tag === "ourPartnersSection")

     const ServiceTiles = data.filter((data: any) => data?.tag === "bottomServiceCardSection")
      if(!results || results.length === 0) {
        return {
          notFound: true,
        };
      }

     return {
       props: {
         singleService,
         topBanner,
         seoEnhance,
         belowSingleBanner,
         contactTeamPanel,
         topCardGrid,
         servicesBottomPanel,
         ourClients,
         contactSectionCenter,
         middleSingleBanner,
         ourPartnersBottom,
         cardInfoGridNumber,
         cardGridNumber,
         cardGridTagline,
         cardGridRight,
         socialMediaPartner,
         ourPartnersWithTitle,
         ourPartners,
         ServiceTiles

       },
       revalidate: 60
     };
}

export async function getStaticPaths() {
  const singleService = await allServicesHomePage();
  const paths = singleService?.singleServiceCollection?.items?.map((post:any) => ({
    params: { slug: post.slug },
  }))
  return { paths, fallback: 'blocking'  }
}