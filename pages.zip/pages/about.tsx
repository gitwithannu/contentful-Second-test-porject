/* eslint-disable @next/next/no-title-in-document-head */
import { AboutContact, PageImageBanner } from "@/src/components";
import WhatWeDone from "@/src/components/About/WhatWeDone";
import WhoWeWorkWith from "@/src/components/About/WhoWeWorkWith";
// import WhoWeAre from "@/src/components/About/WhoWeAre";
import CreatorTeam from "@/src/components/About/CreatorTeam";
import TeamSlider from "@/src/components/About/TeamSlider";
import BlowSingleBanner from "@/src/templates/BlowSingleBanner";
import ServicesBlowPanel from "@/src/components/Services/BlowInnerPanel";
import { Modal } from "@/src/components/Modal";
import { getAboutNew } from "@/utils/contentful";
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
import { documentToHtmlString } from "@contentful/rich-text-html-renderer";
import Image from 'next/image'
import Link from 'next/link'
import { WhatWeValue } from "@/src/components/About/WhatWeValue";
import Head from 'next/head';
import { useEffect } from "react";
import AboutLeadershipBio from "@/src/components/About/LeadershipBio";
import { useRouter } from "next/router";
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || '';
const About = (props: any) => {
  const allData = props?.aboutPage?.aboutUsModelCollection?.items;
  const filtered = allData.filter((singleData: any) => {
    return singleData.pageSlug === "about";
  });
  return filtered.map((section: any, key: any) => {
    const allSections = section.allSectionsCollection.items
    const metaTitle = section?.metaTitle;
    const metaDescription = section?.metaDescription;
    const metaIndex = section?.enableMetaIndex;
    const pageSlug = section?.pageSlug;
    const pageTitle = section?.pageName;
    const pageSubTitle = section?.subtitle;
    const bannerData = allSections.filter((data: any) => {
      return data.tag === "topBannerImage";
    });
    const belowSingleBanner = allSections.filter((data: any) => {
      return data.tag === "BelowTopSingleBanner";
    });
    const whatWeDoneAbout = allSections.filter((data: any) => {
      return data.tag === "whatWeDoneAbout";
    });
    const whoWorkWith = allSections.filter((data: any) => {
      return data.tag === "whoWorkWith";
    });
    const partnerSliderTwo = allSections.filter((data: any) => {
      return data.tag === "partnerSliderTwo";
    });
    const partnerSliderThree = allSections.filter((data: any) => {
      return data.tag === "partnerSliderThree";
    });
    // const whoWeAre = allSections.filter((data: any) => {
    //   return data.tag === "whoWeAreSection";
    // });
    const aboutTeamSlider = allSections.filter((data: any) => {
      return data.tag === "aboutTeamSlider";
    });
    const leadershipBio = allSections.filter((data: any) => {
      return data.tag === "leadershipBio";
    });
    const aboutCreativeTeam = allSections.filter((data: any) => {
      return data.tag === "aboutCreativeTeam";
    });
    const aboutContactSectiom = allSections.filter((data: any) => {
      return data.tag === "aboutContactSectiom";
    });
    const aboutValue = allSections.filter((data: any) => {
      return data.tag === "aboutValue";
    });
    return (
      <div key={key} className="aboutMain">
         <Head>
          <title>{metaTitle ? metaTitle : "TRU AGENCY"}</title>
          {metaIndex && metaIndex != null ?
             <meta name="robots" content="index, follow" />
            :
             <meta name="robots" content="noindex, nofollow" />
          }
        <meta
          name="description"
          content={metaDescription ? metaDescription : "TRU AGENCY"}
          key="desc"
          />
          <link rel="canonical" href={`${BASE_URL}/${pageSlug}`} />
          <script type="application/ld+json" dangerouslySetInnerHTML={{
          __html: `{
            "@context": "https://schema.org",
            "@type": "Corporation",
            "name": "Tru",
            "description": "We're an award-winning digital consulting agency based in Toronto, Canada specializing in website design, web development, e-commerce, and data-backed SEO.",      
            "legalName": "Tru Inc.",
            "url": "${BASE_URL}",
            "logo": "${BASE_URL}/images/tru-logo-white.jpg",
            "email": "support@tru.agency",   
            "sameAs": [
              "https://www.facebook.com/truincorp/",
              "https://twitter.com/Tru_Inc",
              "https://www.instagram.com/tru_inc/",
              "https://www.linkedin.com/company/truinc"
            ]
          }`
          }} />
          
          <script type="application/ld+json" dangerouslySetInnerHTML={{
          __html: `{
            "@context": "https://schema.org/", 
            "@type": "BreadcrumbList",
            "name": "BreadcrumbList",
            "itemListElement": [{
              "@type": "ListItem", 
              "position": 1, 
              "name": "Home",
              "item": "${BASE_URL}"  
            },{
              "@type": "ListItem", 
              "position": 2, 
              "name": "About",
              "item": "${BASE_URL}/about"  
            }]
          }`
          }} />  

          
      </Head>  
        {
          bannerData.map((data: any, key: any) => {
            return (
              <PageImageBanner key={key}
                title={pageTitle}
                subtitle={pageSubTitle}
                bg={data?.image?.url}
                bgAlt={data?.image?.title}
                goBackName={`Home`}
                goBackUrl={`/`}
                showHide={true}
                shadowHide={false}
              />
            )
          })
        }
        {
          belowSingleBanner.map((data: any, key: any) => {
            return (
              <BlowSingleBanner key={key} customClass="aboutBanner">
                <ServicesBlowPanel
                  bannerHeading={data.title}
                  bannerSubHeading={data.subTitle}
                  bannerDescription={documentToPlainTextString(data.description.json)}
                />
              </BlowSingleBanner>
            )
          }
          )
        }

        <div className="about--gradient">
          {
            whatWeDoneAbout.map((data: any, key: any) => {
              return (
                <WhatWeDone key={key} sectionData={JSON.stringify(data)} />
              )
            })
          }
          {
            aboutContactSectiom.map((data: any, key: any) => {
              return (
                <AboutContact key={key} enableButton={data?.enableButton} buttonText={data?.buttonText} buttonUrl={data?.buttonUrl} title={data?.subTitle} />
              )
            })
          }
        {
          whoWorkWith?.map((data: any, key: any) => {
            const sliderTwo= partnerSliderTwo[0]?.cardsCollection?.items;
            const sliderThree= partnerSliderThree[0]?.cardsCollection?.items;
            return (
              <WhoWeWorkWith key={key} customImageUrl={data?.image?.url} customImageTitle={data?.image?.title} imagesData={JSON.stringify(data)} slideTwo={JSON.stringify(sliderTwo)} slideThree={JSON.stringify(sliderThree)} />
            )
          })
        }
         {
          aboutTeamSlider?.map((data: any,key:any) => {
              return (
                <TeamSlider key={key} teamMembers={JSON.stringify(data?.cardsCollection?.items)} />
              )
         }) 
          }
          {
            leadershipBio?.map((data: any, key: any) => {
              return (
                <AboutLeadershipBio  key={key} title={data?.title} dataMembers={JSON.stringify(data?.cardsCollection?.items)} />
              )
         }) 
          }
          
          
          
        </div>
       
        {
          aboutValue?.map((data: any, key: any) => {
              return (
                <WhatWeValue key={key} title={data?.title} columnData={JSON.stringify(data?.cardsCollection?.items)} />
              )
         }) 
        }
        {
          aboutCreativeTeam?.map((data: any, key: any) => {
            const title = data?.title;
            const description = data?.description?.json;
            const gridImages = data?.cardsCollection?.items;
            const buttonText = data?.buttonText;
            const buttonUrl = data?.buttonUrl;
            return (
              <CreatorTeam key={key} title={title} description={documentToPlainTextString(description)} gridImages={JSON.stringify(gridImages)} buttonText={buttonText} buttonUrl={buttonUrl} />
            )
          })
        }
      </div>
    )
  });
}

export default About;

export async function getStaticProps(context: any) {
  const aboutPage = await getAboutNew();
  return {
    props: {
      aboutPage,
    },
    revalidate: 60
  };
}