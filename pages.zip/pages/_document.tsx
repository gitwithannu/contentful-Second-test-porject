import { Html, Head, Main, NextScript } from 'next/document'
import Script from 'next/script'
export default function Document() {
  const environment = `${process.env.NEXT_PUBLIC_CONDITION}`;
  return (
    <Html lang="en">
      <Head>
      </Head>
      <body>
        <Main />
        <NextScript />
        <div id="portal" />
        {environment == 'true' && (
          <>
          <script
                id="usersnap-1"
                defer
                src="https://widget.usersnap.com/load/55b35694-b765-4be8-abe8-fc91b140357e?onload=onUsersnapLoad"
              />
              <script
                id="usersnap-2"
                defer
                dangerouslySetInnerHTML={{
                  __html: `
                  window.onUsersnapLoad = function(api) {
                      // store the Usersnap api on the window, if case you want to use it in other contexts
                      window.Usersnap = api; 
                      api.init();
                  }         
                  `,
                }}
              />
          </>
        )}
      </body>
    </Html>
  )
}
