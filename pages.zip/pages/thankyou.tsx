import { PageBanner } from "@/src/components";
import Link from 'next/link'
import Image from 'next/image'
import parse from 'html-react-parser';
import Head from 'next/head';
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || '';
const Thankyou = () => {
    return (
        <div className="default-content thankyouPage">
            <Head>
                <meta name="robots" content="noindex, follow" />
                    <title>{`Thank You | TRU`}</title>
                    <meta
                    name="description"
                    content={`Thank you page`}
                    key="desc"
                    />
                <link rel="canonical" href={`${BASE_URL}/thankyou`} />
                <script type="application/ld+json" dangerouslySetInnerHTML={{
                __html: `{
                    "@context": "https://schema.org/", 
                    "@type": "BreadcrumbList",
                    "name": "BreadcrumbList",
                    "itemListElement": [{
                    "@type": "ListItem", 
                    "position": 1, 
                    "name": "Home",
                    "item": "${BASE_URL}"  
                    },{
                    "@type": "ListItem", 
                    "position": 2, 
                    "name": "Thank You",
                    "item": "${BASE_URL}/thankyou"  
                    }]
                }`
                    }} /> 
            </Head> 
            
         <PageBanner
            title={`Thank you`}
            className="hide-shadow"
        />
        <section className="paddingY128">
            <div className="container">
                <div className="row">
                        <div className="col-12 text-center">                             
                        <Image src="/images/blue-check.svg" alt="Blue check" width={160} height={160} />
                    <h3 className="thankyouPageHeading text-center">The form was submitted successfully.</h3>   
                    </div>
                </div>
            </div>     
         </section>
      </div>
) }
export default Thankyou;
