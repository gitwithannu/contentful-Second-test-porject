import { useRef, useState, useEffect, FormEvent } from "react";
import Image from "next/image";
import Link from "next/link";
import gsap from "gsap";
import { useIsomorphicLayoutEffect } from "@/utils/hooks/useIsomorphicLayoutEffects";
import { PageBanner, PageImageBanner } from "@/src/components";
import {
  getBlogsPosts,
  getBlogByCategory,
  getAllBlogCategory,
  getBlogPage,
  getCategoryFilterAndInput,
  getInputData,
} from "@/utils/contentful";
import { documentToPlainTextString } from "@contentful/rich-text-plain-text-renderer";
import BlowSingleBanner from "@/src/templates/BlowSingleBanner";
import ServicesBlowPanel from "@/src/components/Services/BlowInnerPanel";
import Head from "next/head";
import dynamic from "next/dynamic";
import { useRouter } from "next/router";
import Scrollbar from "smooth-scrollbar";

const ImageConversion = dynamic(
  () => import("@/src/components/ImageConversion/ImageConversion")
);
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || "";

const Blogs = (props: any) => {
  const router = useRouter();
  const blogPostRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLFormElement | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const [blogFiter, setblogFiter] = useState<boolean>(false);
  const [customFields, setCustomFields] = useState<any>();
  const [loading, setLoading] = useState(false);
  const [loadMore, setLoadMore] = useState(true);
  const [limit, setLimit] = useState<number>(6);
  const [loadMoreLimit, setLoadMoreLimit] = useState<number>(6);
  const [skip, setSkip] = useState<number>(6);
  const [pages, setPages] = useState<number>(1);
  const [customFieldsActive, setCustomFieldsActive] = useState<any>();
  const [selectAllText, setSelectAllText] = useState<any>(true);

  const toggle = () => {
    setblogFiter(!blogFiter);
  };
  const allCats = props?.getAllBlogCats?.blogPostsCollection?.items;

  let blogtab: any = [];
  allCats?.forEach((cat: any) => {
    cat?.categories?.forEach((single: any) => {
      blogtab.push({ title: single });
    });
  });
  
  let tempResult: any = {};
  blogtab.forEach(({ title }: any) => {
    tempResult[title] = {
      title,
      count: tempResult[title] ? tempResult[title].count + 1 : 1,
    };
  });
  
  let resultasd = Object.values(tempResult);
  
  // Convert resultasd to array of objects
  let arr = resultasd.map((obj: any) => obj);
  
  // Sort arr alphabetically by title
  arr.sort((a: any, b: any) => {
    // Use localeCompare for proper alphabetical sorting
    return a.title.localeCompare(b.title);
  });
     
  const [checkedArr, setCheckArr] = useState<any>([...arr]);
  const blogPosts = props?.blogPage?.blogPostsCollection?.items;
  const blogsLength = props?.blogPage?.blogPostsCollection?.total;

  let postData: any = [];
  var months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];
  let categories = "";
  function renderDate(date: any) {
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);
    if (date.toLocaleDateString() == today.toLocaleDateString()) {
      return "Today";
    } else if (date.toLocaleDateString() == yesterday.toLocaleDateString()) {
      return "Yesterday";
    }
    return date.toLocaleDateString("en-US", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });
  }

  const processedData = (blogPosts: any, reset = false) => {
    let postData: any = [];
    blogPosts?.map((section: any, index: any) => {
      categories = section?.categories;
      let category = "";
      if (categories != undefined) {
        category = categories[0];
      }
      let date = new Date(section.publishDate);
      var year = date.getFullYear();
      var month = months[date.getMonth()];
      var dateVal = date.getDate();
      let desc = documentToPlainTextString(section?.description?.json);
      const wpm = 180;
      const words = desc.trim().split(/\s+/).length;
      const time = Math.ceil(words / wpm);
      postData.push({
        image: section?.gridFeaturedImage?.url,
        altImage: section?.gridFeaturedImage?.title,
        title: section?.postTitle,
        category: category,
        postdate: renderDate(date),
        date: month + " " + dateVal + ", " + year,
        slug: "/blogs/" + section?.slug,
        readingTime: time,
      });
    });
    if (reset) {
      setPosts(postData);
      setSkip(6);
      setLoading(false);
    }

    return postData;
  };

  const [posts, setPosts] = useState<Array<any>>(processedData(blogPosts));
  const handleSubmit = async (e: any) => {
    e.preventDefault();
    setLoading(true);
    const inputFields = e.target?.querySelectorAll("input");
    const updatedCustomFields: string[] = [];
    inputFields.forEach((input: any) => {
      if (input.type === "checkbox" && input.checked) {
        updatedCustomFields.push(input.value);
      }
    });
    toggle();
    setCustomFields(updatedCustomFields);
    setSkip(0);
  };

  const loadMorePosts = async () => {
    try {
      const inputData = inputRef.current?.value;
      const req = await getCategoryFilterAndInput(
        customFields,
        inputData,
        skip,
        limit
      );
      const fetchedPosts = req?.blogPostsCollection?.items || [];
      const fetchedTotal =
        loadMoreLimit + skip < req?.blogPostsCollection?.total ? true : false;
      setLoadMore(fetchedTotal);
      setLoading(false);
      const data = processedData(fetchedPosts, false);
      setPosts((prevPosts) => [...prevPosts, ...data]);
    } catch (error) {
      console.error("Error loading more posts:", error);
    } finally {
      setSkip((prev) => prev + 6); // Ensure loading state is reset in both success and error cases
    }
  };

  const searchInputChange = async (e: any) => {
    setLoading(true);
    setPages(1);
    const searchInput = e.target.value;
    const req = await getCategoryFilterAndInput(customFields, searchInput, 0);
    const fetchedPosts = req?.blogPostsCollection?.items || [];
    const pageNo = req?.blogPostsCollection?.total / 6;
    const fetchedTotal = pages < Math.ceil(pageNo) ? true : false;
    setLoadMore(fetchedTotal);
    processedData(fetchedPosts, true);
  };
  const scrollToElement = () => {
    setTimeout(() => {
      const targetElement = document.querySelector(
        `#main-blog-section`
      ) as HTMLElement | null;
      if (targetElement) {
        let targetElementOffsetTop = 30;
        if (window.innerWidth <= 1199) {
          targetElementOffsetTop += 80;
        }
        const scrollbar = Scrollbar.init(
          document.querySelector(".scroller") as HTMLElement
        );
        if (scrollbar) {
          scrollbar.scrollIntoView(targetElement, {
            alignToTop: true,
            offsetTop: targetElementOffsetTop,
          });
        }
      }
    }, 600);
  };
  const selectedCategory = (
    category: any,
    formRef: React.RefObject<HTMLFormElement>
  ) => {
    if (typeof category === "string") {
      setTimeout(async () => {
        const arrayOfObjects = [category];
        try {
          const inputData = inputRef.current?.value;
          const req = await getCategoryFilterAndInput(
            arrayOfObjects,
            inputData,
            0,
            limit
          );
          const fetchedPosts = req?.blogPostsCollection?.items || [];
          const fetchedTotal =
            loadMoreLimit + skip < req?.blogPostsCollection?.total
              ? true
              : false;
          setLoadMore(fetchedTotal);
          setLoading(false);
          processedData(fetchedPosts, true);
          const allInputFields = formRef.current?.querySelectorAll(
            'input[type="checkbox"]'
          );
          allInputFields?.forEach((input) => {
            (input as HTMLInputElement).checked = false;
          });
          const textWithoutSpaces = category.replace(/\s/g, "_").toLowerCase();
          const inputFields = formRef.current?.querySelectorAll(
            `input[name="${textWithoutSpaces}"]`
          );
          const updatedCustomFields: string[] = [];
          inputFields?.forEach((inputField) => {
            const inputElement = inputField as HTMLInputElement;
            inputElement.checked = true;
            updatedCustomFields.push(inputElement.value);
          });
          setCustomFields(updatedCustomFields);
          scrollToElement();
        } catch (error) {
          console.error("Error fetching data:", error);
        }
      }, 1000);
    }
  };

  const selectAll = async () => {
    const inputFields = formRef.current?.querySelectorAll(
      'input[type="checkbox"]'
    );
    let allChecked = true;
    inputFields?.forEach((input: any) => {
      if (!input.checked) {
        allChecked = false;
        input.checked = true;
      }
    });
    if (allChecked) {
      inputFields?.forEach((input: any) => {
        input.checked = false;
      });
    }
    setCheckArr((prev: any) => {
      return prev?.map((elm: any) => {
        return { ...elm, check: !allChecked };
      });
    });
  };

  const changeCheckbox = (e: any, index: number) => {
    const newArr = [...checkedArr];
    newArr[index]["check"] = e.target.checked;
    setCheckArr(newArr);
  };

  const removeCategory = (e: React.MouseEvent<HTMLButtonElement>) => {
    setLoading(true);
    const category = e.currentTarget.getAttribute("data-cat");
    const inputFields = formRef.current?.querySelectorAll(
      `input[name="${category}"]`
    );
    inputFields?.forEach((inputField) => {
      const inputElement = inputField as HTMLInputElement;
      inputElement.checked = false;
    });
    const allInputFields = formRef.current?.querySelectorAll(
      `input[type="checkbox"]`
    );
    const updatedCustomFields: string[] = [];
    allInputFields?.forEach((input: any) => {
      if (input.type === "checkbox" && input.checked) {
        updatedCustomFields.push(input.value);
      }
    });
    setCustomFields(updatedCustomFields);
    setSelectAllText(true);
  };
     
  const clearFilter = () => {
     setLoading(true);
     const allInputFields = formRef.current?.querySelectorAll(
          'input[type="checkbox"]'
     );
     const updatedCustomFields: string[] = [];
        allInputFields?.forEach((input) => {
             (input as HTMLInputElement).checked = false;
             if ((input as HTMLInputElement).checked) {
               updatedCustomFields.push((input as HTMLInputElement).value);
             }
        });
        setCustomFields(updatedCustomFields);
        setSelectAllText(true);
  }

  useEffect(() => {
    processedData(blogPosts, true);
    const pageNo = blogsLength / 6;
    const fetchedTotal = pages < Math.ceil(pageNo) ? true : false;
    setPages((prev) => prev + 1);
    setLoadMore(fetchedTotal);
  }, []);

  useEffect(() => {
    const checked = checkedArr.every((obj: any) => obj?.check);
    if (checked) setSelectAllText(false);
    else if (!checked) setSelectAllText(true);
  }, [checkedArr]);

  useEffect(() => {
    setPages(1);
    const fetchData = async () => {
      setTimeout(async () => {
        const inputData = inputRef.current?.value;
        const req = await getCategoryFilterAndInput(
          customFields,
          inputData,
          0,
          limit
        );
        const fetchedPosts = req?.blogPostsCollection?.items || [];
        // const fetchedTotal = (loadMoreLimit + skip) < req?.blogPostsCollection?.total ? true : false
        const pageNo = req?.blogPostsCollection?.total / 6;
        const fetchedTotal = pages < Math.ceil(pageNo) ? true : false;
        setLoadMore(fetchedTotal);
        setLoading(false);
        processedData(fetchedPosts, true);
      }, 1000);
    };
    setCustomFieldsActive(customFields || []);
    fetchData();
  }, [customFields]);

  useEffect(() => {
    const handleRouteChangeComplete = () => {
      const category = router.query.cat;
      selectedCategory(category, formRef);
    };
    if (router.isReady) {
      const category = router.query.cat;
      selectedCategory(category, formRef);
    }
    router.events.on("routeChangeComplete", handleRouteChangeComplete);
    return () => {
      router.events.off("routeChangeComplete", handleRouteChangeComplete);
    };
  }, [router]);

  const allData = props?.getBlogPageData?.blogPageCollection?.items;
  const filtered = allData?.filter((singleData: any) => {
    return singleData.pageSlug === "blogs";
  });

  return filtered?.map((section: any, key: any) => {
    const allSection = section?.sectionCollection?.items;
    const metaTitle = section?.metaTitle;
    const metaDescription = section?.metaDescription;
    const metaIndex = section?.enableMetaIndex;
    const blogSection = allSection.filter((data: any) => {
      return data.tag === "blogSection";
    });

    return (
      <div key={key}>
        <Head>
          <title>{metaTitle ? metaTitle : "TRU AGENCY"}</title>
          {metaIndex && metaIndex != null ? (
            <meta name="robots" content="index, follow" />
          ) : (
            <meta name="robots" content="noindex, nofollow" />
          )}
          <meta
            name="description"
            content={metaDescription ? metaDescription : "TRU AGENCY"}
            key="desc"
          />
          <link rel="canonical" href={`${BASE_URL}/${section?.pageSlug}`} />

          <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{
              __html: `{
                  "@context": "https://schema.org/", 
                  "@type": "BreadcrumbList",
                  "name": "BreadcrumbList",
                  "itemListElement": [{
                    "@type": "ListItem", 
                    "position": 1, 
                    "name": "Home",
                    "item": "${BASE_URL}"  
                  },{
                    "@type": "ListItem", 
                    "position": 2, 
                    "name": "${section?.pageName}",
                    "item": "${BASE_URL}/${section?.pageSlug}"  
                  }]
                }`,
            }}
          />
        </Head>
        <PageImageBanner
          title={section?.pageName}
          subtitle={section?.subtitle}
          bg={section?.topBanner?.url}
          bgAlt={section?.topBanner?.title}
          className="blogPageHeader"
          goBackName="Home"
          goBackUrl="/"
        />
        {blogSection?.map((data: any, key: any) => {
          return (
            <BlowSingleBanner key={key} customClass="aboutBanner">
              <ServicesBlowPanel
                bannerHeading={data?.title}
                bannerSubHeading={data?.subTitle}
                bannerDescription={documentToPlainTextString(
                  data?.description?.json
                )}
              />
            </BlowSingleBanner>
          );
        })}
        {/* <!--Blogs start Here--> */}
        <section className="blogsPin" ref={blogPostRef}>
          <section
            className="latestestStudioMain paddingY128 Blog"
            id="main-blog-section"
          >
            <div className="container latestStudioInner">
              <div className="row b-filter-tab-row">
                <div className="blog-filter-col">
                  <div className="b-fiter-list-col">
                    <h6 className="b-filter-by-text">Filter by:</h6>
                    <div className="b-filter-list-con">
                      <div className="b-filter-selected-cat" onClick={toggle}>
                        Select Category{" "}
                        <span className="icon-down-arrow"></span>
                      </div>
                      <div
                        className={`b-filter-list-outer ${
                          blogFiter ? "active" : ""
                        }`}
                      >
                        <form
                          ref={formRef}
                          onSubmit={handleSubmit}
                          encType="multipart/form-data"
                        >
                          <ul className="b-filter-list">
                            <li>
                              <span className="b-filter-select-head">
                                Categories
                              </span>
                              <ul className="b-filter-list-group">
                                {arr?.map((el: any, key: any) => {
                                  const textWithoutSpaces = el?.title
                                    .replace(/\s/g, "_")
                                    .toLowerCase();
                                  return (
                                    <>
                                      <li>
                                        <input
                                          id={`${textWithoutSpaces}`}
                                          type="checkbox"
                                          value={el.title}
                                          name={textWithoutSpaces}
                                          className="b-filter-checkbox"
                                          onChange={(e) =>
                                            changeCheckbox(e, key)
                                          }
                                        />
                                        <label htmlFor={`${textWithoutSpaces}`}>
                                          {el.title}
                                        </label>
                                      </li>
                                    </>
                                  );
                                })}
                              </ul>
                            </li>
                            <li>
                              <span
                                className="b-filter-select-all"
                                onClick={selectAll}
                              >
                                {selectAllText ? "Select All" : "Unselect All"}
                              </span>
                              <button
                                className="b-filter-selected-apply"
                                type="submit"
                              >
                                Apply
                              </button>
                            </li>
                          </ul>
                        </form>
                      </div>
                    </div>
                  </div>
                  <div className="b-fiter-search-col">
                    <input
                      ref={inputRef}
                      name="blog-search"
                      type="text"
                      placeholder="Search"
                      className="b-fiter-search-box"
                      onChange={searchInputChange}
                    />
                    <button className="searchButton">
                      <span className="icon-search-1"></span>
                    </button>
                  </div>
                </div>
                <div className="blog-filter-col">
               {customFieldsActive?.length > 0 && <ul className="active-filter">
                    <li>Active Filter:</li>
                    {customFieldsActive?.map((data: any, index: any) => {
                         const textWithoutSpaces = data
                              .replace(/\s/g, "_")
                              .toLowerCase();
                         return (
                              data && (
                                   <li className="selectedFilters" key={index} data-category={textWithoutSpaces}>
                                        {data}{" "}
                                        <span
                                             data-cat={textWithoutSpaces}
                                             onClick={removeCategory}
                                             className="icon-cancel"
                                        ></span>
                                   </li>
                              )
                         );
                    })}
                    <li className="selectedFilters clearAll" onClick={clearFilter}>Clear All</li>
               </ul>
               }
                </div>
              </div>
              {loading ? (
                <div className="loading-job-list paddingY128">
                  <Image
                    src="/images/icons/loading.svg"
                    alt="loading-image"
                    width="200"
                    height="200"
                  />
                </div>
              ) : (
                <div className="row rightPanel paddingT64">
                  {posts?.map((item: any, key: any) => {
                    return (
                      <div className="col-4 col-12-sm boxes" key={key}>
                        <div className="newsPanel blog-1">
                          <div className="newsHeader">
                            <Link href={item?.slug}>
                              <h4>{item?.title}</h4>
                            </Link>
                          </div>
                          <div className="newsBody">
                            <div className="newsNav">
                              <ul>
                                {item?.category ? (
                                  <li>{item?.category}</li>
                                ) : (
                                  <li className="emptyNav"></li>
                                )}
                                <li>{item?.date}</li>
                                <li>{item?.readingTime} mins read </li>
                              </ul>
                            </div>
                            <div className="newsImagePanel">
                              <Link href={item?.slug}>
                                <ImageConversion
                                  url={
                                    item?.image
                                      ? item?.image
                                      : "/images/blog/placeholder-desktop.png"
                                  }
                                  altext={
                                    item?.altImage
                                      ? item?.altImage
                                      : "Picture of Latest Post"
                                  }
                                />
                              </Link>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}

                  {loadMore && (
                    <div className="col-12-sm">
                      <div className="button loadMore">
                        <button
                          onClick={loadMorePosts}
                          className="globalButton"
                          aria-label="Click here to load more items"
                        >
                          Load More
                        </button>
                      </div>
                    </div>
                  )}

                  {!posts.length && (
                    <div className="col-12-sm">
                      <div className="button loadMore">
                        <span className="b-filter-noresult">
                          No result found
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </section>
        </section>
        {/* <!--Blogs end Here--> */}
      </div>
    );
  });
};
export default Blogs;

export async function getStaticProps(context: any) {
  const blogPage = await getBlogsPosts();
  const blogCategories = await getBlogByCategory();
  const getAllBlogCats = await getAllBlogCategory();
  const getBlogPageData = await getBlogPage();
  return {
    props: {
      blogPage,
      blogCategories,
      getAllBlogCats,
      getBlogPageData,
    },
    revalidate: 60,
  };
}