import Image from "next/image";
import { PageImageBanner } from "@/src/components";
import { getSingleBlogPage,getAllBlogsPost,getAsset,getEntry } from "@/utils/contentful";
import { documentToPlainTextString } from '@contentful/rich-text-plain-text-renderer';
import { documentToReactComponents } from '@contentful/rich-text-react-renderer';
import { BLOCKS, INLINES, MARKS } from '@contentful/rich-text-types';
import parse, { domToReact } from 'html-react-parser';
import Link from "next/link";
import Head from 'next/head';
import dynamic from "next/dynamic";
import { useEffect,useState } from 'react';
import Scrollbar from 'smooth-scrollbar';
import SmoothScroller from "@/src/components/SmoothScroller";
import EmbeddedEntryComponent from "@/src/components/EmbeddedEntryComponent";
import useWindowSize from '@/utils/hooks/useWindowSize';
import React from "react";
const ImageConversion = dynamic(() => import('@/src/components/ImageConversion/ImageConversion'))
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || '';
const isHtmlTag = (text:any) => /<\/?[a-z][\s\S]*>/i.test(text);

const BlogDetails = (props: any) => {
  const { width } = useWindowSize();
  let imagesUrl: string[] = [];
  const singleBlog = props?.singleBlog?.blogPostsCollection?.items;
  const origin =
        typeof window !== 'undefined' && window.location.origin
            ? window.location.origin
            : '';

    const URL = `${origin}`;
    
  function renderDate(date:any) {
    const today = new Date
    const yesterday = new Date; yesterday.setDate(today.getDate() - 1)
    if(date.toLocaleDateString() == today.toLocaleDateString()){
      return 'Today'
    }else if (date.toLocaleDateString() == yesterday.toLocaleDateString()) {
      return 'Yesterday'
    }
    return date.toLocaleDateString('en-US', {
      day : 'numeric',
      month: 'long',
      year: 'numeric'
    })
  }
  
  const onBtnClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const target = e.target as HTMLButtonElement;
    const dataId = target.getAttribute('data-id');
    const targetElement = document.querySelector('#' + dataId) as HTMLElement | null;
    let targetElementOffsetTop =30
    if (targetElement) {
      const scrollbar = Scrollbar.get(document.querySelector('.scroller') as HTMLElement);
      if (scrollbar) {
          targetElementOffsetTop += 80; 
        scrollbar.scrollIntoView(targetElement, {
          alignToTop: true,
          offsetTop: targetElementOffsetTop,
        });
      } 
    } 
  };

  function renderOptions(links:any) {
    const assetMap = new Map();
    for (const asset of links.assets.block) {
      assetMap.set(asset.sys.id, asset);
    }
    const entryMap = new Map();
    for (const entry of links.entries.block) {
      entryMap.set(entry.sys.id, entry);
    }
    return {
      renderNode: {
        [BLOCKS.TABLE]:(node:any, children:any) => {
          return (
            <div className="custom-table-container">
             <SmoothScroller>
                <table className="custom-table-class">{children}</table>
              </SmoothScroller>
            </div>
          );
        },
        [BLOCKS.EMBEDDED_ENTRY]: (node:any, children:any) => {
          const entry = entryMap.get(node.data.target.sys.id);
         return <EmbeddedEntryComponent data={node} entry={entry} />
        },
        [BLOCKS.PARAGRAPH]: (node: any, children: any) => {
          let containsHtml = false;
          let newChildren = children;
          let paragraphContent = '';
          node.content.forEach((childNode:any) => {
            if (childNode.nodeType === 'text' && isHtmlTag(childNode.value)) {
              containsHtml = true;
            }
            paragraphContent += childNode.value;
          });
          if (containsHtml) {
            return parse(paragraphContent);
          }
          return <p>{newChildren}</p>;
        },
        [BLOCKS.EMBEDDED_ASSET]: (node:any, children:any) => {
          const asset = assetMap.get(node.data.target.sys.id);
          imagesUrl.push(`"${asset?.url}"`)
          return (
            <div className="singleImage">
              <ImageConversion url={asset?.url} altext={asset?.title} />
              {asset?.description && <div className="img-src-text">{parse(asset?.description)}</div>}

            </div>
          );
        },
      },
    };
  }
  return (
    <div>
      {
        singleBlog.map((data: any, index: any) => {
          const linkedEntries = data?.description?.links;
          let categoryName = data?.categories?.slice(0, 1);
          let date = new Date(data?.publishDate);
          const isoTimestamp = date.toISOString().replace('Z', '+08:00');
          const wpm = 180;
          const words = documentToPlainTextString(data?.description?.json).trim().split(/\s+/).length;
          const time = Math.ceil(words / wpm);
          const metaTitle = data?.metaTitle;
          const metaIndex = data?.enableMetaIndex;
          const metaDescription = data?.metaDescription;
          const enabelFeaturedImage = data?.enableFeaturedImage;
          const authorDetails = [{ category: categoryName, time: time, date: renderDate(date) }];
          {
            data?.featuredImage?.url && (
              imagesUrl.push(`"${data?.featuredImage?.url}"`)
            )
          }
          const imagesArray = imagesUrl;
          const renderedContent = documentToReactComponents(data?.description?.json, renderOptions(linkedEntries));

          return (
            <div key={index} className={`serviceDetails blogSinglePost ${enabelFeaturedImage ? ' ' : 'blogWithoutImg'}`}>
               <Head>
                    <title>{metaTitle ? metaTitle : "TRU AGENCY"}</title>
                    {metaIndex && metaIndex != null ?
                        <meta name="robots" content="index, follow" />
                        :
                        <meta name="robots" content="noindex, nofollow" />
                    }
                  <meta
                    name="description"
                    content={metaDescription ? metaDescription : "TRU AGENCY"}
                    key="desc"
                />
                <link rel="canonical" href={`${BASE_URL}/blogs/${data?.slug}`} />
                <meta property="og:image" content={data?.featuredImage?.url} />
                <meta property="og:image:width" content="1600" />
                <meta property="og:image:height" content="400" />
                <script type="application/ld+json" dangerouslySetInnerHTML={{
                __html: `{
                      "@context": "https://schema.org/", 
                      "@type": "BreadcrumbList",
                      "name": "BreadcrumbList",
                      "itemListElement": [{
                        "@type": "ListItem", 
                        "position": 1, 
                        "name": "Home",
                        "item": "${BASE_URL}"  
                      },{
                        "@type": "ListItem", 
                        "position": 2, 
                        "name": "Blogs",
                        "item": "${BASE_URL}/blogs"  
                      },
                      {
                        "@type": "ListItem", 
                        "position": 3, 
                        "name": "${data?.postTitle}",
                        "item": "${BASE_URL}/blogs/${data?.slug}"  
                      }]
                    }`
                }} />  
                  <script type="application/ld+json" dangerouslySetInnerHTML={{
                    __html: `{
                    "@context": "https://schema.org",
                    "@type": "Article",
                    "headline": "${data?.postTitle}",
                    "image": [${imagesArray.map(url => `${url}`).join(',')}],
                    "datePublished": "${isoTimestamp}"
                 }`}} />
                </Head>  
          <PageImageBanner
            title={data?.postTitle}
            bg={data?.featuredImage?.url}
            postDesc={true}
            enablefeaturedImage={enabelFeaturedImage}
            authorDetails ={JSON.stringify(authorDetails)}
            goBackUrl="/blogs/"
            goBackName ="blog"
              />
              
            <section className={`blogPageSingleMain paddingY128 ${enabelFeaturedImage ? 'paddingY128' : ''}`}>
            <div className="container blog-page-contatiner">
              <div className="row">
                <div className="col-3 col-12-sm scrollbar-container">
                  <div className="blogPageSideBar sticky-section">
                    <h2 className="blogSideBarHeading"> Table of contents </h2>
                    <div className="blogSideBarList ">
                    <ul className="list-items">
                    {data?.tableOfContents?.map((contentTable: any, index: number) => (
                      <React.Fragment key={index}>
                        <li key={`parent-${index}`}>
                          <Link 
                            data-id={`table-content-${index + 1}`} 
                            href={`#${contentTable.id}`} 
                            onClick={onBtnClick} 
                            aria-label={contentTable.label}
                          >
                            {contentTable.label}
                          </Link>
                        </li>
                        {contentTable?.children && (
                          <ul className="list-items list-item-children">
                            {contentTable.children.map((childTable: any, count: number) => (
                              <li key={`child-${index}-${count}`}>
                                <Link 
                                  data-id={`table-content-${index + 1}-${count + 1}`} 
                                  href={`#${childTable.id}`} 
                                  onClick={onBtnClick} 
                                  aria-label={childTable.label}
                                >
                                  {childTable.label}
                                </Link>
                              </li>
                            ))}
                          </ul>
                        )}
                      </React.Fragment>
                    ))}
                  </ul>
                    </div>
                    <div className="sharePost">
                      <div className="sharePostHeading"> Share: </div>
                      <div className="sharePostIcons">
                        <ul>
                              <li>
                                
                            <Link
                                  href={`https://www.facebook.com/sharer/sharer.php?u=${URL}/blogs/${data?.slug}`}
                                  className="facebook dFlex"
                                  aria-label="Facebook"
                                  target ="_blank"
                            >
                              <span className="demo-icon icon-facebook"></span>
                            </Link>
                          </li>
                          <li>
                            <Link
                                  href={`https://twitter.com/intent/tweet?text="${data?.excerpt}"`}
                              className="twitter dFlex"
                                  aria-label="Twitter"
                                  target ="_blank"
                            >
                              <span className="demo-icon icon-twitter-1"></span>
                            </Link>
                          </li>
                          <li>
                            <Link
                              href={`https://www.linkedin.com/shareArticle?url=${URL}/blogs/${data?.slug}&title=${data?.postTitle}`}
                              className="linkedin dFlex"
                              aria-label="Linkedin"
                              target ="_blank"
                              >
                              <span className="demo-icon icon-linkedin-logo-svgrepo-com-1"></span>
                            </Link>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-9 col-12-sm customContainer">
                      <div className="blogPageContentInner paddingB128">
                        {renderedContent}
                  </div>
                </div>
              </div>
            </div>
              </section>
          </div>
          )
        }
        )}
    </div>
    
  );
};

export default BlogDetails;
export async function getStaticProps(context: any) {
  const slug = context.params.slug;
  const singleBlog = await getSingleBlogPage(slug);
  const results = singleBlog?.blogPostsCollection?.items;
  if(!results || results.length === 0) {
    return {
      notFound: true,
    };
  }
  return {
    props: {
      singleBlog,
    },
    revalidate: 60
  };
}

export async function getStaticPaths() {
  const singlePost = await getAllBlogsPost();
  const paths = singlePost?.blogPostsCollection?.items?.map((post:any) => ({
    params: { slug: post.slug },
  }))
  return { paths, fallback: 'blocking' }

}